#!/usr/bin/env python3
"""
morning_check.py -- Morning circuit health check automation.

Queries JIRA for all open NOE tickets assigned to the current user,
parses the description for circuit triggers, runs the appropriate tools,
posts results back to JIRA, and sends a digest to Slack.

Trigger format (line 1 of JIRA description):
    1250: <IP> | <DS1>        -> Full suite: Autotester + Fiber + OSPF
    1250: <IP>                -> Lite check: Fiber + OSPF only
    (no match)                -> Post "Scanned -- no automation triggers found."

Config read from C:\\Claude\\autotester_config.txt:
    JIRA_EMAIL=...            (non-sensitive, file)
    JIRA_ASSIGNEE_EMAIL=...   (non-sensitive, file)
    SLACK_WEBHOOK=...         (non-sensitive, file)
    INFRA_USER=...            (non-sensitive, file)
    GSX_USER=...              (non-sensitive, file)
    INFRA_PASS                (secure, Credential Manager via keyring)
    GSX_PASS                  (secure, Credential Manager via keyring)
    JIRA_TOKEN                (secure, Credential Manager via keyring)

IXC interface_check is NOT included in the batch suite -- it requires a
specific site + interface that can't be inferred from the 1250 IP alone.
Run it manually from the web UI when needed.

Built by P. Capps.
"""

import re
import sys
import os
import datetime
import getpass
import base64

try:
    import requests
except ImportError:
    print("ERROR: requests not installed.  pip install requests")
    sys.exit(1)

from device_base import CredentialError, prompt_ip
from jira_client import post_comment, post_report, valid_ticket, JIRA_BASE
from secure_config import load_config, save_config_key as _save_key

# ── Launcher contract ─────────────────────────────────────────────────────────
TOOL_INFO = {
    'name':     'Morning Check',
    'ran_from': 'Windows workstation',
    'desc':     'Scans all open NOE tickets assigned to you, runs circuit health '
                'checks based on description triggers, posts results to JIRA, '
                'and sends a Slack digest.',
    'requires': 'JIRA creds + infra creds + GSX creds + Slack webhook (config file)',
    'order':    80,
}

CONFIG_PATH   = r"C:\Claude\autotester_config.txt"
OUTPUT_DIR    = r"C:\Claude"
JIRA_BASE_URL = "https://bandwidth-jira.atlassian.net"

# Regex to parse description line 1
# Group 1: IP,  Group 2: DS1(s) (optional)
TRIGGER_RE = re.compile(
    r'^\s*1250\s*:\s*([\d.]+)'       # "1250: <IP>"
    r'(?:\s*[|,]\s*([^\r\n]+))?',    # optional "| <DS1(s)>"
    re.IGNORECASE
)
DS1_SPLIT_RE = re.compile(r'[,&\s]+')


# ── JIRA REST helpers ─────────────────────────────────────────────────────────
def _jira_headers(email, token):
    cred = base64.b64encode("{}:{}".format(email, token).encode()).decode()
    return {
        "Authorization": "Basic {}".format(cred),
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }


def get_my_open_tickets(email, token, assignee_email):
    """Return [{key, summary, description}] for open NOE In Progress tickets.

    Uses /rest/api/3/search/jql -- Atlassian fully REMOVED the old
    /rest/api/3/search endpoint (HTTP 410, confirmed live 2026-08-06:
    "The requested API has been removed. Please migrate to the
    /rest/api/3/search/jql API."). The new endpoint also drops
    startAt/total in favor of nextPageToken-based pagination, so this
    loops on that instead of assuming one page covers everything.

    Uses assignee = currentUser() rather than matching assignee_email as a
    literal string -- Jira Cloud's "User Email Visibility" privacy setting
    can make assignee = "someone@x.com" silently resolve to ZERO issues
    (200 OK, no error, just nothing matches) if it can't look up that email
    to an account, which is exactly what happened on the live run this
    replaces: HTTP 200, empty issues list, no error to point at. Since the
    JIRA token passed in already IS assignee_email's own account,
    currentUser() sidesteps the lookup entirely and can't have this failure
    mode. assignee_email is still used for display/logging only now.
    """
    jql = (
        'project = NOE AND assignee = currentUser() '
        'AND status = "In Progress" '
        'ORDER BY updated DESC'
    )

    url = "{}/rest/api/3/search/jql".format(JIRA_BASE_URL)
    headers = _jira_headers(email, token)
    print("  [JIRA] JQL: {}".format(jql))

    results = []
    next_token = None
    for _ in range(20):   # hard cap -- 20 * 50 = 1000 issues, ample headroom
        body = {"jql": jql, "maxResults": 50, "fields": ["summary", "description"]}
        if next_token:
            body["nextPageToken"] = next_token
        try:
            r = requests.post(url, headers=headers, json=body, timeout=30)
        except Exception as e:
            print("[JIRA] Query failed: {}".format(e))
            return results

        if r.status_code != 200:
            print("[JIRA] Query returned HTTP {} -- {}".format(r.status_code, r.text[:200]))
            return results

        data = r.json()
        page_issues = data.get("issues", [])
        for issue in page_issues:
            key    = issue.get("key", "")
            fields = issue.get("fields", {})
            desc   = _extract_adf_text(fields.get("description") or {})
            results.append({"key": key, "summary": fields.get("summary", ""), "description": desc})

        next_token = data.get("nextPageToken")
        if not next_token:
            break

    # The query returning HTTP 200 with zero issues is NOT an error -- it
    # just means nothing matched the JQL. Log that plainly instead of
    # letting it look identical to a query failure (that ambiguity is what
    # made the last miss hard to diagnose).
    if not results:
        print("  [JIRA] Query succeeded (HTTP 200) but matched 0 issues -- "
              "double check the ticket's actual Status field matches "
              "'In Progress' exactly (case/workflow-name sensitive).")
    return results


def _extract_adf_text(adf):
    """Extract plain text from ADF dict -- only needs line 1 for trigger parse."""
    if not adf or not isinstance(adf, dict):
        return ""
    lines = []
    for block in adf.get("content", []):
        block_text = []
        for node in block.get("content", []):
            if node.get("type") == "text":
                block_text.append(node.get("text", ""))
        if block_text:
            lines.append("".join(block_text))
        if lines:
            break  # only need first paragraph
    return "\n".join(lines)


def post_no_trigger_comment(ticket, email, token):
    """Post a minimal 'scanned, nothing found' comment."""
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    ok, msg = post_report(
        ticket=ticket,
        intro="Morning Check -- {} -- Scanned, no automation triggers found.".format(stamp),
        panel_title="Morning Check",
        report_text=(
            "No '1250: <IP>' trigger found on line 1 of the JIRA description.\n"
            "No work was performed.\n\n"
            "To enable automated checks, add a trigger as the first line of the description:\n"
            "  Full suite:  1250: <IP> | <DS1>\n"
            "  Lite check:  1250: <IP>"
        ),
        email=email, token=token,
    )
    return ok, msg


# ── Trigger parser ────────────────────────────────────────────────────────────
def parse_trigger(description):
    """
    Returns:
        ("full", ip, [ds1,...])   -- full suite
        ("lite", ip, [])          -- lite check
        ("none", None, [])        -- no trigger
    """
    if not description:
        return "none", None, []
    line1 = description.splitlines()[0] if description.strip() else ""
    m = TRIGGER_RE.match(line1)
    if not m:
        return "none", None, []
    ip      = m.group(1).strip()
    ds1_raw = (m.group(2) or "").strip()
    if not ds1_raw:
        return "lite", ip, []
    ds1_list = [
        d.strip().lower()
        for d in DS1_SPLIT_RE.split(ds1_raw)
        if d.strip() and d.strip().lower().startswith("ts")
    ]
    if not ds1_list:
        return "lite", ip, []
    return "full", ip, ds1_list


# ── Slack ─────────────────────────────────────────────────────────────────────
def post_slack(webhook_url, message):
    if not webhook_url:
        return False, "No Slack webhook configured."
    try:
        r = requests.post(webhook_url, json={"text": message}, timeout=15)
        if r.status_code == 200:
            return True, "Slack notified."
        return False, "Slack returned HTTP {}: {}".format(r.status_code, r.text[:100])
    except Exception as e:
        return False, "Slack post failed: {}".format(e)


def build_slack_digest(results):
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        "*Morning Circuit Check — {}*".format(stamp),
        "_{} ticket(s) scanned_".format(len(results)),
        "",
    ]
    for r in results:
        if r.get("clean") and not r.get("warnings"):
            icon = ":white_check_mark:"
        elif r.get("warnings"):
            icon = ":warning:"
        else:
            icon = ":large_blue_circle:"
        lines.append("{} *<{}/browse/{}|{}>* — {}".format(
            icon, JIRA_BASE_URL, r["key"], r["key"], r.get("summary", "")[:60]))
        lines.append("  `{}`".format(r.get("status_line", "no status")))
        for dl in r.get("detail_lines", []):
            lines.append("  • {}".format(dl))
        lines.append("")
    return "\n".join(lines)


# ── Batch summary (web UI report panel + Download) ───────────────────────────
# run() processes N tickets and writes one file per ticket via run_full_suite/
# run_lite_suite, but never returned a path itself -- the web app's report
# panel and Download link only ever show/serve whatever run() returns. This
# gives it one small consolidated file to point to instead of the generic
# "finished without producing a report file" fallback.
def _write_batch_summary(assignee, stamp, entries, note=None):
    """
    entries: list of dicts with key/summary/status_line/detail_lines
             (digest_results shape -- see build_slack_digest).
    note:    optional extra line (e.g. "no tickets found", "DRY RUN").
    Returns the written path, or None if the write failed.
    """
    lines = [
        "MORNING CHECK -- BATCH SUMMARY -- {}".format(stamp),
        "=" * 64,
        "Assignee  : {}".format(assignee),
        "Ticket(s) : {}".format(len(entries)),
        "=" * 64, "",
    ]
    if note:
        lines += [note, ""]
    for e in entries:
        lines.append("{}  --  {}".format(e.get("key", "?"), e.get("summary", "")[:70]))
        lines.append("  {}".format(e.get("status_line", "")))
        for dl in e.get("detail_lines", []):
            lines.append("    - {}".format(dl))
        lines.append("")
    lines += ["=" * 64, "END OF BATCH SUMMARY -- see JIRA comments / per-ticket "
              "MorningCheck_*.txt files in C:\\Claude for full detail.", "=" * 64]

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = os.path.join(OUTPUT_DIR, "MorningCheck_Batch_{}.txt".format(ts))
    try:
        with open(out_path, "w") as f:
            f.write("\n".join(lines))
        return out_path
    except Exception as e:
        print("  [!] Batch summary write failed: {}".format(e))
        return None


# ── Tool runners ──────────────────────────────────────────────────────────────
# NOTE: fiber_util and ospf_events use "username"/"password" keys (not
# "infra_user"/"infra_pass") -- this matches their own collect_inputs() contract.

def _read_tool_output(out_path):
    if out_path and os.path.exists(out_path):
        try:
            with open(out_path, "r", errors="ignore") as f:
                return f.read()
        except Exception:
            pass
    return ""


def run_full_suite(ticket, ip_1250, ds1_list, creds):
    """
    Run Autotester + Fiber + OSPF.
    Returns (report_text, summary_text, out_path, digest_info).
    """
    import autotester_standalone as auto
    import fiber_util
    import ospf_events

    username = creds["username"]
    password = creds["password"]
    gsx_user = creds["gsx_user"]
    gsx_pass = creds["gsx_pass"]

    stamp        = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    report_parts = []
    digest_info  = {"key": ticket, "clean": True, "warnings": False, "detail_lines": []}

    report_parts.append("Morning Check -- {} -- {}".format(ticket, stamp))
    report_parts.append("=" * 64)
    report_parts.append("1250 IP : {}".format(ip_1250))
    report_parts.append("DS1(s)  : {}".format(", ".join(ds1_list)))
    report_parts.append("Mode    : Full Suite (Autotester + Fiber Util + OSPF Events)")
    report_parts.append("=" * 64)
    report_parts.append("")

    # ── Autotester ────────────────────────────────────────────────────────
    print("  [{}] Running Autotester ({} DS1s)...".format(ticket, len(ds1_list)))
    report_parts.append("[ AUTOTESTER ]")
    report_parts.append("-" * 40)
    try:
        auto_params = {
            "ip_1250":       ip_1250,
            "ds1_list":      ds1_list,
            "infra_user":    username,
            "infra_pass":    password,
            "gsx_user":      gsx_user,
            "gsx_pass":      gsx_pass,
            "jira_ticket":   None,
            "open_when_done": False,
        }
        auto_text = _read_tool_output(auto.run(auto_params))
        if auto_text:
            report_parts.append(auto_text)
            for line in auto_text.splitlines():
                s = line.strip()
                if s.startswith("FAIL") or "[ !!" in s:
                    digest_info["detail_lines"].append(s[:80])
                    digest_info["clean"]    = False
                    digest_info["warnings"] = True
        else:
            report_parts.append("  [!] Autotester returned no output.")
            digest_info["warnings"] = True
    except CredentialError:
        raise
    except Exception as e:
        report_parts.append("  [!] Autotester failed: {}: {}".format(type(e).__name__, e))
        digest_info["warnings"] = True

    report_parts.append("")

    # ── Fiber Utilization ─────────────────────────────────────────────────
    print("  [{}] Running Fiber Utilization...".format(ticket))
    report_parts.append("[ FIBER UTILIZATION ]")
    report_parts.append("-" * 40)
    try:
        fiber_params = {
            "ip_1250":       ip_1250,
            "username":      username,    # fiber_util uses "username"/"password"
            "password":      password,
            "jira_ticket":   None,
            "open_when_done": False,
        }
        fiber_text = _read_tool_output(fiber_util.run(fiber_params))
        if fiber_text:
            report_parts.append(fiber_text)
            for line in fiber_text.splitlines():
                if "[ !!" in line or "WARN" in line.upper():
                    digest_info["detail_lines"].append("Fiber: " + line.strip()[:70])
                    digest_info["warnings"] = True
        else:
            report_parts.append("  [!] Fiber util returned no output.")
    except CredentialError:
        raise
    except Exception as e:
        report_parts.append("  [!] Fiber util failed: {}".format(e))

    report_parts.append("")

    # ── OSPF Events ───────────────────────────────────────────────────────
    print("  [{}] Running OSPF Events...".format(ticket))
    report_parts.append("[ OSPF EVENTS & FIBER LEVELS ]")
    report_parts.append("-" * 40)
    try:
        ospf_params = {
            "ip_1250":       ip_1250,
            "username":      username,    # ospf_events uses "username"/"password"
            "password":      password,
            "jira_ticket":   None,
            "open_when_done": False,
        }
        ospf_text = _read_tool_output(ospf_events.run(ospf_params))
        if ospf_text:
            report_parts.append(ospf_text)
            down_count = (ospf_text.upper().count("OSPF-DOWN") +
                          ospf_text.count("NEIGHBOR DOWN"))
            if down_count:
                digest_info["detail_lines"].append(
                    "OSPF: {} bounce event(s) in log".format(down_count))
                digest_info["warnings"] = True
        else:
            report_parts.append("  [!] OSPF events returned no output.")
    except CredentialError:
        raise
    except Exception as e:
        report_parts.append("  [!] OSPF events failed: {}".format(e))

    report_parts.append("")

    # ── Write combined file ───────────────────────────────────────────────
    full_text = "\n".join(report_parts)
    ts        = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path  = os.path.join(OUTPUT_DIR,
        "MorningCheck_{}_{}_{}.txt".format(ticket, ip_1250.replace(".", "_"), ts))
    try:
        with open(out_path, "w") as f:
            f.write(full_text)
        print("  [{}] Written: {}".format(ticket, out_path))
    except Exception as e:
        print("  [!] Write failed: {}".format(e))
        out_path = None

    # ── Build summary block (always-visible in JIRA) ──────────────────────
    summary_lines = [
        "Morning Check -- {} -- {}".format(ticket, stamp), "",
        "Mode: Full Suite | IP: {} | DS1(s): {}".format(ip_1250, ", ".join(ds1_list)), "",
    ]
    if digest_info["detail_lines"]:
        summary_lines.append("Findings:")
        for dl in digest_info["detail_lines"][:10]:
            summary_lines.append("  {}".format(dl))
    else:
        summary_lines.append("No faults flagged across all tools.")
    summary_text = "\n".join(summary_lines)

    digest_info["status_line"] = (
        "Full suite — {} finding(s)".format(len(digest_info["detail_lines"]))
        if digest_info["detail_lines"] else "Full suite — all clean"
    )
    return full_text, summary_text, out_path, digest_info


def run_lite_suite(ticket, ip_1250, creds):
    """
    Run Fiber + OSPF only (no DS1 specified).
    Returns (report_text, summary_text, out_path, digest_info).
    """
    import fiber_util
    import ospf_events

    username     = creds["username"]
    password     = creds["password"]
    stamp        = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    report_parts = []
    digest_info  = {"key": ticket, "clean": True, "warnings": False, "detail_lines": []}

    report_parts.append("Morning Check -- {} -- {}".format(ticket, stamp))
    report_parts.append("=" * 64)
    report_parts.append("1250 IP : {}".format(ip_1250))
    report_parts.append("Mode    : Lite Check (Fiber Util + OSPF Events -- no DS1 specified)")
    report_parts.append("=" * 64)
    report_parts.append("")

    for label, module, params_extra in [
        ("FIBER UTILIZATION", fiber_util, {}),
        ("OSPF EVENTS & FIBER LEVELS", ospf_events, {}),
    ]:
        print("  [{}] Running {}...".format(ticket, label))
        report_parts.append("[ {} ]".format(label))
        report_parts.append("-" * 40)
        try:
            p = {"ip_1250": ip_1250, "username": username, "password": password,
                 "jira_ticket": None, "open_when_done": False}
            p.update(params_extra)
            text = _read_tool_output(module.run(p))
            if text:
                report_parts.append(text)
                if label == "OSPF EVENTS & FIBER LEVELS":
                    down_count = (text.upper().count("OSPF-DOWN") +
                                  text.count("NEIGHBOR DOWN"))
                    if down_count:
                        digest_info["detail_lines"].append(
                            "OSPF: {} bounce event(s)".format(down_count))
                        digest_info["warnings"] = True
            else:
                report_parts.append("  [!] {} returned no output.".format(label))
        except CredentialError:
            raise
        except Exception as e:
            report_parts.append("  [!] {} failed: {}".format(label, e))
        report_parts.append("")

    full_text = "\n".join(report_parts)
    ts        = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path  = os.path.join(OUTPUT_DIR,
        "MorningCheck_{}_{}_{}.txt".format(ticket, ip_1250.replace(".", "_"), ts))
    try:
        with open(out_path, "w") as f:
            f.write(full_text)
        print("  [{}] Written: {}".format(ticket, out_path))
    except Exception as e:
        print("  [!] Write failed: {}".format(e))
        out_path = None

    summary_lines = [
        "Morning Check -- {} -- {}".format(ticket, stamp), "",
        "Mode: Lite Check | IP: {}".format(ip_1250), "",
    ]
    if digest_info["detail_lines"]:
        summary_lines += ["Findings:"] + ["  {}".format(d) for d in digest_info["detail_lines"]]
    else:
        summary_lines.append("Fiber and OSPF checks clean.")
    summary_text = "\n".join(summary_lines)

    digest_info["status_line"] = (
        "Lite check — {} finding(s)".format(len(digest_info["detail_lines"]))
        if digest_info["detail_lines"] else "Lite check — clean"
    )
    return full_text, summary_text, out_path, digest_info


# ── Launcher contract ─────────────────────────────────────────────────────────
def collect_inputs(session=None):
    session = session or {}
    cfg     = load_config()

    print("\n-- Morning Check Configuration --")

    email    = cfg.get("JIRA_EMAIL", "")
    token    = cfg.get("JIRA_TOKEN", "")
    if not (email and token):
        if not email:
            email = input("JIRA email: ").strip()
        if not token:
            token = getpass.getpass("JIRA API token: ")
        if not (email and token):
            print("JIRA credentials required.")
            return None

    assignee = cfg.get("JIRA_ASSIGNEE_EMAIL", "")
    if not assignee:
        assignee = input("Your JIRA assignee email [{}]: ".format(email)).strip() or email
        _save_key("JIRA_ASSIGNEE_EMAIL", assignee)

    username = cfg.get("INFRA_USER", "") or session.get("infra_user", "")
    password = cfg.get("INFRA_PASS", "") or session.get("infra_pass", "")
    if not (username and password):
        print("\n-- Infrastructure Credentials (1250 / 1800 / MUX) --")
        if not username:
            username = input("Username: ").strip()
        if not password:
            password = getpass.getpass("Password: ")
        if not (username and password):
            print("Infrastructure credentials required.")
            return None

    gsx_user = cfg.get("GSX_USER", "") or session.get("gsx_user", "")
    gsx_pass = cfg.get("GSX_PASS", "") or session.get("gsx_pass", "")
    if not (gsx_user and gsx_pass):
        print("\n-- GSX Credentials --")
        if not gsx_user:
            gsx_user = input("GSX username: ").strip()
        if not gsx_pass:
            gsx_pass = getpass.getpass("GSX password: ")
        if not (gsx_user and gsx_pass):
            print("GSX credentials required.")
            return None

    slack_webhook = cfg.get("SLACK_WEBHOOK", "")
    if not slack_webhook:
        raw = input("\nSlack webhook URL (leave blank to skip): ").strip()
        if raw:
            slack_webhook = raw
            _save_key("SLACK_WEBHOOK", slack_webhook)

    dry_run = input("\nDry run? (parse tickets only, no execution) (y/n) [n]: ").strip().lower()
    dry_run = dry_run in ("y", "yes")

    open_when_done = input(
        "\nOpen the batch summary file when done? (y/n) [n]: ").strip().lower()
    open_when_done = open_when_done in ("y", "yes")

    return {
        "jira_email":     email,
        "jira_token":     token,
        "assignee":       assignee,
        "username":       username,
        "password":       password,
        "gsx_user":       gsx_user,
        "gsx_pass":       gsx_pass,
        "slack_webhook":  slack_webhook,
        "dry_run":        dry_run,
        "open_when_done": open_when_done,
        # Session harvest keys
        "infra_user":    username,
        "infra_pass":    password,
    }


def run(params):
    """Main execution -- no prompting."""
    email         = params["jira_email"]
    token         = params["jira_token"]
    assignee      = params["assignee"]
    username      = params["username"]
    password      = params["password"]
    gsx_user      = params["gsx_user"]
    gsx_pass      = params["gsx_pass"]
    slack_webhook  = params.get("slack_webhook", "")
    dry_run        = params.get("dry_run", False)
    open_when_done = params.get("open_when_done", False)

    creds = {"username": username, "password": password,
             "gsx_user": gsx_user, "gsx_pass": gsx_pass}

    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    print("\n" + "=" * 64)
    print("  MORNING CHECK -- {}".format(stamp))
    print("=" * 64)

    def _finish(entries, note=None):
        """Write the batch summary, honor open_when_done, return the path --
        the one exit point for run(), used from every early-return below too
        so 'no tickets'/'dry run' behave the same as a full completed run."""
        out_path = _write_batch_summary(assignee, stamp, entries, note=note)
        if open_when_done and out_path:
            try:
                os.startfile(out_path)
            except Exception as e:
                print("[!] could not auto-open batch summary: {}".format(e))
        return out_path

    # ── Fetch tickets ─────────────────────────────────────────────────────
    print("\nFetching open NOE tickets for {}...".format(assignee))
    tickets = get_my_open_tickets(email, token, assignee)
    if not tickets:
        print("No open tickets found (or JIRA query failed).")
        return _finish([], note=(
            "No open NOE tickets found for this assignee (or the JIRA "
            "query failed -- check the server console for details)."))

    print("Found {} ticket(s).".format(len(tickets)))

    # ── Parse triggers ────────────────────────────────────────────────────
    parsed = []
    for t in tickets:
        mode, ip, ds1_list = parse_trigger(t["description"])
        parsed.append({"key": t["key"], "summary": t["summary"],
                        "mode": mode, "ip": ip, "ds1_list": ds1_list})
        icon = {"full": "[FULL]", "lite": "[LITE]", "none": "[SKIP]"}[mode]
        detail = "| IP: {} DS1: {}".format(ip, ds1_list) if mode != "none" else ""
        print("  {} {} -- {} {}".format(icon, t["key"], t["summary"][:50], detail))

    if dry_run:
        print("\n[Dry run] Stopping before tool execution.")
        dry_entries = [{
            "key": p["key"], "summary": p["summary"],
            "status_line": "[{}] IP: {}  DS1: {}".format(
                p["mode"].upper(), p["ip"] or "--",
                ", ".join(p["ds1_list"]) if p["ds1_list"] else "--"),
            "detail_lines": [],
        } for p in parsed]
        return _finish(dry_entries, note=(
            "DRY RUN -- tickets were parsed only. No tools were run, no "
            "JIRA comments or Slack digest were posted."))

    # ── Execute per ticket ────────────────────────────────────────────────
    digest_results = []

    for t in parsed:
        key  = t["key"]
        mode = t["mode"]
        print("\n" + "=" * 64)
        print("  Processing {} ({})".format(key, mode.upper()))
        print("=" * 64)

        try:
            if mode == "none":
                print("  No trigger -- posting scan notice...")
                ok, msg = post_no_trigger_comment(key, email, token)
                print("  [JIRA] {}".format(msg if ok else "FAILED: " + msg))
                digest_results.append({
                    "key": key, "summary": t["summary"],
                    "clean": True, "warnings": False,
                    "status_line": "Scanned — no triggers found", "detail_lines": [],
                })
                continue

            elif mode == "lite":
                report_text, summary_text, out_path, digest_info = run_lite_suite(
                    key, t["ip"], creds)
            else:
                report_text, summary_text, out_path, digest_info = run_full_suite(
                    key, t["ip"], t["ds1_list"], creds)

            digest_info["summary"] = t["summary"]

            # Post to JIRA
            print("  [{}] Posting to JIRA...".format(key))
            ok, msg = post_report(
                ticket=key,
                intro="Morning Check -- {} -- {} | {}".format(
                    stamp, t["ip"],
                    ", ".join(t["ds1_list"]) if t["ds1_list"] else "lite check"),
                panel_title="Morning Check -- Full Report",
                report_text=report_text,
                email=email, token=token,
                attach_path=out_path,
                summary_text=summary_text,
            )
            print("  [JIRA] {}".format(msg if ok else "FAILED: " + msg))
            if not ok:
                digest_info["detail_lines"].insert(0, "JIRA post failed: {}".format(msg[:60]))

            digest_results.append(digest_info)

        except CredentialError as e:
            print("\n  [!] Credential error on {}: {}".format(key, e))
            raise
        except Exception as e:
            print("  [!] Error on {}: {}: {}".format(key, type(e).__name__, e))
            digest_results.append({
                "key": key, "summary": t["summary"],
                "clean": False, "warnings": True,
                "status_line": "ERROR: {}".format(str(e)[:60]), "detail_lines": [],
            })

    # ── Slack digest ──────────────────────────────────────────────────────
    if slack_webhook and digest_results:
        print("\nPosting Slack digest...")
        ok, msg = post_slack(slack_webhook, build_slack_digest(digest_results))
        print("[Slack] {}".format(msg if ok else "FAILED: " + msg))
    elif not slack_webhook:
        print("\n(Slack webhook not configured -- skipping digest)")

    print("\n" + "=" * 64)
    print("  MORNING CHECK COMPLETE -- {} ticket(s) processed".format(len(parsed)))
    print("=" * 64)

    return _finish(digest_results)


def main():
    print("=" * 64)
    print("  MORNING CHECK -- NOE Ticket Automation")
    print("=" * 64)
    params = collect_inputs()
    if params:
        run(params)


if __name__ == "__main__":
    main()
