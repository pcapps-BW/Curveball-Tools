# Curveball Tools — Changelog

---

## v1.48 — 2026-08-05

### DS1 Test Builder -- restored left column title
- Side-by-side layout (v1.47) left the build column without a heading,
  since it previously just inherited the page's top-level h1. Added a
  "Build Test Script" heading matching the "GSX Monitor (read-only)"
  heading style on the right, so both columns look intentional.
- NOTE: `templates/ds1_gsx_test.html` changed -- hard refresh (Ctrl+Shift+R).

---

## v1.47 — 2026-08-05

### DS1 Test Builder page -- side-by-side layout, separate logs, Stop removed
- Build Test Script and GSX Monitor now sit in two columns side by side
  (stacks to one column on narrow windows) instead of stacked full-width.
- Each box now gets its OWN status/log and report panel underneath it,
  instead of sharing one. Root cause of the earlier "Stop does nothing"
  report: the Stop button's click handler was bound once to whichever
  form initialized first (the build form), so clicking it while the
  monitor was running acted on the wrong job's id. Splitting the panels
  fixes that class of bug generally, not just for Stop.
- Removed the Stop button entirely per request -- it wasn't reliable
  enough to keep. The underlying `/api/job/<id>/stop` endpoint and
  `stop_event` plumbing are left in place server-side (harmless, unused)
  in case a properly-scoped Stop gets added later.
- `_job_panels.html` now takes an optional `panel_suffix` (set via
  `{% set panel_suffix = 'foo' %}` before including) so a page can embed
  multiple independent status/report pairs; omitted entirely it falls
  back to the original `statusPanel`/`reportPanel` ids, so every other
  single-form tool page is unaffected.
- NOTE: `job.js`, `style.css`, and `templates/_job_panels.html` +
  `templates/ds1_gsx_test.html` changed -- hard refresh (Ctrl+Shift+R).

---

## v1.46 — 2026-08-05

### JIRA-posted alert -- bigger, louder, ticket link
- Confirmed working as of v1.44 (the in-page toast fired correctly) but
  was easy to miss: small, top-right corner, opposite side of the screen
  from the form. Rebuilt as the primary "you can continue now" signal
  since native OS desktop notifications turned out to be silently
  swallowed on this machine (Chrome permission + Windows notification
  settings were both fine -- almost certainly Focus Assist or a
  quiet-notification policy outside our control; not worth chasing
  further since this replacement is more reliable anyway):
  - Full-width banner across the TOP of the page (can't end up "off to
    the side" of the content), bigger bold text, drop-in animation,
    20s display / click-to-dismiss.
  - Auto-detects the ticket number in the JIRA result line and adds an
    "Open NOE-XXXX" link straight to the ticket.
  - Audible two-tone chime (Web Audio API, no external files) -- rising
    tone on success, falling tone on failure -- so it's noticeable even
    if you're not looking at the screen. Unlocked from the form-submit
    click (browser autoplay policy requires a real user gesture) and
    reused when the async JIRA result arrives later.
  - Desktop notification + failure alert() kept as extra fallback layers.
- NOTE: `job.js` + `style.css` changed -- hard refresh (Ctrl+Shift+R).

---

## v1.45 — 2026-08-05

### DS1 Test Builder -- "may be hung" warning was firing on normal runs
- Investigated a run that looked stuck at "[1800] running prechecks ..."
  for 5+ minutes -- it wasn't hung, it finished normally at 6m46s. Root
  cause: `_warn_after()`'s 300s (5 min) floor is tuned for single/dual-
  hop tools, but this tool walks 4 live hops per DS1 (1250 -> 1800 ->
  MUX -> GSX) with several commands each, so a normal single-DS1 run
  routinely runs 6-7 minutes. Bumped this tool's floor to 480s (8 min)
  so the warning banner stops firing on ordinary runs.
- No functional bug found or fixed -- the earlier "something broken"
  read was the warning banner's timing, not a hang.

---

## v1.44 — 2026-08-05

### Web -- JIRA "posted" notification
- When the live log shows the JIRA post result, the browser now notifies
  the user that the script/report is on the ticket and they can continue
  (`job.js`, `style.css`). Three layers:
  - Desktop notification (works even from another tab/window) --
    permission requested on first job submit.
  - In-page toast, top-right, green border on success / red on failure,
    auto-dismisses after 12s or on click.
  - alert() popup as last resort on FAILURE when desktop notifications
    are denied (success stays non-blocking).
- Works for every tool automatically -- it keys off the "[JIRA] Comment
  posted / attached / FAILED" lines all tools already print. Once per
  job.
- NOTE: `job.js` + `style.css` changed -- hard refresh (Ctrl+Shift+R).

---

## v1.43 — 2026-08-05

### GSX Monitor -- Stop button, clean output, deltas; script in JIRA
- **Stop button**: generic stoppable-job plumbing (`threading.Event` per
  job, `POST /api/job/<id>/stop`, `stoppable` flag in status polls). The
  GSX Monitor sleeps in 1s steps so a Stop lands within ~a second; the
  log ends with "[GSX Monitor] STOPPED by user after N poll(s)". A red
  Stop button appears in the status panel only while a stoppable job is
  running. Non-stoppable jobs reject the endpoint (400).
- **Monitor output deduped**: counter lines containing "Alarm" matched
  both the counter regex and the status/alarm keyword scan, printing
  everything twice. Now parsed once with a seen-set.
- **"+N since last poll" deltas**: the counters are cumulative, and the
  test question is "are errors still incrementing while my loop is up?"
  -- so a counter that climbs between polls is tagged
  "<-- +N since last poll". Static counters print plain.
- **Generated script now posts as an expand panel in the JIRA comment**
  (switched the Test Builder to post_report): intro line, visible
  per-circuit summary, collapsed "DS1 Test Script -- <device> <test>"
  panel with the FULL script (previous post_comment path truncated to
  4000 chars under a misleading panel title), file attachment as before.
- Known issue (parked per P. Capps): GSX creds still not auto-carrying
  from the build form to the monitor form on some runs -- workaround is
  typing them in the monitor form.
- NOTE: `job.js` + `style.css` changed -- hard refresh (Ctrl+Shift+R).

---

## v1.42 — 2026-08-05

### Fixes from first live DS1 Test Builder run
- **GSX Monitor creds not forwarded**: the cred-copy submit listener was
  registered AFTER job.js's submit handler (same element = registration
  order), so blank creds were read before the copy ran. Registration
  reordered -- "blank = reuse from above" now actually works.
- **JIRA post produced nothing**: root cause was in `jira_client._build_adf`
  -- the Test Builder posts with an empty PM-panel text, and ADF rejects
  empty text nodes, so Jira 400'd the whole comment. Panels with no
  content are now omitted (guarded in `_build_report_adf` too). Also:
  a checked "Post to JIRA" box with a blank ticket is now a form error
  instead of a silent skip, and the tool logs "[JIRA] skipped -- no
  ticket provided" when applicable.
- **"[K" artifacts (root cause, all tools)**: `device_base`'s reader
  thread pumps 1 byte at a time and ANSI-stripped per byte -- a
  multi-byte sequence like \x1b[K never matched, survived into reports,
  and browsers displayed the bare "[K" after eating the invisible ESC.
  `_clean()` now strips ANSI over the whole assembled output. (Belt &
  suspenders: `mux_loop_script._capture` also strips.) Fixes the same
  artifact previously seen in Autotester PM sections.
- **ROUTE section now lists every device with its IP** per DS1 (1250,
  1800 + OC path, MUX, GSX + T1 assignment).
- **Every command section now uses the STEP 6 format** -- "On <device>
  (<ip>):" header before the commands (STEPs 2, 3, 4, 5, 6; grouped per
  GSX node for multi-DS1 runs).
- **STEP 4 (MONITOR) now includes the clear-counters command** per DS1
  ("clear once the test is up, then poll"), alongside the SHOW commands.

---

## v1.41 — 2026-08-05

### DS1 Test Builder -- GSX Monitor auto-fill
- The user now only ever types the 1250 IP + DS1(s) (+ creds once). The
  build job publishes its resolved GSX targets (node, IP, T1 assignment
  per DS1) mid-run through the job-status feed (`ds1_gsx_test.run()`
  gained an optional `result_sink`; `/api/job/<id>` returns it as
  `extras`), and the page auto-fills the GSX Monitor's IP + assignment
  the moment the route resolves -- no digging through the script text.
- Multiple DS1s render as clickable target chips ("ts1/1 -> T1-1-10-1-15
  @ 10.x.x.x") that fill the monitor form on click.
- GSX credentials carry over from the build form to the monitor form
  automatically when left blank ("blank = reuse from above").
- Plumbing is generic (`job.js` exposes a per-poll `window.onJobData`
  hook; any tool can publish `extras`) -- CLI behavior unchanged
  (`result_sink` defaults to None).
- NOTE: `job.js` changed -- hard refresh (Ctrl+Shift+R) to pick it up.

---

## v1.40 — 2026-08-05

### NEW TOOL: DS1 Test Builder (AIS / Loops to GSX) -- `ds1_gsx_test.py`
- Single-page DS1 test workflow: resolve the full route per DS1 (1250 ->
  1800 -> MUX -> GSX, same chain as the Autotester/MUX Loop tool), run
  live read-only prechecks, then generate a copy/paste test script.
  **Nothing config-touching is ever executed.** Script sections:
  1. ROUTE (per-DS1: MUSE, 1800 OC path, GSX node + T1 assignment)
  2. PRECHECKS (live output embedded: 1250 status/PMs, 1800 OC
     PMs/alarms, GSX STATUS/STATISTICS)
  3. CLEAR GSX COUNTERS (CONFIGURE T1 ... PERFMON RESET COUNTERS ALL
     per DS1 -- per P. Capps, GSX clears only)
  4. TEST ON (AIS or loop commands for the chosen device + direction)
  5. MONITOR (GSX SHOW commands to repeat, or use the web monitor)
  6. TEST OFF / BACK-OUT (always-run section)
  7. POSTCHECKS (commands only)
- **Never-guess token extraction**: the 1250's ces-card type and the
  1800's slot/card/port/sts-1/vt-15 tokens are read from each device's
  own config render (grep "chassis slot <ts> ces-card"), and the 1800's
  sts/vt is cross-checked against the resolved OC string. Every change
  command is stamped [VERIFIED against config: <actual line>] or a loud
  [UNVERIFIED -- ...] with exactly what didn't match. Prod-safe by
  construction.
- Directions supported (per P. Capps' command reference 2026-08-05):
  - 1250 AIS: toward GSX (force-ais-psn-bound) / toward LEC
    (force-defect-tdm-bound ais); turn-down = delete of the same path.
  - 1250 loops: facility (faces LEC) / terminal (faces BW core);
    down = maintenance loopback release.
  - 1800 AIS (**SYNTAX UNVERIFIED -- flagged with a warning banner in
    the UI and the generated script**): toward 1250 (psn-bound) /
    toward MUX/GSX (tdm-bound ais) / disable (both directions).
  - 1800 loops: facility / terminal (orientation notes marked "verify").
- **GSX Monitor** (web page, read-only): polls SHOW T1 <id> STATISTICS
  at a chosen interval (5-300s) for a chosen duration (30s-1hr),
  streaming a timestamped snapshot (status/alarm lines + any non-zero
  counters) into the live log each poll -- watch errors move (or stay
  flat) while a loop/AIS test is up. Fixed duration since jobs can't be
  killed yet.
- Web: /tools/ds1-gsx-test with dynamic direction dropdown per
  device/test combo; JIRA posting includes the visible summary + full
  script attachment. CLI launcher picks the tool up automatically
  (order 70). `job.js` now supports multiple forms per page.
- Verified: token extractors (exact match / mismatch->UNVERIFIED /
  missing->UNVERIFIED), all command builders against the provided
  reference syntax (incl. oc48 variant + delete forms), web validation
  paths, monitor job lifecycle.

---

## v1.39 — 2026-08-05

### All tools -- visible findings summary on every JIRA post
- `post_report()` gained `summary_text` (mirroring `post_comment`):
  an always-visible findings block on the ticket, in BOTH the normal
  inline post and the too-large attachment fallback. No more bare
  "see attached file" comments from any tool.
- Per-tool summaries:
  - **OSPF Events + Fiber Levels**: per-event "Date  Time  DOWN/FULL"
    lines (timestamp parsed from each event; unparseable lines echoed
    raw so nothing is dropped), count header, capped at 40 per category
    with a "+N more" pointer. Fiber light levels as
    "ts2  tx -6.4 dBm | rx -6.0 dBm" per slot.
  - **Fiber Utilization**: per-port "IN cur/max | OUT cur/max" in Mbps.
  - **DS1 PMs**: one line per DS1 -- the device's own physical status
    row + NE alarm count (first alarm quoted).
  - **1250 Health Check**: NE/Chassis alarm counts (first rows quoted),
    OSPF neighbor / LDP session line counts, and any DS1 status rows
    flagged LOS/LOF/AIS/DOWN across all CES slots.
  - **NPT-1250 Discovery**: fiber/CES slot inventory, active MUSE DS1
    count + list, alarm section counts, OSPF/LDP line counts.
  - **GSX Perfmon**: T1 operational/alarm/admin status lines + non-zero
    current-day error counters (or "none").
  - **IXC Check**: OSPF neighbor + LDP adjacency found/none (row
    quoted), ping results parsed to "4/4 received (0% loss)" for both
    the standard and 8000B DF pings.
  - **MUX CEM Loop Script** (both modes): resolved circuit path
    (1250/DS1/MUSE, 1800/OC, MUX ACR/CEM/conn, GSX node/IP) + reminder
    that loop commands are generated, not executed.
- Verified: all 10 files compile; OSPF summary formatting across three
  timestamp formats + no-timestamp fallback; post_report summary
  placement on both the normal and fallback paths.

---

## v1.38 — 2026-08-05

### JIRA summary -- per-DS1 REVIEW line (standardized diagnosis matrix)
- **Every DS1 section in the JIRA summary now ends with a REVIEW line**
  (`output_builders.py`: `_ds1_review()`): a brief paragraph that states
  what was seen, explains WHY the conclusion follows, and names the next
  step -- not just "Engage X". Derived entirely from the standardized
  per-hop Clean/Dirty verdicts, walked bottom-up: faults cascade
  downstream (away from the LEC, toward the GSX), so the lowest dirty
  hop is treated as the root cause. The finite matrix:
  - Route incomplete -> fix Netbox, re-run before concluding.
  - All clean -> no active fault at test time; suspect intermittent /
    outside the tested span. (Notes when CES PMs were disabled.)
  - 1250 TDM LOS -> LEC handoff; everything above is echoing the loss.
  - 1250 TDM errored (no LOS) -> marginal LEC signal; monitor.
  - 1250 CES dirty, rest clean -> packet transport 1250<->1800, not the
    physical circuit; re-run to distinguish historical vs climbing.
  - 1800 1250-side dirty -> NNI/EVC segment (optics/fiber).
  - 1800 MUX-side dirty -> SONET transport 1800<->MUX (Peerless
    variant: toward the Peerless handoff; engage Peerless).
  - MUX 1800-side dirty (non-AIS) -> MUX facility / CEM connection.
  - MUX GSX-side dirty -> T3 span MUX<->GSX.
  - GSX dirty, route clean -> the GSX port itself.
  - Multiple dirty -> root named first; downstream dirt flagged as
    likely knock-on effects.
- DS1_AIS cases keep their existing (more specific) VERDICT paragraph
  and skip the generic REVIEW -- no duplication.
- Verified all 9 matrix branches with synthetic runs.

### Web -- version number in the watermark
- Watermark now reads "Built by P. Capps · vX.XX" on every page
  (`app.py`: APP_VERSION constant + context processor, `base.html`).
  One place to bump per release, kept in sync with this changelog.

---

## v1.37 — 2026-08-05

### JIRA comment -- per-DS1 brief summary, always visible
- **New `build_jira_summary()`** (`output_builders.py`): builds a compact
  per-DS1 block for the JIRA comment -- DS1 assignment as a header, that
  DS1's per-hop Clean/Dirty status on readable lines beneath it, plus any
  DS1_AIS VERDICT paragraph lifted from that DS1's diagnostic summary.
  Repeated per DS1, since each channel can have different symptoms.
- **The summary is always visible on the ticket** (`jira_client.py`,
  `autotester_standalone.py`):
  - Normal-size reports: summary appears as plain text right under the
    intro line, above the existing collapsed panels.
  - Too-large reports (the attachment fallback that fired on the 7-DS1
    run): the stub comment now carries the same visible summary -- no
    more bare "see attached file" with zero at-a-glance info. When the
    Run Summary + Diagnostic block also fits, it rides along in a
    collapsed panel underneath as before.
- Verified with synthetic 3-DS1 run (clean / route-FAIL / DS1_AIS with
  verdict): summary renders per-DS1, normal ADF = paragraph > summary >
  2 expands, fallback stub ADF = paragraph > summary > optional expand.

---

## v1.36 — 2026-08-05

### JIRA posting -- fix indefinite hang on large reports
- Symptom: multi-DS1 Autotester run stuck at "[JIRA] Posting results to
  NOE-XXXX ..." indefinitely. Root cause: requests' timeout= only covers
  waiting for RESPONSE bytes -- it does NOT bound the upload/send phase.
  A proxy/VPN that accepts the connection but stalls consuming a large
  upload (a 7-DS1 report builds a multi-hundred-KB JSON comment) blocks
  requests.post() forever, so the 30s timeout never fired. Small runs =
  small payload = worked; large runs could hang. Three fixes
  (`jira_client.py`):
  1. **Watchdog** (`_bounded()`, 240s ceiling): post_comment/post_report
     now run their network work in a bounded thread. A stall comes back
     as "[JIRA] FAILED: TIMED OUT after 240s ..." with a reminder that
     the report file is already saved locally -- the job finishes
     normally instead of hanging.
  2. **Size pre-check** (COMMENT_TEXT_LIMIT = 30k chars): reports over
     Jira's inline comment limit were guaranteed a CONTENT_LIMIT_EXCEEDED
     rejection anyway -- and that giant JSON upload was exactly the
     payload most likely to trigger the send-phase stall. Now oversized
     reports skip the comment attempt and go straight to the existing
     stub-comment + file-attachment fallback.
  3. **Progress prints** in the fallback path ("report text ~N KB --
     over the inline comment limit...", "posting stub comment ...",
     "uploading attachment X (N KB) ...") -- the JIRA phase is no longer
     silent between "Posting results ..." and the final result, so the
     web live log / console shows exactly which step it's on.
- Applies to all tools (Autotester via post_comment; the others via
  post_report). Verified watchdog timeout, fast-path passthrough, and
  size-bypass routing with synthetic tests.

---

## v1.35 — 2026-08-05

### Autotester -- DS1_AIS cross-hop correlation VERDICT
- **The static "(AIS from LEC/1250 direction ...)" note is replaced with
  an automated troubleshooting verdict** (`output_builders.py`:
  `_ais_verdict()` + `_wrap_note()`). When the MUX reports DS1_AIS, the
  diagnostic summary now correlates it against the same run's upstream
  data and prints a brief paragraph walking the logic and naming the
  next action. Finite symptom matrix, checked in priority order:
  1. 1250 TDM LOS/LOF -> LEC handoff failure (1250 is generating the
     AIS). Engage the LEC.
  2. 1250 receiving AIS -> failure deeper in the LEC network; 1250 is
     passing it through. Engage the LEC.
  3. 1250 TDM clean but middle dirty (CES/EVC/NNI/OC, named in the
     verdict) -> transport fault between 1250 and MUX; work that
     segment first.
  4. 1250 TDM errored (no hard LOS/AIS), path clean -> marginal LEC
     signal; monitor.
  5. Everything clean -> the 1800 is inserting AIS into an unequipped /
     mis-stitched VT (provisioning or mapping gap -- clean PMs are
     EXPECTED here since AIS transports without errors). Verdict names
     the exact MUSE circuit, OC/STS/T1, ACR/CEM to verify, and the MUX
     'show cem circuit' Lbits corroboration check.
- Rationale: AIS is generated at the point of failure and travels
  downstream only, so the AIS origin is fully determined by data the
  Autotester already collects in the same run (1250 TDM state, CES/EVC/
  NNI/OC health). Verified all 5 branches with synthetic inputs.
- `_wrap_note()` wraps verdicts to report width without splitting
  interface names on hyphens.

---

## v1.34 — 2026-08-05

### Autotester -- diagnose GSX node/slot/port unresolved (None-None-None-N)
- Confirmed the "FLAG: WARNING: Netbox not populated -- MUX description
  fallback used..." message only ever fires from the Tier-2 MUX-controller-
  description branch in `mux4216_client.py` -- i.e. it's proof that branch
  DID run and DID succeed (found the ACR via the MUX's SONET-ACR
  description), not the Tier-3 shotgun-guess fallback. That message and
  a Tier-3 "legacy ACR-guess used" message are mutually exclusive, so
  seeing the Tier-2 wording means Tier-2 worked.
- The separate "GSX None-None-None-N" symptom is unrelated to that --
  it comes from a second, independent description lookup (the GSX-side
  T3 controller's description, parsed for a NODE-SLOT-PORT-T1 naming
  convention like `LAXGSX04-11-2-14`) failing to resolve. Root cause is
  almost always that the T3 controller simply has no description
  configured, or one that doesn't match the expected 4-part format --
  a provisioning-documentation gap, same family of issue as an
  unpopulated Netbox entry, just on the GSX side of the MUX instead.
- `mux4216_client.py`: added a `gsx_flag` on the mux result dict --
  fires a specific warning ("no description configured" with the raw
  command output, or "doesn't match expected format" with what was
  found) whenever node/slot/port can't be derived, instead of silently
  leaving them `None` with no trail to follow.
- `autotester_standalone.py`: surfaces `gsx_flag` as its own FLAG line
  in the live progress log (same place `netbox_conflict` already
  showed), and the "GSX {node}-{slot}-{port}-{t1}" progress line now
  prints `?` instead of `None` for any unresolved field. (The polished
  report already did this via `build_route_block`'s `or "?"` -- this
  was only a console/live-log cosmetic gap.)

---

## v1.33 — 2026-08-05

### Web Front End — pass/fail rollup + attribution
- **Overall PASS/FAIL badge on finished reports** (`app.py`, `job.js`,
  `_job_panels.html`, `style.css`) -- scans the Run Summary section
  (currently only the Autotester writes one) for any "Dirty" tag or
  "FAIL" line across all DS1s and shows one glance-check badge above the
  report: green "PASS -- N DS1(s) clean" or red "ISSUES DETECTED --
  <DS1s>". No change to the underlying report text or to any tool's
  logic -- the existing per-DS1 PASS/FAIL in the Run Summary only ever
  reflected whether the route resolved, not hop health, so this adds the
  rollup that was missing rather than replacing anything. Tools that
  don't emit a Run Summary show no badge (nothing to roll up yet).
- **Subtle attribution watermark** on every page (`templates/base.html`,
  `style.css`) -- "Built by P. Capps", fixed bottom-right, low opacity,
  inherited automatically by every tool page and the home page.

---

## v1.32 — 2026-08-05

### Web Front End — live step-by-step progress log
- **Status panel now shows a scrolling log while a job runs**, not just an
  elapsed timer. No changes to any tool's actual logic -- every tool
  already `print()`s progress as it works ("[connecting] ...",
  "[GSX] resolving ...", etc.); `app.py` now captures those same lines
  per-job via a small thread-aware stdout tee (`_JobStdoutTee`) and hands
  them back through `/api/job/<id>` as a `log` list. `job.js` appends only
  the new lines each poll and auto-scrolls.
- Concurrent jobs stay correctly separated (each background thread's
  writes are routed to its own job's log via a thread-id map) -- verified
  with two simultaneous runs against different IPs.
- This was the natural next step flagged when the polling architecture
  was first built (v1.29): the background-thread + poll scaffolding
  needed no structural changes, just a place to route the existing print
  output.

---

## v1.31 — 2026-08-04

### Web Front End — all 9 tools + home page
- **Home page** (`templates/home.html`) -- lists every tool as a card
  (name, which device it runs from, description, what it requires),
  pulled live from each module's own `TOOL_INFO` dict and sorted by the
  same `order` the CLI launcher menu uses. `/` now renders this instead
  of going straight to the Autotester form.
- **Remaining 8 tools wired up** (`app.py`, new templates): NPT-1250
  Discovery, DS1 PMs, Fiber Utilization, OSPF Events + Fiber Levels,
  1250 Health Check, GSX Perfmon (96 Intervals), IXC Check, and the MUX
  CEM Loop Script -- each gets its own page/route/`/api/.../run` endpoint,
  following the same pattern as the Autotester: no `collect_inputs()`,
  same background-job + polling architecture, same "never persist
  credentials" rule.
  - Discovery / Fiber / OSPF / Health share one route helper
    (`_simple_1250_route`) since all four take identical inputs (1250 IP
    + infra creds).
  - DS1 PMs re-validates entries server-side with the tool's own
    `_parse_and_validate()` before launching the job, so bad slot/channel
    input comes back as an immediate form error instead of a failed run.
  - GSX Perfmon reuses the tool's own `_parse_t1_id()` for the same reason.
  - IXC Check's site dropdown is checked against `interface_check.SITE_TO_1800`.
  - MUX CEM Loop Script's form branches on 1250+DS1 vs. MUX-direct mode.
    MUX-direct never opens a live GSX session (GSX info there is only
    embedded as "run manually" text), so GSX credentials are optional in
    that mode -- only required in 1250+DS1 mode, matching what the code
    actually uses.
- **`app.py` generalized**: job-runner/polling machinery (`_launch_job`,
  `_run_job`, `/api/job/<id>`, `/download/<id>`) is now tool-agnostic,
  taking a `run_callable` closure per tool instead of being hardcoded to
  the Autotester.
- **`templates/index.html` retired** -- superseded by `base.html` +
  per-tool templates + `home.html`. Left on disk (not referenced by any
  route) since it couldn't be removed in this environment; safe to
  delete manually.
- Verified: `py_compile` across all tool modules + `app.py`, plus a live
  smoke test of every `/tools/*` page (200) and one job run per tool
  shape (bad-input validation returns 400s with the right messages, and
  unreachable-device runs finish as a graceful `error`/no-report status
  rather than crashing the server).

---

## v1.30 — 2026-08-04

### Web Front End
- **"Open results file when done" checkbox** (`templates/index.html`,
  `app.py`) -- exposes the same `open_when_done` behavior the CLI's
  "Open results file when done? (y/n)" prompt has always had. Was
  previously hardcoded to `False` for the web app (auto-opening a file only
  makes sense when the server and browser are the same machine). A caption
  under the checkbox says so directly, and it stays unchecked by default.

---

## v1.29 — 2026-08-04

### New: Web Front End (Proof of Concept)
- **`app.py` + `templates/index.html`** -- a small Flask app that runs the
  Autotester from a browser instead of a terminal. See `WEB_SETUP.md` for
  the full walkthrough. Highlights:
  - `collect_inputs()` is never called from the web layer (it uses
    `input()`/`getpass()`, which would hang with no terminal attached) --
    the web form builds the same `params` dict directly and calls
    `autotester_standalone.run(params)`, the exact same code path as the CLI.
  - Each run happens in a background thread; the browser polls a status
    endpoint every ~2s showing an elapsed timer, and flags a "may be hung"
    warning past a threshold (5 min, scaling up slightly for multi-DS1
    runs) -- without literally blocking an HTTP request for the run's
    duration.
  - Credentials are submitted fresh per run and held only in memory for
    that job -- never persisted.
  - Finished report renders on the page plus a download link for the same
    `.txt` the CLI would have written.
  - `autotester_standalone.run()` now returns the output file path (was:
    returned nothing) so the web layer can retrieve it. No change to CLI
    behavior -- `main()` still ignores the return value.
  - `requirements.txt` gained `flask>=3.0`.
  - Known POC limitations (in-memory job store, no real job-kill, dev
    server only) and the checklist for eventually moving this onto a
    shared network host are documented in `WEB_SETUP.md`.

---

## v1.28 — 2026-08-04

### Report Format
- **Run Summary standardized to Clean/Dirty per hop/side** (`output_builders.py`)
  - Replaced the itemized-counter findings line (raw counter names + values,
    plus a trailing "Suggest: ..." fault-direction phrase) with a fixed,
    standardized format:
    ```
    TS1/7  --  PASS  |  1250: TDM Clean / CES Dirty (RxPsnES)  |  1800: 1250-side Clean / MUX-side Clean  |  MUX: 1800-side Clean / GSX-side Clean
    ```
    - **1250**: Clean/Dirty on TDM vs CES
    - **1800**: Clean/Dirty on 1250-side (NNI + EVC) vs MUX-side (OC PM +
      alarms) -- Peerless circuits label the second side "network-side"
      since there's no Bandwidth MUX beyond a Peerless 1800 hop
    - **MUX**: Clean/Dirty on 1800-side (facility alarms + connection/xconnect
      state) vs GSX-side (T3 controller counters)
    - Dirty tags name the counter/alarm that tripped it (e.g. `(RxPsnES)`,
      `(LP_AIS)`) -- never the raw value. The trailing "Suggest: ..." phrase
      is gone; the per-side Clean/Dirty tags already convey direction.
  - **CEM Pkts Missing / Failure Counts / Generated+Received Lbits/Rbits
    dropped from Dirty determination entirely**, at the Run Summary AND the
    Diagnostic Summary's CEM indicator. These are cumulative-since-last-
    "clear cem circuit" counters (per the CEM Hairpin Loop MOP's own manual
    clear step) -- not a current-state reading. A mature, healthy circuit
    shows large non-zero values for all of them, so treating any non-zero
    value as "Dirty" was flagging nearly every circuit's MUX hop regardless
    of real health (root cause of the "every DS1 shows MUX CEM errors"
    pattern). The raw circuit counters are still visible in full in the MUX
    Stats section (`>> CEM Circuit Health`) for reference -- just no longer
    drive a pass/fail-style verdict. Connection state and xconnect leg status
    (genuine current-state signals) still do.
  - `run_summary_line()` gained two new parameters (`all_t3_stats`,
    `fiber_results`/`evc_results`) to support the 1800/MUX side-splitting --
    call site updated in `autotester_standalone.py`.

---

## v1.27 — 2026-08-04

### Report Layout
- **Autotester: Full Route + Diagnostic Summary now grouped per channel**
  (`autotester_standalone.py`)
  - Previously the report had two separate combined sections: one Diagnostic
    Summary block spanning every DS1, followed by every DS1's Full Route
    block. Now each DS1's Full Route is immediately followed by that same
    DS1's own Diagnostic Summary before moving to the next channel -- easier
    to digest one circuit at a time instead of cross-referencing two lists.
  - `build_diagnostic_summary` is now called once per DS1 (still the same
    function/logic, just scoped to a single-element list per call) instead of
    once for the whole run. Output content is unchanged, only the ordering.
  - The JIRA "Diagnostic Summary" panel is unaffected -- it's built from the
    same per-channel blocks concatenated together.

### New Features
- **GSX IP address in the Full Route block** (`output_builders.py`,
  `autotester_standalone.py`)
  - `HOP 4 -- GSX` now shows the resolved GSX management IP:
    ```
      HOP 4 -- GSX
        Node       : LAXGSX01
        IP         : 192.168.45.3
        Assignment : 11-2-27
        T1 Command : SHOW T1 T1-1-11-2-27
    ```
  - The IP is the live management address the Autotester actually reached
    (resolved via Netbox mgmt IPs + reachability ping, same value used to
    open the GSX session). Shows `?` if no reachable IP was resolved for that
    DS1 (mirrors the existing fallback convention used elsewhere).

---

## v1.26 — 2026-08-04

### Performance
- **1800 MUSE lookup batched per hub instead of per DS1** (`npt1800_client.py`)
  - Root cause of the "any show configuration | ... command is slow" complaint:
    the MUSE ID -> OC lookup (`show configuration | display-set | match
    "{muse_id} "`) issued that call **once per DS1**. The slowness is a
    device-side full-config render (~90-120s), and that render cost is paid
    per CALL, not per DS1 -- so a 4-DS1 run on one hub paid it 4 times
    (~6-8 minutes) for data a single render already contains.
  - New `_muse_lookup_batch()` issues **one render per hub**, matched against
    a regex alternation of every DS1's muse_id needed that run (Junos-style
    `match` supports `|` alternation), then groups the returned lines back to
    each muse_id locally in Python. Same source command, same selectivity
    (still only matches the muse_ids actually needed -- no broader/unscoped
    dump), just consolidated. This mirrors the pattern `npt1250_client.
    query_batch` already uses for `peer-address` (one render, parse many).
  - Net effect: an N-DS1 run on one hub now costs ~90-120s total instead of
    N * 90-120s. No output/behavior change -- verified the OC resolution and
    Peerless-customer detection are correctly scoped per-DS1 even when
    multiple DS1s share one combined render (unit-tested with a 2-DS1 mixed
    Peerless/non-Peerless fixture).
  - The separate OC alarm/PM stat commands (already deduped per unique OC,
    not a full-config render) keep their own smaller timeout, unaffected.

---

## v1.25 — 2026-08-04

### New Tools
- **mux_loop_script.py** — `MUX CEM Loop Script` (launcher order 60) — item 13
  - Generates a copy/paste-ready CEM hairpin loop MOP for a circuit. Does **not**
    execute any config — it connects only to run read-only prechecks, then writes
    a script the engineer pastes manually.
  - **Two input modes:**
    1. **1250 IP + DS1 (default)** — resolves the full route automatically
       (1250 → 1800 → MUX → GSX), the same path the Autotester walks, then fills
       every identifier into the script.
    2. **MUX-direct** — engineer supplies MUX IP / name / ACR / CEM group directly
       (plus optional other-hop info); only the MUX is queried. For when the route
       is already known or Netbox is unavailable.
  - **Prechecks are run live** against every reachable hop and the real output is
    embedded in the script as the baseline. **Postchecks are emitted as commands
    only** (run manually after testing).
  - Generates both scenarios from the MOP, with correct `connect` command syntax
    derived from the resolved ACR / CEM / GSX CE identifiers:
    - **Scenario A** — hairpin facing the **GSX** (`connect ... CEM{gsx} CEM{gsx}`),
      isolates the GSX; includes turn-up, validation, and restore.
    - **Scenario B** — hairpin facing the **1250** (`connect ... CEM-ACR{n} CEM-ACR{n}`),
      isolates the 1250/LEC; includes turn-up, validation, and restore.
  - Connection name (e.g. `CB_OC3_STS02_02`) is discovered automatically via
    `show run | include CEM-ACR{n}` — never typed by hand (new
    `get_connection_name()` in `mux4216_client.py`).
  - Peerless circuits are detected and rejected (no MUX/GSX hop to loop).
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA attachment, auto-opens.

---

## v1.24 — 2026-08-04

### New Features
- **Autotester CEM circuit health** (`mux4216_client.py`, `output_builders.py`,
  `autotester_standalone.py`) — item 14
  - The Autotester now checks CEM circuit health at the MUX hop, closing the gap
    between "the SONET path resolves" and "the emulated circuit is actually clean."
  - New `mux4216_client.query_cem_health()` pulls, per DS1:
    - `show cem circuit interface cem-acr {acr} {cem}` — Pkts Missing, Failure
      Counts, Lbits/Rbits (any non-zero = flagged)
    - `show xconnect all | include CE{acr}:{cem}(` — both legs UP
    - `show connection name {conn}` — Current State UP
    - `show acr group {acr} detail cem` — working/protect state
  - New `get_connection_name()` discovers the connection name automatically
    (shared with the loop-script tool).
  - **Diagnostic Summary** MUX block now shows `[ OK ]/[ !! ] CEM circuit`,
    `Connection UP`, and `Xconnect leg(s) DOWN` indicators.
  - **Run Summary** flags `MUX CEM: Pkts Missing=… / Failure Counts=…` with a
    "check MUX" suggestion.
  - **MUX Stats** section gains a `>> CEM Circuit Health` block with the raw
    circuit / xconnect / connection / ACR-detail output per DS1.
  - All additions are read-only; no change to how the route is resolved.

---

## v1.23 — 2026-08-04

### New Files
- **`Curveball Tools.bat`** — double-click launcher (item 7)
  - Opens a terminal window in the correct directory and runs `python launcher.py`
  - No need to navigate manually; works by double-click from anywhere

- **`Create Curveball Shortcut.ps1`** — one-time taskbar shortcut setup (item 7)
  - Right-click → **Run with PowerShell** (do not double-click — that opens Notepad,
    a Windows default for `.ps1` files)
  - Creates `Curveball Tools.lnk` on the Desktop, ready to right-click → Pin to taskbar

### Documentation
- **`README.md`** — updated tools table (added OSPF Events, GSX Perfmon), updated
  Running section and file list to include `.bat` and shortcut script
- **`INSTALL.md`** — added "Quick launch / Taskbar shortcut" section (step 4),
  updated Quick Setup Checklist

---

## v1.22 — 2026-08-04

### Bug Fixes
- **DS1 input normalization** — item 19 (`autotester_standalone.py`, `ds1_pms.py`)
  - DS1 entries are now lowercased on input, so `TS1/7` and `ts1/7` both work
  - `&` is now accepted as a separator in addition to `,` — entries like
    `TS1/23 & TS1/28` are split correctly instead of being treated as one item

---

## v1.21 — 2026-08-04

### Bug Fixes
- **output_builders.py** — MUX DS1_AIS direction annotation (item 17)
  - `[ !! ] MINOR DS1_AIS` in the diagnostic output now appends
    `(AIS from LEC/1250 direction -- signal loss at bottom of route)`
  - DS1_AIS on the MUX T1 path means the 1800 is inserting AIS into the SONET
    payload because the 1250 is not delivering a valid DS1 — the fault is on the
    LEC/customer side, not the IXC side

- **output_builders.py** — GSX PM interval label in diagnostic header (item 18)
  - GSX node header now reads `GSX -- NYCGSX02  (current 15 min / 24 hr)` instead
    of just `GSX -- NYCGSX02`
  - Clarifies that the `[ !! ]` error counts shown are the max across the current
    15-minute interval and current 24-hour interval (whichever is higher), not
    cumulative statistics

---

## v1.20 — 2026-08-04

### New Tools
- **gsx_perfmon.py** — `GSX Perfmon (96 Intervals)` (launcher order 55)
  - Pulls a complete 24-hour picture of a single T1 on the GSX:
    - `SHOW T1 ... STATUS`
    - `SHOW T1 ... STATISTICS`
    - `SHOW T1 ... PERFMON CURRENT DAY`
    - `SHOW T1 ... PERFMON THRESHOLDS`
    - `SHOW T1 ... PERFMON INTERVAL N FIFTEENMIN` for all 96 intervals
      (interval 1 = most recent, interval 96 = oldest, ~24 hours back)
  - T1 assignment accepts full form (`T1-1-7-2-2`) or short form (`7-2-2`)
  - Reuses GSX credentials from session (no re-prompt if already entered this session)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post with attachment
    fallback, and auto-opens the file
  - Useful for stress-test planning: reveals error frequency and timing so test
    durations are grounded in real failure patterns

---

## v1.19 — 2026-08-04

### New Features
- **MUX controller description fallback** (`mux4216_client.py`) — item 12
  - When Netbox has no OC→SONET mapping for a circuit (e.g. ts3 not yet populated),
    the autotester now tries a second resolution method before falling back to the
    unreliable legacy ACR-guess
  - New method `find_acr_by_description(hub_hostname, slot_port)` scans
    `show run | section controller` on the MUX and looks for a SONET-ACR stanza
    whose description matches `{1800-hostname} {OC-slot/port}`
    (e.g. `ces01.lax1 ts3/1`). Case-insensitive.
  - If matched, uses that ACR number to resolve VTG / T1 / CEM group directly —
    the same path as a successful Netbox lookup, but without Netbox
  - On success: marks `netbox_conflict` with a reminder to populate Netbox
  - Resolution tier order is now:
    1. Netbox `oc_to_sonet` (most accurate, verifies path)
    2. MUX description scan (accurate, works without Netbox)
    3. Legacy ACR-guess (shotgun, last resort)
  - No changes to `autotester_standalone.py` — fallback is entirely inside
    `query_batch`

---

## v1.18 — 2026-08-04

### Bug Fixes
- **Dynamic OC type labeling** — autotester no longer hardcodes "OC12" in output
  - The 1800 regex already captured any OC speed (`oc12`, `oc48`, `oc3`, etc.); only
    the display labels were wrong
  - Added `_oc_label(oc_iface)` helper in `output_builders.py` that extracts the
    speed from the interface identifier (e.g. `oc48-ts20/1:13:1` → `"OC48"`)
  - All user-facing "OC12" label strings replaced in:
    - `output_builders.py` — route blocks, peerless block, full diagnostic block,
      run summary findings and suggestions
    - `npt1800_client.py` — stat section header and "could not find" error message
    - `autotester_standalone.py` — "NPT-1800 OC STATS" section header
    - `mux4216_client.py` — internal `Cannot parse OC interface` error text

---

## v1.17 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display now distinguishes "disabled" from "clean"
  - When the device returns "switch of this interface object is off" (PMs not enabled), `npt1250_client` already writes `"CES PMs not enabled on this DS1."` into the PM blob
  - `build_diagnostic_summary` now detects that marker and shows `[ -- ] CES PMs disabled` instead of `[ OK ] CES PMs clean`
  - Applies to both the full-route and peerless diagnostic blocks

---

## v1.16 — 2026-08-04

### New Features
- **IP address validation** on all manual IP entry prompts
  - Rejects entries that aren't 4 octets with each octet 0–255 (e.g. `192.168.270.1` or `192.168.150` both fail)
  - Re-prompts in a loop until a valid IP is entered — no more silent TCP failures from a typo
  - Implemented via `prompt_ip()` in `device_base.py`; wired into autotester, health check, fiber util, DS1 PMs, discovery, and OSPF events

### Bug Fixes
- **output_builders.py** — incomplete route now returns FAIL in run summary
  - When Netbox data is missing (1800/OC12 not resolved, hub IP unknown, or MUX not found), `run_summary_line` now returns `FAIL | Route incomplete: ... | Check Netbox` instead of `PASS | All clean`

---

## v1.15 — 2026-08-04

### Bug Fixes
- **Bad credential loop fixed** across all tools
  - Previously: auth failure was silently swallowed, bad creds stayed in the session, every subsequent run re-used them with no way to re-enter without quitting
  - Now: `CredentialError` (new exception in `device_base.py`) is raised on `AuthenticationException` (paramiko) or "Access denied" in plink output (GSX)
  - `launcher.py` catches it in `dispatch()`, prints the rejection message, and clears **only the failing cred pair** (`infra` or `gsx`) from the session — the user is re-prompted on the very next tool run without restarting the launcher
  - Files changed: `device_base.py`, `gsx_client.py`, `launcher.py`, `autotester_standalone.py`, `health_check.py`, `fiber_util.py`, `ds1_pms.py`, `interface_check.py`, `npt1250_discovery.py`, `ospf_events.py`

---

## v1.14 — 2026-08-04

### Bug Fixes
- **output_builders.py** — Run Summary CES reporting now shows the worst error, not the first
  - Previous logic stopped at the first CES counter it found (e.g. `RxPsnOverrunEvents=8`) even when a more severe counter was present (`RxPsnES=1627`)
  - Now scans all CES counters and reports the one with the highest value in the run summary line

---

## v1.13 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display placement corrected (NOE-4503)
  - CES PMs now appear **above** the `1250 --` identifier line (`[ !! ] CES ...` / `[ OK ] CES PMs clean`)
  - Removed the duplicate CES block that was also appearing below the `ds1-tsX/Y MUSE_XXXX` line
  - TDM PMs remain below the identifier line, unchanged
  - Fix applied to both the full route block and the peerless block

---

## v1.12 — 2026-08-04

### New Tools
- **ospf_events.py** — `OSPF Events + Fiber Levels` (launcher order 45)
  - Pulls `show ne events unreported` and filters in Python for OSPF state changes
  - Separate sections for DOWN events and FULL/UP events; catch-all for other OSPF lines
  - Also checks fiber transceiver light levels on ts2 and ts5 (TX/RX power)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post and auto-open

### Bug Fixes
- **jira_client.py** — JIRA `CONTENT_LIMIT_EXCEEDED` fallback
  - When a report is too large to post as a comment (HTTP 400), the script now:
    1. Posts a short stub comment noting the attachment
    2. Uploads the `.txt` output file directly as a JIRA attachment
  - Affects all tools: autotester, health check, fiber util, DS1 PMs, interface check, discovery, and the new OSPF events tool

---

## v1.11 — (prior release)

*(No changelog maintained before v1.12 — see git history or `!Revisions/` zip archive for earlier changes.)*
