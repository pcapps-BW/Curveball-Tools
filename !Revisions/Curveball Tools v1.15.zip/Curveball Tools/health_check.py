#!/usr/bin/env python3
"""
health_check.py -- standalone NPT-1250 high-level health check.

A quick overall look at a 1250: interfaces, fiber transceivers (ts2/ts5),
routing adjacencies, DS1 physical status across the CES slots, and alarms/events.
No parsing or pass/fail logic -- it just runs a fixed set of read-only commands
and dumps the output in the standard sectioned format.

Runs standalone (prompts for its own inputs) OR via launcher.py (params dict).
READ-ONLY: 'show' commands only (with session-only '| no-more' paging).

Built by P. Capps.
"""

import os
import datetime

try:
    import paramiko  # noqa: F401
    _DEP_ERROR = None
except ImportError as e:
    _DEP_ERROR = "paramiko not installed (pip install paramiko): {}".format(e)

from npt1250_client import NPT1250Client
from device_base import CredentialError
from jira_client import post_report, valid_ticket

# Hardcoded per spec (matches the fiber + DS1 PMs tools).
FIBER_SLOTS = ["ts2", "ts5"]           # GE transceiver slots
CES_SLOTS   = ["ts1", "ts3", "ts6", "ts8"]

# Ordered command list. Each entry: (section title, command).
# `| no-more` is appended at run time (session-only paging suppression).
def _build_command_list():
    cmds = [
        ("Software Version", "show version"),
        ("Interfaces", "show interfaces"),
    ]
    for slot in FIBER_SLOTS:
        cmds.append(("Transceiver -- {} port1".format(slot),
                     "show chassis transceiver information slot {} port1".format(slot)))
        cmds.append(("Transceiver Laser -- {} port1".format(slot),
                     "show chassis transceiver information slot {} port1 | grep laser".format(slot)))
    cmds += [
        ("LDP Sessions", "show ldp session"),
        ("OSPF Neighbors", "show ospf neighbor"),
    ]
    for slot in CES_SLOTS:
        cmds.append(("DS1 Physical Status -- {}".format(slot),
                     "show interfaces physical status slot {}".format(slot)))
    cmds += [
        ("NE Alarms", "show ne alarms"),
        ("Chassis Alarms", "show chassis alarms"),
        ("NE Events", "show ne events"),
        ("NE Events Unreported", "show ne events unreported"),
    ]
    return cmds


# Launcher menu metadata (read by launcher.py auto-discovery).
TOOL_INFO = {
    'name': '1250 Health Check',
    'ran_from': '1250',
    'desc': 'High-level 1250 health: version, interfaces, fiber transceivers, LDP/OSPF, DS1 status across CES slots, alarms and events.',
    'requires': '1250 IP, creds',
    'order': 50,
}


def collect_inputs(session=None):
    """Prompt for inputs; return params dict (or None to abort)."""
    import getpass
    session = session if session is not None else {}

    default_ip = session.get("ip_1250")
    prompt = "1250 IP" + (" [{}]".format(default_ip) if default_ip else "")
    ip = input(prompt + ": ").strip()
    if not ip and default_ip:
        ip = default_ip
    if not ip:
        print("No IP.")
        return None

    jira_ticket = None
    if input("Add to JIRA? (y/n) [n]: ").strip().lower() in ("y", "yes"):
        while True:
            jira_ticket = input("JIRA number (NOE-XXXX): ").strip().upper()
            if valid_ticket(jira_ticket):
                break
            if not jira_ticket:
                print("  (blank -- skipping JIRA)")
                jira_ticket = None
                break
            print("  Invalid format. Expected NOE-XXXX (e.g. NOE-1234).")

    open_when_done = input("Open results file when done? (y/n) [y]: ").strip().lower()
    open_when_done = open_when_done in ("", "y", "yes")

    user = session.get("infra_user")
    pw   = session.get("infra_pass")
    if not (user and pw):
        user = input("Username: ").strip()
        pw   = getpass.getpass("Password: ")
    if not (user and pw):
        print("Missing credentials.")
        return None

    return {
        "ip_1250": ip,
        "username": user,
        "password": pw,
        "jira_ticket": jira_ticket,
        "open_when_done": open_when_done,
    }


def run(params):
    """Execute the health check given a params dict (no prompting)."""
    if _DEP_ERROR:
        print("[!] {} -- tool unavailable.".format(_DEP_ERROR))
        return

    ip = params["ip_1250"]
    user = params["username"]
    pw   = params["password"]
    jira_ticket    = params.get("jira_ticket")
    open_when_done = params.get("open_when_done", True)

    c = NPT1250Client(ip, user, pw)
    print("\n[connecting] {}".format(ip))
    try:
        c.connect()
    except CredentialError:
        raise
    except Exception as e:
        print("[!] connect failed: {}: {}".format(type(e).__name__, e))
        return
    host = c.hostname
    print("  host: {}".format(host))

    lines = []
    lines.append("NPT-1250 HEALTH CHECK")
    lines.append("Host: {}  IP: {}".format(host, ip))
    lines.append("=" * 64)

    # Sections too verbose for the console -- written to the .txt/JIRA only.
    # (NE event logs can be hundreds of lines; user reads those in the file.)
    CONSOLE_SUPPRESS = {"NE Events", "NE Events Unreported"}
    console_lines = list(lines)   # console gets a copy sans the suppressed blocks

    for title, cmd in _build_command_list():
        print("  collecting: {}".format(title))
        raw = c.run(cmd + " | no-more")
        block = ["", "=" * 64, "  {}".format(title), "  CMD: {}".format(cmd), "=" * 64]
        body = [ln.rstrip() for ln in raw.splitlines() if ln.rstrip()]
        if body:
            block.extend("  {}".format(ln) for ln in body)
        else:
            block.append("  (no output)")
        lines.extend(block)
        if title in CONSOLE_SUPPRESS:
            # console: show the header + a pointer, not the full dump
            console_lines.extend(["", "=" * 64, "  {}".format(title),
                                  "  CMD: {}".format(cmd), "=" * 64,
                                  "  (omitted from console -- see .txt / JIRA)"])
        else:
            console_lines.extend(block)

    c.close()

    # Echo the report to the console (verbose event logs suppressed above).
    print("")
    print("\n".join(console_lines))

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = r"C:\Claude\health_check_{}_{}.txt".format(ts, host)
    try:
        with open(out_path, "w") as f:
            f.write("\n".join(lines))
        print("\n[written] {}".format(out_path))
    except Exception as e:
        print("\n[!] write failed: {}".format(e))
        return

    if jira_ticket:
        print("\n[JIRA] Posting to {} ...".format(jira_ticket))
        intro = "NPT-1250 health check -- {} ({}), run {}.".format(
            host, ip, datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
        ok, msg = post_report(
            jira_ticket, intro, "NPT-1250 Health Check -- {}".format(host),
            "\n".join(lines), attach_path=out_path)
        print("[JIRA] {}".format(msg) if ok else "[JIRA] FAILED: {}".format(msg))

    if open_when_done:
        try:
            os.startfile(out_path)
        except Exception as e:
            print("[!] could not auto-open: {}".format(e))


def main():
    print("=" * 64)
    print("  NPT-1250 HEALTH CHECK (standalone)")
    print("=" * 64)
    params = collect_inputs()
    if params:
        run(params)


if __name__ == "__main__":
    main()
