# Curveball Tools — Changelog

---

## v1.12 — 2026-08-04

### New Tools
- **ospf_events.py** — `OSPF Events + Fiber Levels` (launcher order 45)
  - Pulls `show ne events unreported` and filters in Python for OSPF state changes
  - Separate sections for DOWN events and FULL/UP events; catch-all for other OSPF lines
  - Also checks fiber transceiver light levels on ts2 and ts5 (TX/RX power)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post and auto-open

### Bug Fixes
- **jira_client.py** — JIRA `CONTENT_LIMIT_EXCEEDED` fallback
  - When a report is too large to post as a comment (HTTP 400), the script now:
    1. Posts a short stub comment noting the attachment
    2. Uploads the `.txt` output file directly as a JIRA attachment
  - Affects all tools: autotester, health check, fiber util, DS1 PMs, interface check, discovery, and the new OSPF events tool

---

## v1.11 — (prior release)

*(No changelog maintained before v1.12 — see git history or `!Revisions/` zip archive for earlier changes.)*
