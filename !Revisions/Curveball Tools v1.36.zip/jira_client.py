#!/usr/bin/env python3
"""
jira_client.py -- post Autotester results to a JIRA ticket as a comment.

Port of the SecureCRT JIRA integration, using requests (not PowerShell).
Posts an ADF (Atlassian Document Format) comment via API v3 with two collapsed
expand panels:
    "Test Results -- Run Summary & Diagnostic"  (run summary + diagnostic summary)
    "Per-DS1 Performance Monitors"              (per-DS1 PMs)

Creds (JIRA_EMAIL, JIRA_TOKEN) read from autotester_config.txt; caller may pass
them in instead. Ticket format: NOE-XXXX.

Fallback: if JIRA returns CONTENT_LIMIT_EXCEEDED, the report is uploaded as a
file attachment instead (post_report / post_comment accept attach_path= for this).

Built by P. Capps.
"""

import re
import sys
import base64
import datetime
import threading

try:
    import requests
except ImportError:
    print("ERROR: requests not installed. Run:  pip install requests")
    sys.exit(1)

CONFIG_PATH = r"C:\Claude\autotester_config.txt"
JIRA_BASE   = "https://bandwidth-jira.atlassian.net"
TICKET_RE   = re.compile(r'^NOE-\d{4}$')

# Hard ceiling for the entire JIRA post. requests' timeout= only covers
# waiting for RESPONSE bytes -- it does NOT cover the upload/send phase, so
# a proxy/VPN that accepts the connection but stalls consuming a large
# upload hangs requests.post() forever. The watchdog bounds that.
JIRA_WATCHDOG_SECS = 240

# Jira Cloud rejects comment bodies past ~32k chars of text with
# CONTENT_LIMIT_EXCEEDED. Reports past this are going to be rejected
# anyway, so skip uploading the doomed multi-hundred-KB JSON (the exact
# payload most likely to trigger the send-phase stall above) and go
# straight to stub-comment + file attachment.
COMMENT_TEXT_LIMIT = 30000


def _bounded(fn, timeout=JIRA_WATCHDOG_SECS):
    """Run fn() (returns (ok, msg)) in a watchdog thread. If it doesn't
    finish in `timeout` seconds, report failure instead of hanging the
    caller forever. The stuck thread is daemonized and abandoned."""
    result = {}

    def _run():
        try:
            result["val"] = fn()
        except Exception as e:
            result["val"] = (False, "JIRA post crashed: {}: {}".format(
                type(e).__name__, e))

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return False, ("TIMED OUT after {}s -- network stall talking to "
                       "JIRA (send-phase hang; large upload through a "
                       "proxy is the usual cause). The report file is "
                       "saved locally -- attach it manually.".format(timeout))
    return result.get("val", (False, "JIRA post returned nothing."))


def load_jira_config(path=CONFIG_PATH):
    email = token = ""
    try:
        with open(path, "r") as cfg:
            for line in cfg:
                line = line.strip()
                if line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                if key == "JIRA_EMAIL":
                    email = val.strip()
                elif key == "JIRA_TOKEN":
                    token = val.strip()
    except FileNotFoundError:
        pass
    return email, token


def valid_ticket(ticket):
    return bool(TICKET_RE.match((ticket or "").strip().upper()))


def _build_adf(host_1250, ds1_count, results_text, pm_text):
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    return {
        "version": 1,
        "type": "doc",
        "content": [
            {
                "type": "paragraph",
                "content": [{
                    "type": "text",
                    "text": "Autotester results for {} -- {} DS1(s) tested on {}.".format(
                        host_1250, ds1_count, stamp)
                }]
            },
            {
                "type": "expand",
                "attrs": {"title": "Test Results -- Run Summary & Diagnostic"},
                "content": [{
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{"type": "text", "text": results_text}]
                }]
            },
            {
                "type": "expand",
                "attrs": {"title": "Per-DS1 Performance Monitors"},
                "content": [{
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{"type": "text", "text": pm_text}]
                }]
            }
        ]
    }


def attach_file(ticket, file_path, email=None, token=None):
    """
    Upload file_path as an attachment to ticket.
    Returns (ok, message).
    """
    ticket = (ticket or "").strip().upper()
    if not valid_ticket(ticket):
        return False, "Invalid ticket format '{}'".format(ticket)

    if not (email and token):
        cfg_email, cfg_token = load_jira_config()
        email = email or cfg_email
        token = token or cfg_token
    if not (email and token):
        return False, "Missing JIRA credentials."

    cred = base64.b64encode("{}:{}".format(email, token).encode("ascii")).decode("ascii")
    url  = "{}/rest/api/3/issue/{}/attachments".format(JIRA_BASE, ticket)
    headers = {
        "Authorization":      "Basic {}".format(cred),
        "X-Atlassian-Token":  "no-check",
        "Accept":             "application/json",
    }
    try:
        import os as _os
        fname = _os.path.basename(file_path)
        with open(file_path, "rb") as fh:
            r = requests.post(url, headers=headers,
                              files={"file": (fname, fh, "text/plain")},
                              timeout=60)
    except Exception as e:
        return False, "Attach request failed: {}: {}".format(type(e).__name__, e)

    if r.status_code in (200, 201):
        return True, "File attached to {}".format(ticket)
    return False, "Attach returned HTTP {} -- {}".format(r.status_code, (r.text or "")[:300])


def _fallback_attach(ticket, short_note, file_path, cred):
    """
    Called when a comment post hits CONTENT_LIMIT_EXCEEDED.
    Posts a brief stub comment then uploads the file as an attachment.
    Returns (ok, message).
    """
    import os as _os
    fname = _os.path.basename(file_path) if file_path else "report.txt"

    # Brief stub comment so the ticket shows something.
    stub_adf = {
        "version": 1,
        "type": "doc",
        "content": [{
            "type": "paragraph",
            "content": [{"type": "text",
                         "text": "{} -- Report too large for inline comment; see attached file: {}.".format(
                             short_note, fname)}]
        }]
    }
    url = "{}/rest/api/3/issue/{}/comment".format(JIRA_BASE, ticket)
    headers = {
        "Authorization": "Basic {}".format(cred),
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }
    try:
        print("[JIRA] posting stub comment ...")
        requests.post(url, json={"body": stub_adf}, headers=headers, timeout=30)
    except Exception:
        pass  # stub comment failure is non-fatal; attachment is what matters

    if not file_path:
        return False, "Report too large for a comment and no attach_path provided -- cannot attach."

    try:
        import os as _os2
        size_kb = _os2.path.getsize(file_path) // 1024
        print("[JIRA] uploading attachment {} ({} KB) ...".format(fname, size_kb))
    except OSError:
        print("[JIRA] uploading attachment {} ...".format(fname))
    ok, msg = attach_file(ticket, file_path)
    if ok:
        return True, "Comment too large -- attached {} to {} instead".format(fname, ticket)
    return False, "Report too large for a comment and attach also failed: {}".format(msg)


def post_comment(ticket, host_1250, ds1_count, results_text, pm_text,
                 email=None, token=None, attach_path=None):
    """
    Post the results as an ADF comment. Returns (ok, message).
    Bounded by a watchdog -- never hangs the caller past JIRA_WATCHDOG_SECS.
    """
    return _bounded(lambda: _post_comment_impl(
        ticket, host_1250, ds1_count, results_text, pm_text,
        email, token, attach_path))


def _post_comment_impl(ticket, host_1250, ds1_count, results_text, pm_text,
                       email=None, token=None, attach_path=None):
    ticket = (ticket or "").strip().upper()
    if not valid_ticket(ticket):
        return False, "Invalid ticket format '{}' (expected NOE-XXXX)".format(ticket)

    if not (email and token):
        cfg_email, cfg_token = load_jira_config()
        email = email or cfg_email
        token = token or cfg_token
    if not (email and token):
        return False, "Missing JIRA credentials (JIRA_EMAIL / JIRA_TOKEN)."

    cred = base64.b64encode("{}:{}".format(email, token).encode("ascii")).decode("ascii")

    # Size pre-check: reports past the comment limit are guaranteed to be
    # rejected -- don't upload the doomed JSON, go straight to attachment.
    total_chars = len(results_text or "") + len(pm_text or "")
    if total_chars > COMMENT_TEXT_LIMIT:
        print("[JIRA] report text ~{} KB -- over the inline comment limit, "
              "posting stub comment + file attachment instead".format(
                  total_chars // 1024))
        note = "Autotester results -- {} ({} DS1s)".format(host_1250, ds1_count)
        return _fallback_attach(ticket, note, attach_path, cred)

    adf = _build_adf(host_1250, ds1_count, results_text, pm_text)
    url = "{}/rest/api/3/issue/{}/comment".format(JIRA_BASE, ticket)
    headers = {
        "Authorization": "Basic {}".format(cred),
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        r = requests.post(url, json={"body": adf}, headers=headers, timeout=30)
    except Exception as e:
        return False, "JIRA request failed: {}: {}".format(type(e).__name__, e)

    if r.status_code in (200, 201):
        return True, "Comment posted to {}".format(ticket)
    if r.status_code == 400 and "CONTENT_LIMIT_EXCEEDED" in r.text:
        print("[JIRA] comment rejected for size -- falling back to attachment")
        note = "Autotester results -- {} ({} DS1s)".format(host_1250, ds1_count)
        return _fallback_attach(ticket, note, attach_path, cred)
    return False, "JIRA returned HTTP {} -- {}".format(
        r.status_code, (r.text or "")[:300])


def _build_report_adf(intro, panel_title, report_text):
    """Single intro paragraph + one collapsed panel holding the full report."""
    return {
        "version": 1,
        "type": "doc",
        "content": [
            {
                "type": "paragraph",
                "content": [{"type": "text", "text": intro}]
            },
            {
                "type": "expand",
                "attrs": {"title": panel_title},
                "content": [{
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{"type": "text", "text": report_text}]
                }]
            }
        ]
    }


def post_report(ticket, intro, panel_title, report_text, email=None, token=None, attach_path=None):
    """
    General-purpose single-panel post for the auxiliary tools (discovery,
    DS1 PMs, interface check). Returns (ok, message).
      intro       -- one-line summary shown in the comment body
      panel_title -- title of the collapsed panel
      report_text -- the full report (goes in the collapsed code block)
    Bounded by a watchdog -- never hangs the caller past JIRA_WATCHDOG_SECS.
    """
    return _bounded(lambda: _post_report_impl(
        ticket, intro, panel_title, report_text, email, token, attach_path))


def _post_report_impl(ticket, intro, panel_title, report_text,
                      email=None, token=None, attach_path=None):
    ticket = (ticket or "").strip().upper()
    if not valid_ticket(ticket):
        return False, "Invalid ticket format '{}' (expected NOE-XXXX)".format(ticket)

    if not (email and token):
        cfg_email, cfg_token = load_jira_config()
        email = email or cfg_email
        token = token or cfg_token
    if not (email and token):
        return False, "Missing JIRA credentials (JIRA_EMAIL / JIRA_TOKEN)."

    cred = base64.b64encode("{}:{}".format(email, token).encode("ascii")).decode("ascii")

    # Size pre-check -- same rationale as _post_comment_impl.
    if len(report_text or "") > COMMENT_TEXT_LIMIT:
        print("[JIRA] report text ~{} KB -- over the inline comment limit, "
              "posting stub comment + file attachment instead".format(
                  len(report_text) // 1024))
        return _fallback_attach(ticket, intro, attach_path, cred)

    adf = _build_report_adf(intro, panel_title, report_text)
    url = "{}/rest/api/3/issue/{}/comment".format(JIRA_BASE, ticket)
    headers = {
        "Authorization": "Basic {}".format(cred),
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        r = requests.post(url, json={"body": adf}, headers=headers, timeout=30)
    except Exception as e:
        return False, "JIRA request failed: {}: {}".format(type(e).__name__, e)

    if r.status_code in (200, 201):
        return True, "Comment posted to {}".format(ticket)
    if r.status_code == 400 and "CONTENT_LIMIT_EXCEEDED" in r.text:
        print("[JIRA] comment rejected for size -- falling back to attachment")
        return _fallback_attach(ticket, intro, attach_path, cred)
    return False, "JIRA returned HTTP {} -- {}".format(
        r.status_code, (r.text or "")[:300])
