#!/usr/bin/env python3
"""
gsx_client.py -- GSX9000 client (plink), importable module.

Extracted from the proven gsx_prover.py. Uses PuTTY plink (NOT paramiko) because
the GSX offers only ssh-dss (512-bit DSA), which paramiko/cryptography reject.
Drives an interactive plink session via subprocess pipes with a byte-reader
thread (no readline deadlock on the newline-less prompt).

In the orchestrator, the node/slot/port/t1 come FROM the MUX hop -- never
entered by hand. mgmt IPs come from Netbox; ping picks the live card.

Built by P. Capps.
"""

import re
import os
import sys
import time
import json
import subprocess
import threading

import platform_paths

PLINK_CANDIDATES = [
    "plink",
    r"C:\Program Files\PuTTY\plink.exe",
    r"C:\Program Files (x86)\PuTTY\plink.exe",
]

PING_TIMEOUT_MS = 1000
SESSION_TIMEOUT = 45
READ_IDLE = 0.4

# Local fingerprint store (Tier 1 TOFU + change detection). Upgradeable to
# Netbox-sourced known-good fingerprints later (Tier 2).
HOSTKEY_STORE = platform_paths.path("gsx_hostkeys.json")


def find_plink():
    for cand in PLINK_CANDIDATES:
        try:
            r = subprocess.run([cand, "-V"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0 or "plink" in (r.stdout + r.stderr).lower():
                return cand
        except Exception:
            continue
    return None


def ping_host(ip):
    """
    One-shot local-OS ping (NOT a device CLI command -- this runs on whatever
    host the tool itself is executing on, to find the live GSX mgmt card
    before SSHing in).

    Flags are OS-specific and were Windows-only before 2026-09-11 (-n/-w),
    silently broken the first time this ran on Linux (noe-util-01a) -- Linux
    ping uses -c/-W with a different timeout unit (whole seconds, not ms).
    Exit code is the primary success signal (0 = at least one reply, on both
    platforms) since it's the one thing that doesn't depend on locale/output
    format; the string checks are kept only as a belt-and-suspenders fallback.
    """
    try:
        if os.name == "nt":
            cmd = ["ping", "-n", "1", "-w", str(PING_TIMEOUT_MS), ip]
        else:
            timeout_s = max(1, int(round(PING_TIMEOUT_MS / 1000.0)))
            cmd = ["ping", "-c", "1", "-W", str(timeout_s), ip]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        out = result.stdout.lower()
        return (result.returncode == 0) or ("ttl=" in out) or ("received = 1" in out)
    except Exception:
        return False


def find_live_ip(cards):
    """cards = {"1-1":[ips], "1-2":[ips]} -> (card_key, ip) or (None, None).

    PING ONLY. A GSX can answer ICMP and still refuse SSH ("Connection
    refused" out of plink), so a pingable IP is not a usable IP. Callers that
    are about to log in should use connect_first_live() instead; this remains
    for callers that only need an address to print in a runbook.
    """
    for card_key in sorted(cards.keys()):
        for ip in cards[card_key]:
            if ping_host(ip):
                return card_key, ip
    return None, None


def connect_first_live(cards, username, password, plink_path, progress=None):
    """
    Return (card_key, ip, connected_client) for the first mgmt IP that both
    pings AND accepts SSH -- or (None, None, None) if none do.

    WHY: ping success does not imply SSH. Observed 2026-10-01 on ATLGSX02
    (192.168.40.5) -- ICMP fine, plink died at login with "Network error:
    Connection refused", and because the old path committed to the first
    PINGABLE address, every DS1 on that card failed with the same error
    instead of trying the next management IP.

    The successful client is returned OPEN so the caller reuses this
    connection rather than logging in a second time. Failed attempts are
    closed here. Nothing is cached to disk -- trial and error every run, by
    request, so no address list can go stale.

    `progress` (optional) is called with a one-line note per failed IP, so a
    primary that is always refusing SSH is visible rather than silently
    routed around.
    """
    tried = []
    for card_key in sorted(cards.keys()):
        for ip in cards[card_key]:
            if not ping_host(ip):
                tried.append("{} no ping".format(ip))
                continue
            c = GSXClient(ip, username, password, plink_path)
            try:
                c.connect()
                if tried and progress:
                    progress("     GSX {} reached on {} after skipping: {}"
                             .format(card_key, ip, "; ".join(tried)))
                return card_key, ip, c
            except Exception as e:
                tried.append("{} SSH failed ({})".format(
                    ip, type(e).__name__))
                if progress:
                    progress("     [!] GSX {} pings but SSH failed: {} -- "
                             "trying next mgmt IP".format(ip, e))
                try:
                    c.close()
                except Exception:
                    pass
    if progress and tried:
        progress("     [!] no usable GSX mgmt IP. Tried: {}".format(
            "; ".join(tried)))
    return None, None, None


# ---- Tier 1 host-key fingerprint store (TOFU + change detection) ----

def _load_hostkey_store():
    try:
        with open(HOSTKEY_STORE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_hostkey_store(store):
    try:
        d = os.path.dirname(HOSTKEY_STORE)
        if d and not os.path.exists(d):
            os.makedirs(d)
        with open(HOSTKEY_STORE, "w") as f:
            json.dump(store, f, indent=2)
    except Exception:
        pass


# plink prints e.g.:  The server's dss key fingerprint is:
#                       ssh-dss 512 SHA256:RuzhN9i5U6oBd62FBklVpI34S1stmmS97Uqq...
_FP_RE = re.compile(r'(ssh-\w+\s+\d+\s+SHA256:[A-Za-z0-9+/=]+)')


def capture_fingerprint(plink_path, ip, username, password, timeout=20):
    """
    Phase-1: throwaway connect that provokes the host-key line, parse and return
    the fingerprint string plink reports (e.g. 'ssh-dss 512 SHA256:...') or None.

    plink 0.82+ ignores piped y/n for the host-key prompt (needs
    -legacy-stdio-prompts), so we do NOT try to answer it. We just read plink's
    output in a BACKGROUND THREAD (so a blocking read at the newline-less prompt
    can't deadlock us), grab the fingerprint, then kill the process.
    """
    try:
        proc = subprocess.Popen(
            [plink_path, "-ssh", "{}@{}".format(username, ip),
             "-pw", password, "-legacy-stdio-prompts", "exit"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, bufsize=0)
    except Exception:
        return None

    buf = {"data": ""}
    lock = threading.Lock()
    stop = {"flag": False}

    def _pump():
        while not stop["flag"]:
            try:
                b = proc.stdout.read(1)
            except Exception:
                return
            if not b:
                return
            with lock:
                buf["data"] += b.decode("ascii", errors="ignore")

    t = threading.Thread(target=_pump, daemon=True)
    t.start()

    fp = None
    answered = False
    deadline = time.time() + timeout
    while time.time() < deadline:
        with lock:
            snap = buf["data"]
        m = _FP_RE.search(snap)
        if m and not fp:
            fp = m.group(1)
        # With -legacy-stdio-prompts, plink 0.82+ reads the y/n from stdin.
        # Answer 'n' (do NOT cache in registry -- we pin via -hostkey instead)
        # once we've captured the fingerprint, so the throwaway exits cleanly.
        if fp and not answered and "Store key in cache" in snap:
            try:
                proc.stdin.write(b"n\n")
                proc.stdin.flush()
            except Exception:
                pass
            answered = True
            break
        if m and proc.poll() is not None:
            break
        if proc.poll() is not None and not m:
            break
        time.sleep(0.1)

    stop["flag"] = True
    try:
        proc.kill()
    except Exception:
        pass
    return fp


_PROMPT_NODE_RE = re.compile(r'^([A-Za-z][\w.\-]*)>\s*$')
_NODE_HEADER_RE = re.compile(r'^\s*Node:\s*([\w.\-]+)', re.MULTILINE)


def node_from_prompt(banner):
    """
    Pull the node name out of a GSX login banner: 'ATLGSX02>' -> 'ATLGSX02'.

    Scans from the BOTTOM up -- the prompt is the last line, and a login
    banner can contain anything above it. Returns "" when no prompt line is
    present rather than guessing from banner text.
    """
    for line in reversed((banner or "").splitlines()):
        m = _PROMPT_NODE_RE.match(line.strip())
        if m:
            return m.group(1)
    return ""


def node_from_output(text):
    """
    Second source for the node name: every GSX command's output starts with a
    'Node: ATLGSX02    Date: ...' header. Lets a caller name the node from
    output it has ALREADY pulled, with no extra command -- used as the
    fallback when the prompt could not be read.
    """
    m = _NODE_HEADER_RE.search(text or "")
    return m.group(1) if m else ""


def parse_isup_service(raw):
    """
    The ISUP service / trunk-group name from SHOW ISUP CIRCUIT output.

    The table row is e.g.:
        Port DS1 ISUP Service              CIC  Ch Status   ...
        ---- --- ------------------------ ----- -- -------- ...
        1    16  PSN_440_AT_TF_AC739432   5025  1  UNEQUIP  ...

    Every data row repeats the same service name; return the first one. The
    name is a single token (letters, digits, underscores) in the third
    column. Returns None when no data row is present (empty circuit, command
    error, unrecognised output) rather than guessing.
    """
    if not raw:
        return None
    for line in raw.splitlines():
        # A data row starts with port and DS1 integers, then the name.
        m = re.match(r'\s*\d+\s+\d+\s+([A-Za-z0-9_]+)\s', line)
        if m:
            name = m.group(1)
            # Guard against matching a header/separator token.
            if name.lower() not in ("isup", "service", "status"):
                return name
    return None


def node_names_match(a, b):
    """
    Do two GSX node names refer to the same device?

    Compares the first dot-label, case-insensitively: 'ATLGSX02' and
    'atlgsx02.bandwidth.com' are the same node. Returns False when either
    side is empty -- an unknown name is not a match, and must not be reported
    as agreement.

    Used to cross-check the node the MUX's port description claims against
    the name the GSX gives at login. Deliberately does NOT try to normalise
    anything beyond case and domain: if the two differ in any other way,
    that difference is the finding.
    """
    def norm(s):
        return (s or "").strip().split(".")[0].upper()
    na, nb = norm(a), norm(b)
    return bool(na) and na == nb


class GSXClient:
    # Full pager line: "--- Press <space> for next page, <c>ontinuous, or <q>uit ---"
    # Match the surrounding dashes too, so no "---  ---" remnant is left behind.
    PAGER_RE   = re.compile(r'-*\s*Press <space>.*?<q>uit\s*-*', re.IGNORECASE)
    PROMPT_RE  = re.compile(r'[\w.\-]+>\s*$')
    # Some SHOW commands (SHOW ISUP CIRCUIT) warn they take a few seconds and
    # ask "continue? - Confirm (y/n):". Answered 'y' automatically, the same
    # way the pager is answered 'c'. These are READ commands -- the confirm is
    # about runtime, not about changing anything.
    CONFIRM_RE = re.compile(r'Confirm\s*\(y/n\)\s*:?\s*$', re.IGNORECASE)
    HOSTKEY_RE = re.compile(r'Store key in cache', re.IGNORECASE)

    def __init__(self, ip, username, password, plink_path=None):
        self.ip = ip
        self.username = username
        self.password = password
        self.plink_path = plink_path or find_plink()
        self.proc = None
        self._buf = ""
        self._lock = threading.Lock()
        self._reader = None
        self._stop = False
        # Node name, read from the login prompt by connect().
        #
        # ⚠ GSXClient is NOT a DeviceBase subclass -- it talks to plink
        # directly -- so it does NOT inherit DeviceBase._capture_hostname().
        # Until 2026-10-01 it had no `hostname` attribute at all, which meant
        # `getattr(g, "hostname", "")` (reverse_autotester hop 1) silently
        # returned "" on EVERY run, not just on failures. Kept named
        # `hostname` to match DeviceBase so callers can treat the two the
        # same.
        self.hostname = ""

    def _spawn(self, hostkey=None):
        args = [self.plink_path, "-ssh", "{}@{}".format(self.username, self.ip),
                "-pw", self.password]
        if hostkey:
            # plink -hostkey wants the bare fingerprint form (e.g. "SHA256:...").
            # We store the full "ssh-dss 512 SHA256:..." string for readability;
            # extract just the SHA256:... token for the flag.
            m = re.search(r'(SHA256:[A-Za-z0-9+/=]+)', hostkey)
            hk_arg = m.group(1) if m else hostkey
            # Pin the exact host key -- plink accepts silently, no prompt, and
            # REFUSES if the device presents a different key (change detection).
            args += ["-hostkey", hk_arg]
        # -batch: never prompt interactively. With -hostkey supplying the
        # accepted key, plink connects silently; if anything's off it FAILS
        # (clean exit) instead of hanging at a prompt (plink 0.82+ ignores
        # piped prompt answers anyway).
        args += ["-batch"]
        self.proc = subprocess.Popen(
            args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, bufsize=0)
        self._stop = False

        def _pump():
            while not self._stop:
                b = self.proc.stdout.read(1)
                if not b:
                    return
                with self._lock:
                    self._buf += b.decode("ascii", errors="ignore")

        self._reader = threading.Thread(target=_pump, daemon=True)
        self._reader.start()

    def _snapshot(self):
        with self._lock:
            return self._buf

    def _consume(self):
        with self._lock:
            data = self._buf
            self._buf = ""
            return data

    def _send(self, s):
        self.proc.stdin.write(s.encode("ascii"))
        self.proc.stdin.flush()

    def _wait_for_prompt(self, timeout):
        deadline = time.time() + timeout
        while time.time() < deadline:
            snap = self._snapshot()
            # With -hostkey pinning we should NOT see the cache prompt. If we
            # somehow do, it means no/mismatched key -- don't blindly accept.
            if self.PAGER_RE.search(snap):
                self._send("c")
                with self._lock:
                    self._buf = self.PAGER_RE.sub("", self._buf)
                time.sleep(0.2)
                deadline = time.time() + timeout
                continue
            tail = snap.rstrip().splitlines()[-1] if snap.strip() else ""
            # A "Confirm (y/n):" prompt only appears on the tail line, waiting
            # for input -- answer 'y' and reset the clock, since the command
            # warned it may take several seconds after confirmation.
            if self.CONFIRM_RE.search(tail):
                self._send("y\n")
                with self._lock:
                    self._buf = ""
                time.sleep(0.3)
                deadline = time.time() + timeout
                continue
            if self.PROMPT_RE.search(tail):
                return snap
            if self.proc.poll() is not None:
                return snap
            time.sleep(READ_IDLE)
        return self._snapshot()

    def _resolve_hostkey(self):
        """
        Tier 1: return the fingerprint to pin for this GSX.
        - If stored: return it (subsequent runs pin against the known value).
        - If not stored: capture it (TOFU), store it, return it.
        Raises on a key CHANGE (stored != what the device now presents).
        Returns the fingerprint string, or None if capture failed.
        """
        store = _load_hostkey_store()
        stored = store.get(self.ip)

        # Always capture what the device currently presents so we can detect
        # changes even when we have a stored value.
        current = capture_fingerprint(self.plink_path, self.ip,
                                      self.username, self.password)

        if stored and current and stored != current:
            raise RuntimeError(
                "GSX HOST KEY CHANGED for {}!\n"
                "  stored:  {}\n"
                "  current: {}\n"
                "Refusing to connect. If this device was legitimately replaced, "
                "remove its entry from {} and re-run.".format(
                    self.ip, stored, current, HOSTKEY_STORE))

        if stored and not current:
            # Couldn't re-capture (transient); trust the stored value.
            return stored

        if current and not stored:
            # TOFU: first contact -- record it.
            store[self.ip] = current
            _save_hostkey_store(store)
            return current

        # both present and equal
        return stored or current

    def connect(self):
        if not self.plink_path:
            raise RuntimeError("plink not found. Install PuTTY or add plink to PATH.")
        hostkey = self._resolve_hostkey()   # Tier 1: pin/capture + change detect
        self._spawn(hostkey=hostkey)
        banner = self._wait_for_prompt(SESSION_TIMEOUT)
        if self.proc.poll() is not None:
            if re.search(r'access denied|authentication fail|wrong password|'
                         r'permission denied|incorrect password',
                         banner, re.IGNORECASE):
                from device_base import CredentialError
                raise CredentialError(
                    "GSX authentication failed for '{}' on {} -- wrong username or password.".format(
                        self.username, self.ip),
                    cred_type='gsx')
            raise RuntimeError("plink exited during login. Output:\n{}".format(banner))
        self.hostname = node_from_prompt(banner)
        self._consume()
        return banner

    def run_command(self, cmd):
        self._consume()
        self._send(cmd + "\n")
        time.sleep(0.3)
        raw = self._wait_for_prompt(SESSION_TIMEOUT)
        cleaned = []
        for ln in raw.splitlines():
            s = ln.rstrip()
            if not s:
                continue
            if cmd in s:
                continue
            if self.PROMPT_RE.search(s):
                continue
            # Defensive: drop any leftover pager fragment (a line that is only
            # dashes/spaces, e.g. a "---  ---" remnant from a split pager line).
            if re.match(r'^[-\s]*$', s) and "-" in s and len(s.strip("- ")) == 0:
                # keep genuine separator lines (long solid dashes) but drop the
                # short split-pager remnants like "---  ---"
                if "  " in s:   # remnant has a gap where the text was removed
                    continue
            cleaned.append(s)
        return "\n".join(cleaned)

    def pull_isup_circuit(self, slot, port, ds1):
        """
        ISUP circuit + trunk-group detail for a GSX T1, read-only.

        Two commands, for information only (requested for mgmt/Barlow,
        2026-11-02):

          SHOW ISUP CIRCUIT SHELF 1 SLOT <s> PORT <p> DS1 <d> status
          show trunk group <trunk-name> admin

        The trunk name is NOT known in advance -- it is the "ISUP Service"
        column of the first command's output (e.g. PSN_440_AT_TF_AC739432),
        which is also the ISUP circuit ID the summary line wants. So the
        first command is run, the name parsed, then the second run.

        Returns a dict:
          {"isup_id":   <trunk name or None>,
           "isup_raw":  <full SHOW ISUP CIRCUIT output>,
           "trunk_raw": <full show trunk group output, or a note>}

        Never raises -- a failure here must not take down the GSX hop, which
        has already produced the real diagnostic data. Errors are recorded in
        the raw fields.
        """
        out = {"isup_id": None, "isup_raw": "", "trunk_raw": ""}
        try:
            out["isup_raw"] = self.run_command(
                "SHOW ISUP CIRCUIT SHELF 1 SLOT {} PORT {} DS1 {} status"
                .format(slot, port, ds1))
        except Exception as e:
            out["isup_raw"] = "[command error: {}]".format(e)
            return out

        out["isup_id"] = parse_isup_service(out["isup_raw"])
        if not out["isup_id"]:
            out["trunk_raw"] = ("[no ISUP service/trunk name found in the "
                                "SHOW ISUP CIRCUIT output -- trunk group not "
                                "queried]")
            return out
        try:
            out["trunk_raw"] = self.run_command(
                "show trunk group {} admin".format(out["isup_id"]))
        except Exception as e:
            out["trunk_raw"] = "[command error: {}]".format(e)
        return out

    def get_t3_status(self, slot, port):
        """
        Pull just SHOW T3 STATUS for the parent T3 of a given slot/port.
        Used by the autotester to distinguish T3-level outage from DS1-specific
        failure (if T3 is DOWN, all 28 T1s on that port are affected by the
        same root cause -- one ticket, not 28).
        Returns the raw output string.
        """
        t3_id = "T3-1-{}-{}".format(slot, port)
        try:
            return self.run_command("SHOW T3 {} STATUS".format(t3_id))
        except Exception as e:
            return "[command error: {}]".format(e)

    def pull_t3_stats(self, slot, port):
        """
        Pull the standard T3 command set for a given slot/port.
        Returns list of (label, cmd, output).
        """
        t3_id = "T3-1-{}-{}".format(slot, port)
        commands = [
            ("STATUS",              "SHOW T3 {} STATUS".format(t3_id)),
            ("ADMIN",               "SHOW T3 {} ADMIN".format(t3_id)),
            ("STATISTICS",          "SHOW T3 {} STATISTICS".format(t3_id)),
            ("PERFMON CURRENT DAY", "SHOW T3 {} PERFMON CURRENT DAY".format(t3_id)),
            ("PERFMON THRESHOLDS",  "SHOW T3 {} PERFMON THRESHOLDS".format(t3_id)),
        ]
        out = []
        for label, cmd in commands:
            try:
                res = self.run_command(cmd)
            except Exception as e:
                res = "[command error: {}]".format(e)
            out.append((label, cmd, res))
        return out

    def pull_t1_stats(self, slot, port, t1):
        """
        Pull the standard T1 command set for a given slot/port/t1.
        Returns list of (label, cmd, output). Excludes the destructive reset.
        """
        t1_id = "T1-1-{}-{}-{}".format(slot, port, t1)
        commands = [
            ("STATUS",             "SHOW T1 {} STATUS".format(t1_id)),
            # ADMIN added 2026-10-01. Configured vs operational state; an
            # admin-down T1 and a faulted T1 look the same in STATUS alone.
            ("ADMIN",              "SHOW T1 {} ADMIN".format(t1_id)),
            ("STATISTICS",         "SHOW T1 {} STATISTICS".format(t1_id)),
            ("PERFMON 15MIN",      "SHOW T1 {} PERFMON CURRENT FIFTEENMIN".format(t1_id)),
            ("PERFMON DAY",        "SHOW T1 {} PERFMON CURRENT DAY".format(t1_id)),
            ("PERFMON THRESHOLDS", "SHOW T1 {} PERFMON THRESHOLDS".format(t1_id)),
        ]
        out = []
        for label, cmd in commands:
            try:
                res = self.run_command(cmd)
            except Exception as e:
                res = "[command error: {}]".format(e)
            out.append((label, cmd, res))
        return out

    def close(self):
        try:
            if self.proc and self.proc.poll() is None:
                self._send("exit\n")
                time.sleep(0.5)
        except Exception:
            pass
        self._stop = True
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.terminate()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Self-tests for the node-name parsers. No device needed:
#   python gsx_client.py --self-test
#
# These exist because GSXClient had NO `hostname` attribute until 2026-10-01
# (it is not a DeviceBase subclass, so it never inherited
# _capture_hostname). reverse_autotester read it with
# getattr(g, "hostname", "") and therefore got "" on every single run --
# a missing attribute read through a defaulted getattr fails silently
# forever. A test that pins the parsers is the cheap half of the fix; the
# other half is that hop 1 now FAILS when the name is unknown instead of
# printing '?'.
# ---------------------------------------------------------------------------

_BANNER_SAMPLE = """Using username "pcapps".

Sonus Networks GSX9000
ATLGSX02>
"""

# First two lines of any GSX command's output (verbatim shape, ATLGSX02).
_OUTPUT_HEADER_SAMPLE = """Node: ATLGSX02                                 Date: 2026/10/01 12:09:02  GMT
                                               Zone: GMT
"""


def self_test(verbose=True):
    fails = []

    def chk(label, got, want):
        if got != want:
            fails.append("{}: got {!r} want {!r}".format(label, got, want))
        elif verbose:
            print("  ok  {} = {!r}".format(label, got))

    chk("prompt from login banner", node_from_prompt(_BANNER_SAMPLE), "ATLGSX02")
    chk("prompt bare", node_from_prompt("DFWGSX04>"), "DFWGSX04")
    chk("prompt trailing space", node_from_prompt("LAXGSX01> "), "LAXGSX01")
    chk("prompt dotted name",
        node_from_prompt("atlgsx02.bandwidth.com>"), "atlgsx02.bandwidth.com")
    # Scans bottom-up: the live prompt is the LAST one, not the first.
    chk("prompt takes the last one",
        node_from_prompt("OLDNODE>\nNEWNODE>\n"), "NEWNODE")
    chk("prompt absent", node_from_prompt("Access denied\n"), "")
    chk("prompt from empty", node_from_prompt(""), "")
    chk("prompt from None", node_from_prompt(None), "")
    # A '>' inside prose must not be read as a prompt.
    chk("prose with a > is not a prompt",
        node_from_prompt("see docs > appendix\n"), "")

    chk("Node: header", node_from_output(_OUTPUT_HEADER_SAMPLE), "ATLGSX02")
    chk("Node: header indented",
        node_from_output("   Node: DFWGSX04   Date: x"), "DFWGSX04")
    chk("no Node: header", node_from_output("Shelf: 1  Slot: 6\n"), "")
    chk("command error is not a node",
        node_from_output("[command error: timeout]"), "")
    chk("Node: from empty", node_from_output(""), "")

    # ---- ISUP circuit parsing (#8, mgmt/Barlow, 2026-11-02) ---------------
    _isup = ("Node: ATLGSX02   Date: 2026/10/16 14:20:44  GMT\n"
             "Shelf: 1  Slot: 7\n"
             "Port DS1 ISUP Service              CIC  Ch Status   Local\n"
             "---- --- ------------------------ ----- -- -------- -----\n"
             "1    16  PSN_440_AT_TF_AC739432   5025  1  UNEQUIP  BLK\n"
             "1    16  PSN_440_AT_TF_AC739432   5026  2  UNEQUIP  BLK")
    chk("ISUP service name parsed from the data row",
        parse_isup_service(_isup), "PSN_440_AT_TF_AC739432")
    chk("ISUP header/separator rows are not mistaken for a name",
        parse_isup_service("Port DS1 ISUP Service\n---- --- -----"), None)
    chk("no ISUP data row -> None", parse_isup_service("Node: X\n(empty)"), None)
    chk("ISUP from empty -> None", parse_isup_service(""), None)
    chk("the y/n confirm prompt is recognised",
        bool(GSXClient.CONFIRM_RE.search(
            "This may take several seconds, continue? - Confirm (y/n): ")),
        True)

    # ---- node_names_match: the forward autotester's identity cross-check ---
    chk("same name", node_names_match("ATLGSX02", "ATLGSX02"), True)
    chk("case differs", node_names_match("ATLGSX02", "atlgsx02"), True)
    chk("domain on one side",
        node_names_match("ATLGSX02", "atlgsx02.bandwidth.com"), True)
    chk("domain on the other side",
        node_names_match("atlgsx02.bandwidth.com", "ATLGSX02"), True)
    chk("whitespace", node_names_match("ATLGSX02", " ATLGSX02 "), True)
    # The dangerous case: one digit apart. Two real GSXs at the same site.
    chk("one digit apart is NOT a match",
        node_names_match("ATLGSX02", "ATLGSX01"), False)
    chk("different site", node_names_match("ATLGSX02", "DFWGSX04"), False)
    # An unknown name must never read as agreement.
    chk("empty is not a match (right)", node_names_match("ATLGSX02", ""), False)
    chk("empty is not a match (left)", node_names_match("", "ATLGSX02"), False)
    chk("both empty is not a match", node_names_match("", ""), False)
    chk("both None is not a match", node_names_match(None, None), False)

    print()
    if fails:
        print("FAILURES:")
        for f in fails:
            print("  " + f)
        return False
    print("All gsx_client self-tests passed.")
    return True


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        sys.exit(0 if self_test() else 1)
    print(__doc__ or "gsx_client.py -- GSX9000 SSH client. Try --self-test.")
