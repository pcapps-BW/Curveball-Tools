# Curveball Tools — Changelog

---

## v1.14 — 2026-08-04

### Bug Fixes
- **output_builders.py** — Run Summary CES reporting now shows the worst error, not the first
  - Previous logic stopped at the first CES counter it found (e.g. `RxPsnOverrunEvents=8`) even when a more severe counter was present (`RxPsnES=1627`)
  - Now scans all CES counters and reports the one with the highest value in the run summary line

---

## v1.13 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display placement corrected (NOE-4503)
  - CES PMs now appear **above** the `1250 --` identifier line (`[ !! ] CES ...` / `[ OK ] CES PMs clean`)
  - Removed the duplicate CES block that was also appearing below the `ds1-tsX/Y MUSE_XXXX` line
  - TDM PMs remain below the identifier line, unchanged
  - Fix applied to both the full route block and the peerless block

---

## v1.12 — 2026-08-04

### New Tools
- **ospf_events.py** — `OSPF Events + Fiber Levels` (launcher order 45)
  - Pulls `show ne events unreported` and filters in Python for OSPF state changes
  - Separate sections for DOWN events and FULL/UP events; catch-all for other OSPF lines
  - Also checks fiber transceiver light levels on ts2 and ts5 (TX/RX power)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post and auto-open

### Bug Fixes
- **jira_client.py** — JIRA `CONTENT_LIMIT_EXCEEDED` fallback
  - When a report is too large to post as a comment (HTTP 400), the script now:
    1. Posts a short stub comment noting the attachment
    2. Uploads the `.txt` output file directly as a JIRA attachment
  - Affects all tools: autotester, health check, fiber util, DS1 PMs, interface check, discovery, and the new OSPF events tool

---

## v1.11 — (prior release)

*(No changelog maintained before v1.12 — see git history or `!Revisions/` zip archive for earlier changes.)*
