# Curveball Tools — Changelog

---

## v1.37 — 2026-08-05

### JIRA comment -- per-DS1 brief summary, always visible
- **New `build_jira_summary()`** (`output_builders.py`): builds a compact
  per-DS1 block for the JIRA comment -- DS1 assignment as a header, that
  DS1's per-hop Clean/Dirty status on readable lines beneath it, plus any
  DS1_AIS VERDICT paragraph lifted from that DS1's diagnostic summary.
  Repeated per DS1, since each channel can have different symptoms.
- **The summary is always visible on the ticket** (`jira_client.py`,
  `autotester_standalone.py`):
  - Normal-size reports: summary appears as plain text right under the
    intro line, above the existing collapsed panels.
  - Too-large reports (the attachment fallback that fired on the 7-DS1
    run): the stub comment now carries the same visible summary -- no
    more bare "see attached file" with zero at-a-glance info. When the
    Run Summary + Diagnostic block also fits, it rides along in a
    collapsed panel underneath as before.
- Verified with synthetic 3-DS1 run (clean / route-FAIL / DS1_AIS with
  verdict): summary renders per-DS1, normal ADF = paragraph > summary >
  2 expands, fallback stub ADF = paragraph > summary > optional expand.

---

## v1.36 — 2026-08-05

### JIRA posting -- fix indefinite hang on large reports
- Symptom: multi-DS1 Autotester run stuck at "[JIRA] Posting results to
  NOE-XXXX ..." indefinitely. Root cause: requests' timeout= only covers
  waiting for RESPONSE bytes -- it does NOT bound the upload/send phase.
  A proxy/VPN that accepts the connection but stalls consuming a large
  upload (a 7-DS1 report builds a multi-hundred-KB JSON comment) blocks
  requests.post() forever, so the 30s timeout never fired. Small runs =
  small payload = worked; large runs could hang. Three fixes
  (`jira_client.py`):
  1. **Watchdog** (`_bounded()`, 240s ceiling): post_comment/post_report
     now run their network work in a bounded thread. A stall comes back
     as "[JIRA] FAILED: TIMED OUT after 240s ..." with a reminder that
     the report file is already saved locally -- the job finishes
     normally instead of hanging.
  2. **Size pre-check** (COMMENT_TEXT_LIMIT = 30k chars): reports over
     Jira's inline comment limit were guaranteed a CONTENT_LIMIT_EXCEEDED
     rejection anyway -- and that giant JSON upload was exactly the
     payload most likely to trigger the send-phase stall. Now oversized
     reports skip the comment attempt and go straight to the existing
     stub-comment + file-attachment fallback.
  3. **Progress prints** in the fallback path ("report text ~N KB --
     over the inline comment limit...", "posting stub comment ...",
     "uploading attachment X (N KB) ...") -- the JIRA phase is no longer
     silent between "Posting results ..." and the final result, so the
     web live log / console shows exactly which step it's on.
- Applies to all tools (Autotester via post_comment; the others via
  post_report). Verified watchdog timeout, fast-path passthrough, and
  size-bypass routing with synthetic tests.

---

## v1.35 — 2026-08-05

### Autotester -- DS1_AIS cross-hop correlation VERDICT
- **The static "(AIS from LEC/1250 direction ...)" note is replaced with
  an automated troubleshooting verdict** (`output_builders.py`:
  `_ais_verdict()` + `_wrap_note()`). When the MUX reports DS1_AIS, the
  diagnostic summary now correlates it against the same run's upstream
  data and prints a brief paragraph walking the logic and naming the
  next action. Finite symptom matrix, checked in priority order:
  1. 1250 TDM LOS/LOF -> LEC handoff failure (1250 is generating the
     AIS). Engage the LEC.
  2. 1250 receiving AIS -> failure deeper in the LEC network; 1250 is
     passing it through. Engage the LEC.
  3. 1250 TDM clean but middle dirty (CES/EVC/NNI/OC, named in the
     verdict) -> transport fault between 1250 and MUX; work that
     segment first.
  4. 1250 TDM errored (no hard LOS/AIS), path clean -> marginal LEC
     signal; monitor.
  5. Everything clean -> the 1800 is inserting AIS into an unequipped /
     mis-stitched VT (provisioning or mapping gap -- clean PMs are
     EXPECTED here since AIS transports without errors). Verdict names
     the exact MUSE circuit, OC/STS/T1, ACR/CEM to verify, and the MUX
     'show cem circuit' Lbits corroboration check.
- Rationale: AIS is generated at the point of failure and travels
  downstream only, so the AIS origin is fully determined by data the
  Autotester already collects in the same run (1250 TDM state, CES/EVC/
  NNI/OC health). Verified all 5 branches with synthetic inputs.
- `_wrap_note()` wraps verdicts to report width without splitting
  interface names on hyphens.

---

## v1.34 — 2026-08-05

### Autotester -- diagnose GSX node/slot/port unresolved (None-None-None-N)
- Confirmed the "FLAG: WARNING: Netbox not populated -- MUX description
  fallback used..." message only ever fires from the Tier-2 MUX-controller-
  description branch in `mux4216_client.py` -- i.e. it's proof that branch
  DID run and DID succeed (found the ACR via the MUX's SONET-ACR
  description), not the Tier-3 shotgun-guess fallback. That message and
  a Tier-3 "legacy ACR-guess used" message are mutually exclusive, so
  seeing the Tier-2 wording means Tier-2 worked.
- The separate "GSX None-None-None-N" symptom is unrelated to that --
  it comes from a second, independent description lookup (the GSX-side
  T3 controller's description, parsed for a NODE-SLOT-PORT-T1 naming
  convention like `LAXGSX04-11-2-14`) failing to resolve. Root cause is
  almost always that the T3 controller simply has no description
  configured, or one that doesn't match the expected 4-part format --
  a provisioning-documentation gap, same family of issue as an
  unpopulated Netbox entry, just on the GSX side of the MUX instead.
- `mux4216_client.py`: added a `gsx_flag` on the mux result dict --
  fires a specific warning ("no description configured" with the raw
  command output, or "doesn't match expected format" with what was
  found) whenever node/slot/port can't be derived, instead of silently
  leaving them `None` with no trail to follow.
- `autotester_standalone.py`: surfaces `gsx_flag` as its own FLAG line
  in the live progress log (same place `netbox_conflict` already
  showed), and the "GSX {node}-{slot}-{port}-{t1}" progress line now
  prints `?` instead of `None` for any unresolved field. (The polished
  report already did this via `build_route_block`'s `or "?"` -- this
  was only a console/live-log cosmetic gap.)

---

## v1.33 — 2026-08-05

### Web Front End — pass/fail rollup + attribution
- **Overall PASS/FAIL badge on finished reports** (`app.py`, `job.js`,
  `_job_panels.html`, `style.css`) -- scans the Run Summary section
  (currently only the Autotester writes one) for any "Dirty" tag or
  "FAIL" line across all DS1s and shows one glance-check badge above the
  report: green "PASS -- N DS1(s) clean" or red "ISSUES DETECTED --
  <DS1s>". No change to the underlying report text or to any tool's
  logic -- the existing per-DS1 PASS/FAIL in the Run Summary only ever
  reflected whether the route resolved, not hop health, so this adds the
  rollup that was missing rather than replacing anything. Tools that
  don't emit a Run Summary show no badge (nothing to roll up yet).
- **Subtle attribution watermark** on every page (`templates/base.html`,
  `style.css`) -- "Built by P. Capps", fixed bottom-right, low opacity,
  inherited automatically by every tool page and the home page.

---

## v1.32 — 2026-08-05

### Web Front End — live step-by-step progress log
- **Status panel now shows a scrolling log while a job runs**, not just an
  elapsed timer. No changes to any tool's actual logic -- every tool
  already `print()`s progress as it works ("[connecting] ...",
  "[GSX] resolving ...", etc.); `app.py` now captures those same lines
  per-job via a small thread-aware stdout tee (`_JobStdoutTee`) and hands
  them back through `/api/job/<id>` as a `log` list. `job.js` appends only
  the new lines each poll and auto-scrolls.
- Concurrent jobs stay correctly separated (each background thread's
  writes are routed to its own job's log via a thread-id map) -- verified
  with two simultaneous runs against different IPs.
- This was the natural next step flagged when the polling architecture
  was first built (v1.29): the background-thread + poll scaffolding
  needed no structural changes, just a place to route the existing print
  output.

---

## v1.31 — 2026-08-04

### Web Front End — all 9 tools + home page
- **Home page** (`templates/home.html`) -- lists every tool as a card
  (name, which device it runs from, description, what it requires),
  pulled live from each module's own `TOOL_INFO` dict and sorted by the
  same `order` the CLI launcher menu uses. `/` now renders this instead
  of going straight to the Autotester form.
- **Remaining 8 tools wired up** (`app.py`, new templates): NPT-1250
  Discovery, DS1 PMs, Fiber Utilization, OSPF Events + Fiber Levels,
  1250 Health Check, GSX Perfmon (96 Intervals), IXC Check, and the MUX
  CEM Loop Script -- each gets its own page/route/`/api/.../run` endpoint,
  following the same pattern as the Autotester: no `collect_inputs()`,
  same background-job + polling architecture, same "never persist
  credentials" rule.
  - Discovery / Fiber / OSPF / Health share one route helper
    (`_simple_1250_route`) since all four take identical inputs (1250 IP
    + infra creds).
  - DS1 PMs re-validates entries server-side with the tool's own
    `_parse_and_validate()` before launching the job, so bad slot/channel
    input comes back as an immediate form error instead of a failed run.
  - GSX Perfmon reuses the tool's own `_parse_t1_id()` for the same reason.
  - IXC Check's site dropdown is checked against `interface_check.SITE_TO_1800`.
  - MUX CEM Loop Script's form branches on 1250+DS1 vs. MUX-direct mode.
    MUX-direct never opens a live GSX session (GSX info there is only
    embedded as "run manually" text), so GSX credentials are optional in
    that mode -- only required in 1250+DS1 mode, matching what the code
    actually uses.
- **`app.py` generalized**: job-runner/polling machinery (`_launch_job`,
  `_run_job`, `/api/job/<id>`, `/download/<id>`) is now tool-agnostic,
  taking a `run_callable` closure per tool instead of being hardcoded to
  the Autotester.
- **`templates/index.html` retired** -- superseded by `base.html` +
  per-tool templates + `home.html`. Left on disk (not referenced by any
  route) since it couldn't be removed in this environment; safe to
  delete manually.
- Verified: `py_compile` across all tool modules + `app.py`, plus a live
  smoke test of every `/tools/*` page (200) and one job run per tool
  shape (bad-input validation returns 400s with the right messages, and
  unreachable-device runs finish as a graceful `error`/no-report status
  rather than crashing the server).

---

## v1.30 — 2026-08-04

### Web Front End
- **"Open results file when done" checkbox** (`templates/index.html`,
  `app.py`) -- exposes the same `open_when_done` behavior the CLI's
  "Open results file when done? (y/n)" prompt has always had. Was
  previously hardcoded to `False` for the web app (auto-opening a file only
  makes sense when the server and browser are the same machine). A caption
  under the checkbox says so directly, and it stays unchecked by default.

---

## v1.29 — 2026-08-04

### New: Web Front End (Proof of Concept)
- **`app.py` + `templates/index.html`** -- a small Flask app that runs the
  Autotester from a browser instead of a terminal. See `WEB_SETUP.md` for
  the full walkthrough. Highlights:
  - `collect_inputs()` is never called from the web layer (it uses
    `input()`/`getpass()`, which would hang with no terminal attached) --
    the web form builds the same `params` dict directly and calls
    `autotester_standalone.run(params)`, the exact same code path as the CLI.
  - Each run happens in a background thread; the browser polls a status
    endpoint every ~2s showing an elapsed timer, and flags a "may be hung"
    warning past a threshold (5 min, scaling up slightly for multi-DS1
    runs) -- without literally blocking an HTTP request for the run's
    duration.
  - Credentials are submitted fresh per run and held only in memory for
    that job -- never persisted.
  - Finished report renders on the page plus a download link for the same
    `.txt` the CLI would have written.
  - `autotester_standalone.run()` now returns the output file path (was:
    returned nothing) so the web layer can retrieve it. No change to CLI
    behavior -- `main()` still ignores the return value.
  - `requirements.txt` gained `flask>=3.0`.
  - Known POC limitations (in-memory job store, no real job-kill, dev
    server only) and the checklist for eventually moving this onto a
    shared network host are documented in `WEB_SETUP.md`.

---

## v1.28 — 2026-08-04

### Report Format
- **Run Summary standardized to Clean/Dirty per hop/side** (`output_builders.py`)
  - Replaced the itemized-counter findings line (raw counter names + values,
    plus a trailing "Suggest: ..." fault-direction phrase) with a fixed,
    standardized format:
    ```
    TS1/7  --  PASS  |  1250: TDM Clean / CES Dirty (RxPsnES)  |  1800: 1250-side Clean / MUX-side Clean  |  MUX: 1800-side Clean / GSX-side Clean
    ```
    - **1250**: Clean/Dirty on TDM vs CES
    - **1800**: Clean/Dirty on 1250-side (NNI + EVC) vs MUX-side (OC PM +
      alarms) -- Peerless circuits label the second side "network-side"
      since there's no Bandwidth MUX beyond a Peerless 1800 hop
    - **MUX**: Clean/Dirty on 1800-side (facility alarms + connection/xconnect
      state) vs GSX-side (T3 controller counters)
    - Dirty tags name the counter/alarm that tripped it (e.g. `(RxPsnES)`,
      `(LP_AIS)`) -- never the raw value. The trailing "Suggest: ..." phrase
      is gone; the per-side Clean/Dirty tags already convey direction.
  - **CEM Pkts Missing / Failure Counts / Generated+Received Lbits/Rbits
    dropped from Dirty determination entirely**, at the Run Summary AND the
    Diagnostic Summary's CEM indicator. These are cumulative-since-last-
    "clear cem circuit" counters (per the CEM Hairpin Loop MOP's own manual
    clear step) -- not a current-state reading. A mature, healthy circuit
    shows large non-zero values for all of them, so treating any non-zero
    value as "Dirty" was flagging nearly every circuit's MUX hop regardless
    of real health (root cause of the "every DS1 shows MUX CEM errors"
    pattern). The raw circuit counters are still visible in full in the MUX
    Stats section (`>> CEM Circuit Health`) for reference -- just no longer
    drive a pass/fail-style verdict. Connection state and xconnect leg status
    (genuine current-state signals) still do.
  - `run_summary_line()` gained two new parameters (`all_t3_stats`,
    `fiber_results`/`evc_results`) to support the 1800/MUX side-splitting --
    call site updated in `autotester_standalone.py`.

---

## v1.27 — 2026-08-04

### Report Layout
- **Autotester: Full Route + Diagnostic Summary now grouped per channel**
  (`autotester_standalone.py`)
  - Previously the report had two separate combined sections: one Diagnostic
    Summary block spanning every DS1, followed by every DS1's Full Route
    block. Now each DS1's Full Route is immediately followed by that same
    DS1's own Diagnostic Summary before moving to the next channel -- easier
    to digest one circuit at a time instead of cross-referencing two lists.
  - `build_diagnostic_summary` is now called once per DS1 (still the same
    function/logic, just scoped to a single-element list per call) instead of
    once for the whole run. Output content is unchanged, only the ordering.
  - The JIRA "Diagnostic Summary" panel is unaffected -- it's built from the
    same per-channel blocks concatenated together.

### New Features
- **GSX IP address in the Full Route block** (`output_builders.py`,
  `autotester_standalone.py`)
  - `HOP 4 -- GSX` now shows the resolved GSX management IP:
    ```
      HOP 4 -- GSX
        Node       : LAXGSX01
        IP         : 192.168.45.3
        Assignment : 11-2-27
        T1 Command : SHOW T1 T1-1-11-2-27
    ```
  - The IP is the live management address the Autotester actually reached
    (resolved via Netbox mgmt IPs + reachability ping, same value used to
    open the GSX session). Shows `?` if no reachable IP was resolved for that
    DS1 (mirrors the existing fallback convention used elsewhere).

---

## v1.26 — 2026-08-04

### Performance
- **1800 MUSE lookup batched per hub instead of per DS1** (`npt1800_client.py`)
  - Root cause of the "any show configuration | ... command is slow" complaint:
    the MUSE ID -> OC lookup (`show configuration | display-set | match
    "{muse_id} "`) issued that call **once per DS1**. The slowness is a
    device-side full-config render (~90-120s), and that render cost is paid
    per CALL, not per DS1 -- so a 4-DS1 run on one hub paid it 4 times
    (~6-8 minutes) for data a single render already contains.
  - New `_muse_lookup_batch()` issues **one render per hub**, matched against
    a regex alternation of every DS1's muse_id needed that run (Junos-style
    `match` supports `|` alternation), then groups the returned lines back to
    each muse_id locally in Python. Same source command, same selectivity
    (still only matches the muse_ids actually needed -- no broader/unscoped
    dump), just consolidated. This mirrors the pattern `npt1250_client.
    query_batch` already uses for `peer-address` (one render, parse many).
  - Net effect: an N-DS1 run on one hub now costs ~90-120s total instead of
    N * 90-120s. No output/behavior change -- verified the OC resolution and
    Peerless-customer detection are correctly scoped per-DS1 even when
    multiple DS1s share one combined render (unit-tested with a 2-DS1 mixed
    Peerless/non-Peerless fixture).
  - The separate OC alarm/PM stat commands (already deduped per unique OC,
    not a full-config render) keep their own smaller timeout, unaffected.

---

## v1.25 — 2026-08-04

### New Tools
- **mux_loop_script.py** — `MUX CEM Loop Script` (launcher order 60) — item 13
  - Generates a copy/paste-ready CEM hairpin loop MOP for a circuit. Does **not**
    execute any config — it connects only to run read-only prechecks, then writes
    a script the engineer pastes manually.
  - **Two input modes:**
    1. **1250 IP + DS1 (default)** — resolves the full route automatically
       (1250 → 1800 → MUX → GSX), the same path the Autotester walks, then fills
       every identifier into the script.
    2. **MUX-direct** — engineer supplies MUX IP / name / ACR / CEM group directly
       (plus optional other-hop info); only the MUX is queried. For when the route
       is already known or Netbox is unavailable.
  - **Prechecks are run live** against every reachable hop and the real output is
    embedded in the script as the baseline. **Postchecks are emitted as commands
    only** (run manually after testing).
  - Generates both scenarios from the MOP, with correct `connect` command syntax
    derived from the resolved ACR / CEM / GSX CE identifiers:
    - **Scenario A** — hairpin facing the **GSX** (`connect ... CEM{gsx} CEM{gsx}`),
      isolates the GSX; includes turn-up, validation, and restore.
    - **Scenario B** — hairpin facing the **1250** (`connect ... CEM-ACR{n} CEM-ACR{n}`),
      isolates the 1250/LEC; includes turn-up, validation, and restore.
  - Connection name (e.g. `CB_OC3_STS02_02`) is discovered automatically via
    `show run | include CEM-ACR{n}` — never typed by hand (new
    `get_connection_name()` in `mux4216_client.py`).
  - Peerless circuits are detected and rejected (no MUX/GSX hop to loop).
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA attachment, auto-opens.

---

## v1.24 — 2026-08-04

### New Features
- **Autotester CEM circuit health** (`mux4216_client.py`, `output_builders.py`,
  `autotester_standalone.py`) — item 14
  - The Autotester now checks CEM circuit health at the MUX hop, closing the gap
    between "the SONET path resolves" and "the emulated circuit is actually clean."
  - New `mux4216_client.query_cem_health()` pulls, per DS1:
    - `show cem circuit interface cem-acr {acr} {cem}` — Pkts Missing, Failure
      Counts, Lbits/Rbits (any non-zero = flagged)
    - `show xconnect all | include CE{acr}:{cem}(` — both legs UP
    - `show connection name {conn}` — Current State UP
    - `show acr group {acr} detail cem` — working/protect state
  - New `get_connection_name()` discovers the connection name automatically
    (shared with the loop-script tool).
  - **Diagnostic Summary** MUX block now shows `[ OK ]/[ !! ] CEM circuit`,
    `Connection UP`, and `Xconnect leg(s) DOWN` indicators.
  - **Run Summary** flags `MUX CEM: Pkts Missing=… / Failure Counts=…` with a
    "check MUX" suggestion.
  - **MUX Stats** section gains a `>> CEM Circuit Health` block with the raw
    circuit / xconnect / connection / ACR-detail output per DS1.
  - All additions are read-only; no change to how the route is resolved.

---

## v1.23 — 2026-08-04

### New Files
- **`Curveball Tools.bat`** — double-click launcher (item 7)
  - Opens a terminal window in the correct directory and runs `python launcher.py`
  - No need to navigate manually; works by double-click from anywhere

- **`Create Curveball Shortcut.ps1`** — one-time taskbar shortcut setup (item 7)
  - Right-click → **Run with PowerShell** (do not double-click — that opens Notepad,
    a Windows default for `.ps1` files)
  - Creates `Curveball Tools.lnk` on the Desktop, ready to right-click → Pin to taskbar

### Documentation
- **`README.md`** — updated tools table (added OSPF Events, GSX Perfmon), updated
  Running section and file list to include `.bat` and shortcut script
- **`INSTALL.md`** — added "Quick launch / Taskbar shortcut" section (step 4),
  updated Quick Setup Checklist

---

## v1.22 — 2026-08-04

### Bug Fixes
- **DS1 input normalization** — item 19 (`autotester_standalone.py`, `ds1_pms.py`)
  - DS1 entries are now lowercased on input, so `TS1/7` and `ts1/7` both work
  - `&` is now accepted as a separator in addition to `,` — entries like
    `TS1/23 & TS1/28` are split correctly instead of being treated as one item

---

## v1.21 — 2026-08-04

### Bug Fixes
- **output_builders.py** — MUX DS1_AIS direction annotation (item 17)
  - `[ !! ] MINOR DS1_AIS` in the diagnostic output now appends
    `(AIS from LEC/1250 direction -- signal loss at bottom of route)`
  - DS1_AIS on the MUX T1 path means the 1800 is inserting AIS into the SONET
    payload because the 1250 is not delivering a valid DS1 — the fault is on the
    LEC/customer side, not the IXC side

- **output_builders.py** — GSX PM interval label in diagnostic header (item 18)
  - GSX node header now reads `GSX -- NYCGSX02  (current 15 min / 24 hr)` instead
    of just `GSX -- NYCGSX02`
  - Clarifies that the `[ !! ]` error counts shown are the max across the current
    15-minute interval and current 24-hour interval (whichever is higher), not
    cumulative statistics

---

## v1.20 — 2026-08-04

### New Tools
- **gsx_perfmon.py** — `GSX Perfmon (96 Intervals)` (launcher order 55)
  - Pulls a complete 24-hour picture of a single T1 on the GSX:
    - `SHOW T1 ... STATUS`
    - `SHOW T1 ... STATISTICS`
    - `SHOW T1 ... PERFMON CURRENT DAY`
    - `SHOW T1 ... PERFMON THRESHOLDS`
    - `SHOW T1 ... PERFMON INTERVAL N FIFTEENMIN` for all 96 intervals
      (interval 1 = most recent, interval 96 = oldest, ~24 hours back)
  - T1 assignment accepts full form (`T1-1-7-2-2`) or short form (`7-2-2`)
  - Reuses GSX credentials from session (no re-prompt if already entered this session)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post with attachment
    fallback, and auto-opens the file
  - Useful for stress-test planning: reveals error frequency and timing so test
    durations are grounded in real failure patterns

---

## v1.19 — 2026-08-04

### New Features
- **MUX controller description fallback** (`mux4216_client.py`) — item 12
  - When Netbox has no OC→SONET mapping for a circuit (e.g. ts3 not yet populated),
    the autotester now tries a second resolution method before falling back to the
    unreliable legacy ACR-guess
  - New method `find_acr_by_description(hub_hostname, slot_port)` scans
    `show run | section controller` on the MUX and looks for a SONET-ACR stanza
    whose description matches `{1800-hostname} {OC-slot/port}`
    (e.g. `ces01.lax1 ts3/1`). Case-insensitive.
  - If matched, uses that ACR number to resolve VTG / T1 / CEM group directly —
    the same path as a successful Netbox lookup, but without Netbox
  - On success: marks `netbox_conflict` with a reminder to populate Netbox
  - Resolution tier order is now:
    1. Netbox `oc_to_sonet` (most accurate, verifies path)
    2. MUX description scan (accurate, works without Netbox)
    3. Legacy ACR-guess (shotgun, last resort)
  - No changes to `autotester_standalone.py` — fallback is entirely inside
    `query_batch`

---

## v1.18 — 2026-08-04

### Bug Fixes
- **Dynamic OC type labeling** — autotester no longer hardcodes "OC12" in output
  - The 1800 regex already captured any OC speed (`oc12`, `oc48`, `oc3`, etc.); only
    the display labels were wrong
  - Added `_oc_label(oc_iface)` helper in `output_builders.py` that extracts the
    speed from the interface identifier (e.g. `oc48-ts20/1:13:1` → `"OC48"`)
  - All user-facing "OC12" label strings replaced in:
    - `output_builders.py` — route blocks, peerless block, full diagnostic block,
      run summary findings and suggestions
    - `npt1800_client.py` — stat section header and "could not find" error message
    - `autotester_standalone.py` — "NPT-1800 OC STATS" section header
    - `mux4216_client.py` — internal `Cannot parse OC interface` error text

---

## v1.17 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display now distinguishes "disabled" from "clean"
  - When the device returns "switch of this interface object is off" (PMs not enabled), `npt1250_client` already writes `"CES PMs not enabled on this DS1."` into the PM blob
  - `build_diagnostic_summary` now detects that marker and shows `[ -- ] CES PMs disabled` instead of `[ OK ] CES PMs clean`
  - Applies to both the full-route and peerless diagnostic blocks

---

## v1.16 — 2026-08-04

### New Features
- **IP address validation** on all manual IP entry prompts
  - Rejects entries that aren't 4 octets with each octet 0–255 (e.g. `192.168.270.1` or `192.168.150` both fail)
  - Re-prompts in a loop until a valid IP is entered — no more silent TCP failures from a typo
  - Implemented via `prompt_ip()` in `device_base.py`; wired into autotester, health check, fiber util, DS1 PMs, discovery, and OSPF events

### Bug Fixes
- **output_builders.py** — incomplete route now returns FAIL in run summary
  - When Netbox data is missing (1800/OC12 not resolved, hub IP unknown, or MUX not found), `run_summary_line` now returns `FAIL | Route incomplete: ... | Check Netbox` instead of `PASS | All clean`

---

## v1.15 — 2026-08-04

### Bug Fixes
- **Bad credential loop fixed** across all tools
  - Previously: auth failure was silently swallowed, bad creds stayed in the session, every subsequent run re-used them with no way to re-enter without quitting
  - Now: `CredentialError` (new exception in `device_base.py`) is raised on `AuthenticationException` (paramiko) or "Access denied" in plink output (GSX)
  - `launcher.py` catches it in `dispatch()`, prints the rejection message, and clears **only the failing cred pair** (`infra` or `gsx`) from the session — the user is re-prompted on the very next tool run without restarting the launcher
  - Files changed: `device_base.py`, `gsx_client.py`, `launcher.py`, `autotester_standalone.py`, `health_check.py`, `fiber_util.py`, `ds1_pms.py`, `interface_check.py`, `npt1250_discovery.py`, `ospf_events.py`

---

## v1.14 — 2026-08-04

### Bug Fixes
- **output_builders.py** — Run Summary CES reporting now shows the worst error, not the first
  - Previous logic stopped at the first CES counter it found (e.g. `RxPsnOverrunEvents=8`) even when a more severe counter was present (`RxPsnES=1627`)
  - Now scans all CES counters and reports the one with the highest value in the run summary line

---

## v1.13 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display placement corrected (NOE-4503)
  - CES PMs now appear **above** the `1250 --` identifier line (`[ !! ] CES ...` / `[ OK ] CES PMs clean`)
  - Removed the duplicate CES block that was also appearing below the `ds1-tsX/Y MUSE_XXXX` line
  - TDM PMs remain below the identifier line, unchanged
  - Fix applied to both the full route block and the peerless block

---

## v1.12 — 2026-08-04

### New Tools
- **ospf_events.py** — `OSPF Events + Fiber Levels` (launcher order 45)
  - Pulls `show ne events unreported` and filters in Python for OSPF state changes
  - Separate sections for DOWN events and FULL/UP events; catch-all for other OSPF lines
  - Also checks fiber transceiver light levels on ts2 and ts5 (TX/RX power)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post and auto-open

### Bug Fixes
- **jira_client.py** — JIRA `CONTENT_LIMIT_EXCEEDED` fallback
  - When a report is too large to post as a comment (HTTP 400), the script now:
    1. Posts a short stub comment noting the attachment
    2. Uploads the `.txt` output file directly as a JIRA attachment
  - Affects all tools: autotester, health check, fiber util, DS1 PMs, interface check, discovery, and the new OSPF events tool

---

## v1.11 — (prior release)

*(No changelog maintained before v1.12 — see git history or `!Revisions/` zip archive for earlier changes.)*
