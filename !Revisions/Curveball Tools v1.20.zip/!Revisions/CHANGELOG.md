# Curveball Tools — Changelog

---

## v1.20 — 2026-08-04

### New Tools
- **gsx_perfmon.py** — `GSX Perfmon (96 Intervals)` (launcher order 55)
  - Pulls a complete 24-hour picture of a single T1 on the GSX:
    - `SHOW T1 ... STATUS`
    - `SHOW T1 ... STATISTICS`
    - `SHOW T1 ... PERFMON CURRENT DAY`
    - `SHOW T1 ... PERFMON THRESHOLDS`
    - `SHOW T1 ... PERFMON INTERVAL N FIFTEENMIN` for all 96 intervals
      (interval 1 = most recent, interval 96 = oldest, ~24 hours back)
  - T1 assignment accepts full form (`T1-1-7-2-2`) or short form (`7-2-2`)
  - Reuses GSX credentials from session (no re-prompt if already entered this session)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post with attachment
    fallback, and auto-opens the file
  - Useful for stress-test planning: reveals error frequency and timing so test
    durations are grounded in real failure patterns

---

## v1.19 — 2026-08-04

### New Features
- **MUX controller description fallback** (`mux4216_client.py`) — item 12
  - When Netbox has no OC→SONET mapping for a circuit (e.g. ts3 not yet populated),
    the autotester now tries a second resolution method before falling back to the
    unreliable legacy ACR-guess
  - New method `find_acr_by_description(hub_hostname, slot_port)` scans
    `show run | section controller` on the MUX and looks for a SONET-ACR stanza
    whose description matches `{1800-hostname} {OC-slot/port}`
    (e.g. `ces01.lax1 ts3/1`). Case-insensitive.
  - If matched, uses that ACR number to resolve VTG / T1 / CEM group directly —
    the same path as a successful Netbox lookup, but without Netbox
  - On success: marks `netbox_conflict` with a reminder to populate Netbox
  - Resolution tier order is now:
    1. Netbox `oc_to_sonet` (most accurate, verifies path)
    2. MUX description scan (accurate, works without Netbox)
    3. Legacy ACR-guess (shotgun, last resort)
  - No changes to `autotester_standalone.py` — fallback is entirely inside
    `query_batch`

---

## v1.18 — 2026-08-04

### Bug Fixes
- **Dynamic OC type labeling** — autotester no longer hardcodes "OC12" in output
  - The 1800 regex already captured any OC speed (`oc12`, `oc48`, `oc3`, etc.); only
    the display labels were wrong
  - Added `_oc_label(oc_iface)` helper in `output_builders.py` that extracts the
    speed from the interface identifier (e.g. `oc48-ts20/1:13:1` → `"OC48"`)
  - All user-facing "OC12" label strings replaced in:
    - `output_builders.py` — route blocks, peerless block, full diagnostic block,
      run summary findings and suggestions
    - `npt1800_client.py` — stat section header and "could not find" error message
    - `autotester_standalone.py` — "NPT-1800 OC STATS" section header
    - `mux4216_client.py` — internal `Cannot parse OC interface` error text

---

## v1.17 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display now distinguishes "disabled" from "clean"
  - When the device returns "switch of this interface object is off" (PMs not enabled), `npt1250_client` already writes `"CES PMs not enabled on this DS1."` into the PM blob
  - `build_diagnostic_summary` now detects that marker and shows `[ -- ] CES PMs disabled` instead of `[ OK ] CES PMs clean`
  - Applies to both the full-route and peerless diagnostic blocks

---

## v1.16 — 2026-08-04

### New Features
- **IP address validation** on all manual IP entry prompts
  - Rejects entries that aren't 4 octets with each octet 0–255 (e.g. `192.168.270.1` or `192.168.150` both fail)
  - Re-prompts in a loop until a valid IP is entered — no more silent TCP failures from a typo
  - Implemented via `prompt_ip()` in `device_base.py`; wired into autotester, health check, fiber util, DS1 PMs, discovery, and OSPF events

### Bug Fixes
- **output_builders.py** — incomplete route now returns FAIL in run summary
  - When Netbox data is missing (1800/OC12 not resolved, hub IP unknown, or MUX not found), `run_summary_line` now returns `FAIL | Route incomplete: ... | Check Netbox` instead of `PASS | All clean`

---

## v1.15 — 2026-08-04

### Bug Fixes
- **Bad credential loop fixed** across all tools
  - Previously: auth failure was silently swallowed, bad creds stayed in the session, every subsequent run re-used them with no way to re-enter without quitting
  - Now: `CredentialError` (new exception in `device_base.py`) is raised on `AuthenticationException` (paramiko) or "Access denied" in plink output (GSX)
  - `launcher.py` catches it in `dispatch()`, prints the rejection message, and clears **only the failing cred pair** (`infra` or `gsx`) from the session — the user is re-prompted on the very next tool run without restarting the launcher
  - Files changed: `device_base.py`, `gsx_client.py`, `launcher.py`, `autotester_standalone.py`, `health_check.py`, `fiber_util.py`, `ds1_pms.py`, `interface_check.py`, `npt1250_discovery.py`, `ospf_events.py`

---

## v1.14 — 2026-08-04

### Bug Fixes
- **output_builders.py** — Run Summary CES reporting now shows the worst error, not the first
  - Previous logic stopped at the first CES counter it found (e.g. `RxPsnOverrunEvents=8`) even when a more severe counter was present (`RxPsnES=1627`)
  - Now scans all CES counters and reports the one with the highest value in the run summary line

---

## v1.13 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display placement corrected (NOE-4503)
  - CES PMs now appear **above** the `1250 --` identifier line (`[ !! ] CES ...` / `[ OK ] CES PMs clean`)
  - Removed the duplicate CES block that was also appearing below the `ds1-tsX/Y MUSE_XXXX` line
  - TDM PMs remain below the identifier line, unchanged
  - Fix applied to both the full route block and the peerless block

---

## v1.12 — 2026-08-04

### New Tools
- **ospf_events.py** — `OSPF Events + Fiber Levels` (launcher order 45)
  - Pulls `show ne events unreported` and filters in Python for OSPF state changes
  - Separate sections for DOWN events and FULL/UP events; catch-all for other OSPF lines
  - Also checks fiber transceiver light levels on ts2 and ts5 (TX/RX power)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post and auto-open

### Bug Fixes
- **jira_client.py** — JIRA `CONTENT_LIMIT_EXCEEDED` fallback
  - When a report is too large to post as a comment (HTTP 400), the script now:
    1. Posts a short stub comment noting the attachment
    2. Uploads the `.txt` output file directly as a JIRA attachment
  - Affects all tools: autotester, health check, fiber util, DS1 PMs, interface check, discovery, and the new OSPF events tool

---

## v1.11 — (prior release)

*(No changelog maintained before v1.12 — see git history or `!Revisions/` zip archive for earlier changes.)*
