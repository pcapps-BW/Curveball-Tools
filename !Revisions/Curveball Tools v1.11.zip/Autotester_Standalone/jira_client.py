#!/usr/bin/env python3
"""
jira_client.py -- post Autotester results to a JIRA ticket as a comment.

Port of the SecureCRT JIRA integration, using requests (not PowerShell).
Posts an ADF (Atlassian Document Format) comment via API v3 with two collapsed
expand panels:
    "Test Results -- Run Summary & Diagnostic"  (run summary + diagnostic summary)
    "Per-DS1 Performance Monitors"              (per-DS1 PMs)

Creds (JIRA_EMAIL, JIRA_TOKEN) read from autotester_config.txt; caller may pass
them in instead. Ticket format: NOE-XXXX.

Built by P. Capps.
"""

import re
import sys
import base64
import datetime

try:
    import requests
except ImportError:
    print("ERROR: requests not installed. Run:  pip install requests")
    sys.exit(1)

CONFIG_PATH = r"C:\Claude\autotester_config.txt"
JIRA_BASE   = "https://bandwidth-jira.atlassian.net"
TICKET_RE   = re.compile(r'^NOE-\d{4}$')


def load_jira_config(path=CONFIG_PATH):
    email = token = ""
    try:
        with open(path, "r") as cfg:
            for line in cfg:
                line = line.strip()
                if line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                if key == "JIRA_EMAIL":
                    email = val.strip()
                elif key == "JIRA_TOKEN":
                    token = val.strip()
    except FileNotFoundError:
        pass
    return email, token


def valid_ticket(ticket):
    return bool(TICKET_RE.match((ticket or "").strip().upper()))


def _build_adf(host_1250, ds1_count, results_text, pm_text):
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    return {
        "version": 1,
        "type": "doc",
        "content": [
            {
                "type": "paragraph",
                "content": [{
                    "type": "text",
                    "text": "Autotester results for {} -- {} DS1(s) tested on {}.".format(
                        host_1250, ds1_count, stamp)
                }]
            },
            {
                "type": "expand",
                "attrs": {"title": "Test Results -- Run Summary & Diagnostic"},
                "content": [{
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{"type": "text", "text": results_text}]
                }]
            },
            {
                "type": "expand",
                "attrs": {"title": "Per-DS1 Performance Monitors"},
                "content": [{
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{"type": "text", "text": pm_text}]
                }]
            }
        ]
    }


def post_comment(ticket, host_1250, ds1_count, results_text, pm_text,
                 email=None, token=None):
    """
    Post the results as an ADF comment. Returns (ok, message).
    """
    ticket = (ticket or "").strip().upper()
    if not valid_ticket(ticket):
        return False, "Invalid ticket format '{}' (expected NOE-XXXX)".format(ticket)

    if not (email and token):
        cfg_email, cfg_token = load_jira_config()
        email = email or cfg_email
        token = token or cfg_token
    if not (email and token):
        return False, "Missing JIRA credentials (JIRA_EMAIL / JIRA_TOKEN)."

    adf = _build_adf(host_1250, ds1_count, results_text, pm_text)
    url = "{}/rest/api/3/issue/{}/comment".format(JIRA_BASE, ticket)
    cred = base64.b64encode("{}:{}".format(email, token).encode("ascii")).decode("ascii")
    headers = {
        "Authorization": "Basic {}".format(cred),
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        r = requests.post(url, json={"body": adf}, headers=headers, timeout=30)
    except Exception as e:
        return False, "JIRA request failed: {}: {}".format(type(e).__name__, e)

    if r.status_code in (200, 201):
        return True, "Comment posted to {}".format(ticket)
    return False, "JIRA returned HTTP {} -- {}".format(
        r.status_code, (r.text or "")[:300])


def _build_report_adf(intro, panel_title, report_text):
    """Single intro paragraph + one collapsed panel holding the full report."""
    return {
        "version": 1,
        "type": "doc",
        "content": [
            {
                "type": "paragraph",
                "content": [{"type": "text", "text": intro}]
            },
            {
                "type": "expand",
                "attrs": {"title": panel_title},
                "content": [{
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{"type": "text", "text": report_text}]
                }]
            }
        ]
    }


def post_report(ticket, intro, panel_title, report_text, email=None, token=None):
    """
    General-purpose single-panel post for the auxiliary tools (discovery,
    DS1 PMs, interface check). Returns (ok, message).
      intro       -- one-line summary shown in the comment body
      panel_title -- title of the collapsed panel
      report_text -- the full report (goes in the collapsed code block)
    """
    ticket = (ticket or "").strip().upper()
    if not valid_ticket(ticket):
        return False, "Invalid ticket format '{}' (expected NOE-XXXX)".format(ticket)

    if not (email and token):
        cfg_email, cfg_token = load_jira_config()
        email = email or cfg_email
        token = token or cfg_token
    if not (email and token):
        return False, "Missing JIRA credentials (JIRA_EMAIL / JIRA_TOKEN)."

    adf = _build_report_adf(intro, panel_title, report_text)
    url = "{}/rest/api/3/issue/{}/comment".format(JIRA_BASE, ticket)
    cred = base64.b64encode("{}:{}".format(email, token).encode("ascii")).decode("ascii")
    headers = {
        "Authorization": "Basic {}".format(cred),
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        r = requests.post(url, json={"body": adf}, headers=headers, timeout=30)
    except Exception as e:
        return False, "JIRA request failed: {}: {}".format(type(e).__name__, e)

    if r.status_code in (200, 201):
        return True, "Comment posted to {}".format(ticket)
    return False, "JIRA returned HTTP {} -- {}".format(
        r.status_code, (r.text or "")[:300])
