#!/usr/bin/env python3
"""
ospf_events.py -- OSPF up/down event timestamps + fiber light levels on NPT-1250.

Pulls 'show ne events unreported' and filters in Python for OSPF-related state
change events (down and full/up).  Also checks fiber transceiver light levels
for ts2 and ts5.

Runs standalone (prompts for its own inputs) OR via launcher.py (params dict).
READ-ONLY: 'show' commands only.

Built by P. Capps.
"""

import re
import os
import datetime

try:
    import paramiko  # noqa: F401
    _DEP_ERROR = None
except ImportError as e:
    _DEP_ERROR = "paramiko not installed (pip install paramiko): {}".format(e)

from npt1250_client import NPT1250Client
from device_base import CredentialError, prompt_ip
from jira_client import post_report, valid_ticket

# Fiber transceiver slots to check (same as health_check / fiber_util).
FIBER_SLOTS = ["ts2", "ts5"]

# Regex patterns for OSPF event filtering.
_RE_OSPF  = re.compile(r'ospf', re.IGNORECASE)
_RE_DOWN  = re.compile(r'\bdown\b', re.IGNORECASE)
_RE_FULL  = re.compile(r'\bfull\b', re.IGNORECASE)

# Launcher menu metadata.
TOOL_INFO = {
    'name':     'OSPF Events + Fiber Levels',
    'ran_from': '1250',
    'desc':     'OSPF up/down event timestamps from NE unreported events + fiber transceiver light levels (ts2/ts5).',
    'requires': '1250 IP, creds',
    'order':    45,
}


# ── Parsing helpers ──────────────────────────────────────────────────────────

def _parse_ospf_events(raw):
    """
    Filter NE unreported event lines for OSPF state changes.
    Returns dict with keys 'down', 'full', 'other' (all lists of raw lines).
    """
    down, full, other = [], [], []
    for ln in raw.splitlines():
        s = ln.rstrip()
        if not s or not _RE_OSPF.search(s):
            continue
        if _RE_DOWN.search(s):
            down.append(s)
        elif _RE_FULL.search(s):
            full.append(s)
        else:
            other.append(s)
    return {"down": down, "full": full, "other": other}


def _parse_light_levels(raw):
    """
    Extract light-level lines from transceiver output.
    Matches anything containing power, laser, tx, rx, or dBm keywords.
    Falls back to full output if nothing matches.
    """
    levels = []
    for ln in raw.splitlines():
        s = ln.rstrip()
        if re.search(r'(power|laser|tx\b|rx\b|dbm|level)', s, re.IGNORECASE):
            levels.append(s)
    return levels


# ── Launcher interface ───────────────────────────────────────────────────────

def collect_inputs(session=None):
    """Prompt for all inputs; return params dict (or None to abort)."""
    import getpass
    session = session if session is not None else {}

    ip = prompt_ip("1250 IP", default=session.get("ip_1250"))
    if not ip:
        return None

    jira_ticket = None
    if input("Add to JIRA? (y/n) [n]: ").strip().lower() in ("y", "yes"):
        while True:
            jira_ticket = input("JIRA number (NOE-XXXX): ").strip().upper()
            if valid_ticket(jira_ticket):
                break
            if not jira_ticket:
                print("  (blank -- skipping JIRA)")
                jira_ticket = None
                break
            print("  Invalid format. Expected NOE-XXXX (e.g. NOE-1234).")

    open_when_done = input("Open results file when done? (y/n) [y]: ").strip().lower()
    open_when_done = open_when_done in ("", "y", "yes")

    user = session.get("infra_user")
    pw   = session.get("infra_pass")
    if not (user and pw):
        user = input("Username: ").strip()
        pw   = getpass.getpass("Password: ")
    if not (user and pw):
        print("Missing credentials.")
        return None

    return {
        "ip_1250":       ip,
        "username":      user,
        "password":      pw,
        "jira_ticket":   jira_ticket,
        "open_when_done": open_when_done,
    }


def run(params):
    """Execute the tool given a params dict (no prompting)."""
    if _DEP_ERROR:
        print("[!] {} -- tool unavailable.".format(_DEP_ERROR))
        return

    ip             = params["ip_1250"]
    user           = params["username"]
    pw             = params["password"]
    jira_ticket    = params.get("jira_ticket")
    open_when_done = params.get("open_when_done", True)

    c = NPT1250Client(ip, user, pw)
    print("\n[connecting] {}".format(ip))
    try:
        c.connect()
    except CredentialError:
        raise
    except Exception as e:
        print("[!] connect failed: {}: {}".format(type(e).__name__, e))
        return None
    host = c.hostname
    print("  host: {}".format(host))

    lines = []
    lines.append("OSPF EVENTS + FIBER LIGHT LEVELS")
    lines.append("Host: {}  IP: {}".format(host, ip))
    lines.append("Run:  {}".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    lines.append("=" * 64)

    # ── OSPF Events ──────────────────────────────────────────────────────────
    print("  collecting: NE unreported events (filtering for OSPF)")
    raw_events = c.run("show ne events unreported | no-more")
    ospf = _parse_ospf_events(raw_events)

    lines += [
        "",
        "=" * 64,
        "  OSPF DOWN EVENTS",
        "  CMD: show ne events unreported  [python filter: ospf + down]",
        "=" * 64,
    ]
    if ospf["down"]:
        for ln in ospf["down"]:
            lines.append("  {}".format(ln))
    else:
        lines.append("  (none found)")

    lines += [
        "",
        "=" * 64,
        "  OSPF FULL / UP EVENTS",
        "  CMD: show ne events unreported  [python filter: ospf + full]",
        "=" * 64,
    ]
    if ospf["full"]:
        for ln in ospf["full"]:
            lines.append("  {}".format(ln))
    else:
        lines.append("  (none found)")

    if ospf["other"]:
        lines += [
            "",
            "=" * 64,
            "  OTHER OSPF EVENTS (no down/full keyword)",
            "=" * 64,
        ]
        for ln in ospf["other"]:
            lines.append("  {}".format(ln))

    # ── Fiber Light Levels ───────────────────────────────────────────────────
    for slot in FIBER_SLOTS:
        cmd = "show chassis transceiver information slot {} port1 | no-more".format(slot)
        print("  collecting: transceiver {} port1".format(slot))
        raw_xcvr = c.run(cmd)

        lines += [
            "",
            "=" * 64,
            "  FIBER LIGHT LEVELS -- {} port1".format(slot.upper()),
            "  CMD: show chassis transceiver information slot {} port1".format(slot),
            "=" * 64,
        ]

        levels = _parse_light_levels(raw_xcvr)
        if levels:
            for ln in levels:
                lines.append("  {}".format(ln))
        else:
            # Power-keyword parse found nothing -- dump full output so we don't lose data.
            body = [ln.rstrip() for ln in raw_xcvr.splitlines() if ln.rstrip()]
            if body:
                for ln in body:
                    lines.append("  {}".format(ln))
            else:
                lines.append("  (no data -- slot not present or no transceiver)")

    c.close()

    # Echo to console.
    print("")
    print("\n".join(lines))

    # Write output file.
    ts       = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = r"C:\Claude\ospf_events_{}_{}.txt".format(ts, host)
    try:
        with open(out_path, "w") as f:
            f.write("\n".join(lines))
        print("\n[written] {}".format(out_path))
    except Exception as e:
        print("\n[!] write failed: {}".format(e))
        return None

    # Optional JIRA post.
    if jira_ticket:
        print("\n[JIRA] Posting to {} ...".format(jira_ticket))
        intro = "OSPF events + fiber levels -- {} ({}), run {}.".format(
            host, ip, datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
        ok, msg = post_report(
            jira_ticket, intro,
            "OSPF Events + Fiber Levels -- {}".format(host),
            "\n".join(lines),
            attach_path=out_path)
        print("[JIRA] {}".format(msg) if ok else "[JIRA] FAILED: {}".format(msg))

    if open_when_done:
        try:
            os.startfile(out_path)
        except Exception as e:
            print("[!] could not auto-open: {}".format(e))

    return out_path


# ── Standalone entry point ───────────────────────────────────────────────────

def main():
    print("=" * 64)
    print("  OSPF EVENTS + FIBER LIGHT LEVELS (standalone)")
    print("=" * 64)
    params = collect_inputs()
    if params:
        run(params)


if __name__ == "__main__":
    main()
