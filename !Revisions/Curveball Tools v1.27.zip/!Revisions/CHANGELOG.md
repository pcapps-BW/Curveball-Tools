# Curveball Tools — Changelog

---

## v1.27 — 2026-08-04

### Report Layout
- **Autotester: Full Route + Diagnostic Summary now grouped per channel**
  (`autotester_standalone.py`)
  - Previously the report had two separate combined sections: one Diagnostic
    Summary block spanning every DS1, followed by every DS1's Full Route
    block. Now each DS1's Full Route is immediately followed by that same
    DS1's own Diagnostic Summary before moving to the next channel -- easier
    to digest one circuit at a time instead of cross-referencing two lists.
  - `build_diagnostic_summary` is now called once per DS1 (still the same
    function/logic, just scoped to a single-element list per call) instead of
    once for the whole run. Output content is unchanged, only the ordering.
  - The JIRA "Diagnostic Summary" panel is unaffected -- it's built from the
    same per-channel blocks concatenated together.

### New Features
- **GSX IP address in the Full Route block** (`output_builders.py`,
  `autotester_standalone.py`)
  - `HOP 4 -- GSX` now shows the resolved GSX management IP:
    ```
      HOP 4 -- GSX
        Node       : LAXGSX01
        IP         : 192.168.45.3
        Assignment : 11-2-27
        T1 Command : SHOW T1 T1-1-11-2-27
    ```
  - The IP is the live management address the Autotester actually reached
    (resolved via Netbox mgmt IPs + reachability ping, same value used to
    open the GSX session). Shows `?` if no reachable IP was resolved for that
    DS1 (mirrors the existing fallback convention used elsewhere).

---

## v1.26 — 2026-08-04

### Performance
- **1800 MUSE lookup batched per hub instead of per DS1** (`npt1800_client.py`)
  - Root cause of the "any show configuration | ... command is slow" complaint:
    the MUSE ID -> OC lookup (`show configuration | display-set | match
    "{muse_id} "`) issued that call **once per DS1**. The slowness is a
    device-side full-config render (~90-120s), and that render cost is paid
    per CALL, not per DS1 -- so a 4-DS1 run on one hub paid it 4 times
    (~6-8 minutes) for data a single render already contains.
  - New `_muse_lookup_batch()` issues **one render per hub**, matched against
    a regex alternation of every DS1's muse_id needed that run (Junos-style
    `match` supports `|` alternation), then groups the returned lines back to
    each muse_id locally in Python. Same source command, same selectivity
    (still only matches the muse_ids actually needed -- no broader/unscoped
    dump), just consolidated. This mirrors the pattern `npt1250_client.
    query_batch` already uses for `peer-address` (one render, parse many).
  - Net effect: an N-DS1 run on one hub now costs ~90-120s total instead of
    N * 90-120s. No output/behavior change -- verified the OC resolution and
    Peerless-customer detection are correctly scoped per-DS1 even when
    multiple DS1s share one combined render (unit-tested with a 2-DS1 mixed
    Peerless/non-Peerless fixture).
  - The separate OC alarm/PM stat commands (already deduped per unique OC,
    not a full-config render) keep their own smaller timeout, unaffected.

---

## v1.25 — 2026-08-04

### New Tools
- **mux_loop_script.py** — `MUX CEM Loop Script` (launcher order 60) — item 13
  - Generates a copy/paste-ready CEM hairpin loop MOP for a circuit. Does **not**
    execute any config — it connects only to run read-only prechecks, then writes
    a script the engineer pastes manually.
  - **Two input modes:**
    1. **1250 IP + DS1 (default)** — resolves the full route automatically
       (1250 → 1800 → MUX → GSX), the same path the Autotester walks, then fills
       every identifier into the script.
    2. **MUX-direct** — engineer supplies MUX IP / name / ACR / CEM group directly
       (plus optional other-hop info); only the MUX is queried. For when the route
       is already known or Netbox is unavailable.
  - **Prechecks are run live** against every reachable hop and the real output is
    embedded in the script as the baseline. **Postchecks are emitted as commands
    only** (run manually after testing).
  - Generates both scenarios from the MOP, with correct `connect` command syntax
    derived from the resolved ACR / CEM / GSX CE identifiers:
    - **Scenario A** — hairpin facing the **GSX** (`connect ... CEM{gsx} CEM{gsx}`),
      isolates the GSX; includes turn-up, validation, and restore.
    - **Scenario B** — hairpin facing the **1250** (`connect ... CEM-ACR{n} CEM-ACR{n}`),
      isolates the 1250/LEC; includes turn-up, validation, and restore.
  - Connection name (e.g. `CB_OC3_STS02_02`) is discovered automatically via
    `show run | include CEM-ACR{n}` — never typed by hand (new
    `get_connection_name()` in `mux4216_client.py`).
  - Peerless circuits are detected and rejected (no MUX/GSX hop to loop).
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA attachment, auto-opens.

---

## v1.24 — 2026-08-04

### New Features
- **Autotester CEM circuit health** (`mux4216_client.py`, `output_builders.py`,
  `autotester_standalone.py`) — item 14
  - The Autotester now checks CEM circuit health at the MUX hop, closing the gap
    between "the SONET path resolves" and "the emulated circuit is actually clean."
  - New `mux4216_client.query_cem_health()` pulls, per DS1:
    - `show cem circuit interface cem-acr {acr} {cem}` — Pkts Missing, Failure
      Counts, Lbits/Rbits (any non-zero = flagged)
    - `show xconnect all | include CE{acr}:{cem}(` — both legs UP
    - `show connection name {conn}` — Current State UP
    - `show acr group {acr} detail cem` — working/protect state
  - New `get_connection_name()` discovers the connection name automatically
    (shared with the loop-script tool).
  - **Diagnostic Summary** MUX block now shows `[ OK ]/[ !! ] CEM circuit`,
    `Connection UP`, and `Xconnect leg(s) DOWN` indicators.
  - **Run Summary** flags `MUX CEM: Pkts Missing=… / Failure Counts=…` with a
    "check MUX" suggestion.
  - **MUX Stats** section gains a `>> CEM Circuit Health` block with the raw
    circuit / xconnect / connection / ACR-detail output per DS1.
  - All additions are read-only; no change to how the route is resolved.

---

## v1.23 — 2026-08-04

### New Files
- **`Curveball Tools.bat`** — double-click launcher (item 7)
  - Opens a terminal window in the correct directory and runs `python launcher.py`
  - No need to navigate manually; works by double-click from anywhere

- **`Create Curveball Shortcut.ps1`** — one-time taskbar shortcut setup (item 7)
  - Right-click → **Run with PowerShell** (do not double-click — that opens Notepad,
    a Windows default for `.ps1` files)
  - Creates `Curveball Tools.lnk` on the Desktop, ready to right-click → Pin to taskbar

### Documentation
- **`README.md`** — updated tools table (added OSPF Events, GSX Perfmon), updated
  Running section and file list to include `.bat` and shortcut script
- **`INSTALL.md`** — added "Quick launch / Taskbar shortcut" section (step 4),
  updated Quick Setup Checklist

---

## v1.22 — 2026-08-04

### Bug Fixes
- **DS1 input normalization** — item 19 (`autotester_standalone.py`, `ds1_pms.py`)
  - DS1 entries are now lowercased on input, so `TS1/7` and `ts1/7` both work
  - `&` is now accepted as a separator in addition to `,` — entries like
    `TS1/23 & TS1/28` are split correctly instead of being treated as one item

---

## v1.21 — 2026-08-04

### Bug Fixes
- **output_builders.py** — MUX DS1_AIS direction annotation (item 17)
  - `[ !! ] MINOR DS1_AIS` in the diagnostic output now appends
    `(AIS from LEC/1250 direction -- signal loss at bottom of route)`
  - DS1_AIS on the MUX T1 path means the 1800 is inserting AIS into the SONET
    payload because the 1250 is not delivering a valid DS1 — the fault is on the
    LEC/customer side, not the IXC side

- **output_builders.py** — GSX PM interval label in diagnostic header (item 18)
  - GSX node header now reads `GSX -- NYCGSX02  (current 15 min / 24 hr)` instead
    of just `GSX -- NYCGSX02`
  - Clarifies that the `[ !! ]` error counts shown are the max across the current
    15-minute interval and current 24-hour interval (whichever is higher), not
    cumulative statistics

---

## v1.20 — 2026-08-04

### New Tools
- **gsx_perfmon.py** — `GSX Perfmon (96 Intervals)` (launcher order 55)
  - Pulls a complete 24-hour picture of a single T1 on the GSX:
    - `SHOW T1 ... STATUS`
    - `SHOW T1 ... STATISTICS`
    - `SHOW T1 ... PERFMON CURRENT DAY`
    - `SHOW T1 ... PERFMON THRESHOLDS`
    - `SHOW T1 ... PERFMON INTERVAL N FIFTEENMIN` for all 96 intervals
      (interval 1 = most recent, interval 96 = oldest, ~24 hours back)
  - T1 assignment accepts full form (`T1-1-7-2-2`) or short form (`7-2-2`)
  - Reuses GSX credentials from session (no re-prompt if already entered this session)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post with attachment
    fallback, and auto-opens the file
  - Useful for stress-test planning: reveals error frequency and timing so test
    durations are grounded in real failure patterns

---

## v1.19 — 2026-08-04

### New Features
- **MUX controller description fallback** (`mux4216_client.py`) — item 12
  - When Netbox has no OC→SONET mapping for a circuit (e.g. ts3 not yet populated),
    the autotester now tries a second resolution method before falling back to the
    unreliable legacy ACR-guess
  - New method `find_acr_by_description(hub_hostname, slot_port)` scans
    `show run | section controller` on the MUX and looks for a SONET-ACR stanza
    whose description matches `{1800-hostname} {OC-slot/port}`
    (e.g. `ces01.lax1 ts3/1`). Case-insensitive.
  - If matched, uses that ACR number to resolve VTG / T1 / CEM group directly —
    the same path as a successful Netbox lookup, but without Netbox
  - On success: marks `netbox_conflict` with a reminder to populate Netbox
  - Resolution tier order is now:
    1. Netbox `oc_to_sonet` (most accurate, verifies path)
    2. MUX description scan (accurate, works without Netbox)
    3. Legacy ACR-guess (shotgun, last resort)
  - No changes to `autotester_standalone.py` — fallback is entirely inside
    `query_batch`

---

## v1.18 — 2026-08-04

### Bug Fixes
- **Dynamic OC type labeling** — autotester no longer hardcodes "OC12" in output
  - The 1800 regex already captured any OC speed (`oc12`, `oc48`, `oc3`, etc.); only
    the display labels were wrong
  - Added `_oc_label(oc_iface)` helper in `output_builders.py` that extracts the
    speed from the interface identifier (e.g. `oc48-ts20/1:13:1` → `"OC48"`)
  - All user-facing "OC12" label strings replaced in:
    - `output_builders.py` — route blocks, peerless block, full diagnostic block,
      run summary findings and suggestions
    - `npt1800_client.py` — stat section header and "could not find" error message
    - `autotester_standalone.py` — "NPT-1800 OC STATS" section header
    - `mux4216_client.py` — internal `Cannot parse OC interface` error text

---

## v1.17 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display now distinguishes "disabled" from "clean"
  - When the device returns "switch of this interface object is off" (PMs not enabled), `npt1250_client` already writes `"CES PMs not enabled on this DS1."` into the PM blob
  - `build_diagnostic_summary` now detects that marker and shows `[ -- ] CES PMs disabled` instead of `[ OK ] CES PMs clean`
  - Applies to both the full-route and peerless diagnostic blocks

---

## v1.16 — 2026-08-04

### New Features
- **IP address validation** on all manual IP entry prompts
  - Rejects entries that aren't 4 octets with each octet 0–255 (e.g. `192.168.270.1` or `192.168.150` both fail)
  - Re-prompts in a loop until a valid IP is entered — no more silent TCP failures from a typo
  - Implemented via `prompt_ip()` in `device_base.py`; wired into autotester, health check, fiber util, DS1 PMs, discovery, and OSPF events

### Bug Fixes
- **output_builders.py** — incomplete route now returns FAIL in run summary
  - When Netbox data is missing (1800/OC12 not resolved, hub IP unknown, or MUX not found), `run_summary_line` now returns `FAIL | Route incomplete: ... | Check Netbox` instead of `PASS | All clean`

---

## v1.15 — 2026-08-04

### Bug Fixes
- **Bad credential loop fixed** across all tools
  - Previously: auth failure was silently swallowed, bad creds stayed in the session, every subsequent run re-used them with no way to re-enter without quitting
  - Now: `CredentialError` (new exception in `device_base.py`) is raised on `AuthenticationException` (paramiko) or "Access denied" in plink output (GSX)
  - `launcher.py` catches it in `dispatch()`, prints the rejection message, and clears **only the failing cred pair** (`infra` or `gsx`) from the session — the user is re-prompted on the very next tool run without restarting the launcher
  - Files changed: `device_base.py`, `gsx_client.py`, `launcher.py`, `autotester_standalone.py`, `health_check.py`, `fiber_util.py`, `ds1_pms.py`, `interface_check.py`, `npt1250_discovery.py`, `ospf_events.py`

---

## v1.14 — 2026-08-04

### Bug Fixes
- **output_builders.py** — Run Summary CES reporting now shows the worst error, not the first
  - Previous logic stopped at the first CES counter it found (e.g. `RxPsnOverrunEvents=8`) even when a more severe counter was present (`RxPsnES=1627`)
  - Now scans all CES counters and reports the one with the highest value in the run summary line

---

## v1.13 — 2026-08-04

### Bug Fixes
- **output_builders.py** — CES PM display placement corrected (NOE-4503)
  - CES PMs now appear **above** the `1250 --` identifier line (`[ !! ] CES ...` / `[ OK ] CES PMs clean`)
  - Removed the duplicate CES block that was also appearing below the `ds1-tsX/Y MUSE_XXXX` line
  - TDM PMs remain below the identifier line, unchanged
  - Fix applied to both the full route block and the peerless block

---

## v1.12 — 2026-08-04

### New Tools
- **ospf_events.py** — `OSPF Events + Fiber Levels` (launcher order 45)
  - Pulls `show ne events unreported` and filters in Python for OSPF state changes
  - Separate sections for DOWN events and FULL/UP events; catch-all for other OSPF lines
  - Also checks fiber transceiver light levels on ts2 and ts5 (TX/RX power)
  - Saves timestamped `.txt` to `C:\Claude\`, supports JIRA post and auto-open

### Bug Fixes
- **jira_client.py** — JIRA `CONTENT_LIMIT_EXCEEDED` fallback
  - When a report is too large to post as a comment (HTTP 400), the script now:
    1. Posts a short stub comment noting the attachment
    2. Uploads the `.txt` output file directly as a JIRA attachment
  - Affects all tools: autotester, health check, fiber util, DS1 PMs, interface check, discovery, and the new OSPF events tool

---

## v1.11 — (prior release)

*(No changelog maintained before v1.12 — see git history or `!Revisions/` zip archive for earlier changes.)*
