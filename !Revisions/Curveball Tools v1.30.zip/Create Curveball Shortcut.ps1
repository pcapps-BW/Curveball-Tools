# HOW TO RUN THIS:
# Right-click this file -> "Run with PowerShell"
# (Double-clicking opens Notepad -- that's a Windows default, not a bug)
#
# After running, "Curveball Tools" will appear on your Desktop.
# Right-click it -> "Pin to taskbar"

$ToolsPath  = "C:\Claude\Scripts\Curveball Tools"
$BatchFile  = "$ToolsPath\Curveball Tools.bat"
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "Curveball Tools.lnk"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)

# Target cmd.exe running the .bat -- most reliable for taskbar pinning
$Shortcut.TargetPath       = "C:\Windows\System32\cmd.exe"
$Shortcut.Arguments        = "/k `"$BatchFile`""
$Shortcut.WorkingDirectory = $ToolsPath
$Shortcut.WindowStyle      = 1
$Shortcut.Description      = "Launch Curveball Tools"
$Shortcut.IconLocation     = "C:\Windows\System32\cmd.exe,0"
$Shortcut.Save()

Write-Host ""
Write-Host "  Done! 'Curveball Tools' shortcut created on your Desktop."
Write-Host ""
Write-Host "  To pin to taskbar:"
Write-Host "    Right-click 'Curveball Tools' on your Desktop"
Write-Host "    -> 'Pin to taskbar'"
Write-Host ""
pause
