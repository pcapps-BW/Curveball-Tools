#!/usr/bin/env python3
"""
app.py -- Curveball Tools web front end (proof of concept).

Wraps the Autotester (autotester_standalone.py) in a small Flask app so it
can be run from a browser instead of a terminal. This is a THIN wrapper --
it does not touch any of the existing tool/client modules' logic. It:

  1. Serves a form (templates/index.html) with the same fields
     autotester_standalone.collect_inputs() would prompt for. The web layer
     builds its own `params` dict and calls autotester_standalone.run(params)
     directly -- collect_inputs() itself is never called here, because it
     calls input()/getpass() which would hang with no terminal attached.

  2. Runs each submitted job in a background thread (NOT the Flask request
     thread) so a multi-minute Autotester run doesn't tie up an HTTP
     connection. The browser polls /api/job/<id> every couple seconds for
     status, an elapsed-time counter, and a "this may be hung" warning past
     a threshold -- no full line-by-line progress streaming yet (that's a
     natural v2 on top of this same job-polling scaffolding).

  3. Credentials are POSTed fresh on every run (masked form fields) and held
     only in the params dict passed into the background thread -- never
     written to disk, never put in a session/cookie.

KNOWN POC LIMITATIONS (see the walkthrough for detail):
  - In-memory JOBS dict -- job history is lost on restart, and nothing ever
    evicts old entries. Fine for a POC; would want a real store + cleanup
    before this is a shared, long-running service.
  - "Hung" is a WARNING, not a kill switch. Python threads can't be force-
    stopped; a stuck job will keep running until its own underlying SSH
    timeouts trip. A process-per-job model would allow real cancellation,
    if that's ever needed.
  - Runs with Flask's built-in dev server + debug=True. That's fine on
    localhost. Turn debug OFF and put a real WSGI server (waitress) in
    front of it before this is reachable from anywhere but your own machine
    -- Flask's debugger allows arbitrary code execution if ever exposed.

Built by P. Capps.
"""

import os
import re
import time
import uuid
import threading

from flask import Flask, render_template, request, jsonify, send_file, abort

import autotester_standalone
from device_base import CredentialError
from jira_client import valid_ticket

app = Flask(__name__)

# ---- in-memory job store ----
JOBS = {}
JOBS_LOCK = threading.Lock()


def _valid_ip(s):
    parts = (s or "").strip().split(".")
    return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


def _warn_after(ds1_count):
    """Seconds before the UI flags a running job as possibly hung.
    Scales gently with DS1 count -- mirrors the per-batch timeout heuristics
    already used inside the device clients, just for the browser's benefit."""
    return max(300, ds1_count * 90)


def _run_job(job_id, params):
    """Background-thread target. Never touches the Flask request/response --
    only writes into JOBS[job_id] under the lock."""
    try:
        out_path = autotester_standalone.run(params)
        report_text = ""
        if out_path and os.path.exists(out_path):
            with open(out_path, "r", errors="ignore") as f:
                report_text = f.read()
        elif not out_path:
            report_text = "(Autotester finished without producing a report file -- check the server console for details.)"
        with JOBS_LOCK:
            JOBS[job_id].update(
                status="done", finished=time.time(),
                report=report_text, path=out_path)
    except CredentialError as e:
        with JOBS_LOCK:
            JOBS[job_id].update(
                status="error", finished=time.time(),
                error="Credential error ({}): {}".format(e.cred_type, e))
    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id].update(
                status="error", finished=time.time(),
                error="{}: {}".format(type(e).__name__, e))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/autotester/run", methods=["POST"])
def api_autotester_run():
    f = request.form

    ip_1250 = (f.get("ip_1250") or "").strip()
    if not _valid_ip(ip_1250):
        return jsonify(error="Enter a valid 1250 IP (4 octets, e.g. 10.111.131.77)."), 400

    ds1_raw = (f.get("ds1_list") or "").strip()
    ds1_list = [d.strip().lower() for d in ds1_raw.replace("&", ",").split(",") if d.strip()]
    if not ds1_list:
        return jsonify(error="Enter at least one DS1 (e.g. ts3/8, ts3/9)."), 400

    infra_user = (f.get("infra_user") or "").strip()
    infra_pass = f.get("infra_pass") or ""
    gsx_user = (f.get("gsx_user") or "").strip()
    gsx_pass = f.get("gsx_pass") or ""
    if not (infra_user and infra_pass and gsx_user and gsx_pass):
        return jsonify(error="Infrastructure and GSX credentials are both required."), 400

    jira_ticket = None
    if f.get("add_jira") == "on":
        raw_ticket = (f.get("jira_ticket") or "").strip().upper()
        if raw_ticket:
            if not valid_ticket(raw_ticket):
                return jsonify(error="JIRA ticket must look like NOE-1234."), 400
            jira_ticket = raw_ticket

    params = {
        "ip_1250": ip_1250,
        "ds1_list": ds1_list,
        "infra_user": infra_user,
        "infra_pass": infra_pass,
        "gsx_user": gsx_user,
        "gsx_pass": gsx_pass,
        "jira_ticket": jira_ticket,
        # Only meaningful when the server and browser are the same machine
        # (the local POC case) -- os.startfile() opens the file on whatever
        # machine is running app.py, not on the browser's machine. See the
        # form caption and WEB_SETUP.md.
        "open_when_done": f.get("open_when_done") == "on",
    }

    job_id = uuid.uuid4().hex
    with JOBS_LOCK:
        JOBS[job_id] = {
            "status": "running",
            "started": time.time(),
            "finished": None,
            "report": None,
            "path": None,
            "error": None,
            "ds1_count": len(ds1_list),
            "warn_after": _warn_after(len(ds1_list)),
            "ip_1250": ip_1250,
        }

    t = threading.Thread(target=_run_job, args=(job_id, params), daemon=True)
    t.start()

    return jsonify(job_id=job_id)


@app.route("/api/job/<job_id>")
def api_job_status(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify(error="Unknown job id."), 404
        job = dict(job)   # shallow copy for a consistent snapshot

    now = job["finished"] or time.time()
    elapsed = now - job["started"]
    warning = job["status"] == "running" and elapsed > job["warn_after"]

    resp = {
        "status": job["status"],
        "elapsed": int(elapsed),
        "warning": warning,
        "ip_1250": job["ip_1250"],
    }
    if job["status"] == "done":
        resp["report"] = job["report"]
        resp["download_url"] = "/download/{}".format(job_id)
    elif job["status"] == "error":
        resp["error"] = job["error"]

    return jsonify(**resp)


@app.route("/download/<job_id>")
def download(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job or job["status"] != "done" or not job["path"] or not os.path.exists(job["path"]):
        abort(404)
    return send_file(job["path"], as_attachment=True)


if __name__ == "__main__":
    print("=" * 64)
    print("  Curveball Tools -- Web (proof of concept)")
    print("  Open http://127.0.0.1:5000 in a browser")
    print("=" * 64)
    # debug=True is fine on localhost only -- see the module docstring.
    app.run(host="127.0.0.1", port=5000, debug=True, threaded=True)
