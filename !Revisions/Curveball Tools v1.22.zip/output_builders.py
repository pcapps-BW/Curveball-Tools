#!/usr/bin/env python3
"""
output_builders.py -- Stage B polished output for the standalone Autotester.

Faithful port of the SecureCRT builders:
  - build_route_block        (FULL T1 ROUTE, HOP 1-4 + SUMMARY)
  - build_peerless_block     (PARTIAL T1 ROUTE, ends at 1800)
  - build_diagnostic_summary (per-DS1 vertical route w/ [ OK ]/[ !! ] + X connectors)
  - run_summary_line         (one-liner PASS + findings + fault-direction suggestion)

The 'X' between hops is intentional (NOT '|' -- a pipe breaks JIRA table rendering).

Built by P. Capps.
"""

import re

SEP  = "=" * 58
SEP2 = "-" * 58


# ---- helpers ----
def _ok_or(flagged, label):
    return "[ !! ] {}".format(label) if flagged else "[ OK ] {}".format(label)


def _check_counters(text, counters):
    """Return ['COUNTER: value', ...] for any non-zero counter found in text."""
    hits = []
    for c in counters:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(re.escape(c)), text)
        if m:
            hits.append("{}: {}".format(c, m.group(1)))
    return hits


def _oc_label(oc_iface):
    """Derive the OC speed label from an interface identifier.
    'oc48-ts20/1:13:1' -> 'OC48', 'oc12-ts2/1:6:3' -> 'OC12',
    'oc-ts5/1:2:1' -> 'OC', '' or None -> 'OC'.
    """
    m = re.match(r'oc(\d+)-', (oc_iface or '').lower())
    return "OC{}".format(m.group(1)) if m else "OC"


# Marker written by npt1250_client.query_ds1_pms when the device returns
# "switch of this interface object is off" (pm-collection-enable not set).
_CES_DISABLED_RE = re.compile(r'CES PMs not enabled', re.IGNORECASE)

CES_COUNTERS = [
    "RxPsnLostPkts", "RxPsnOverrunEvents", "RxPsnUnderrunEvents",
    "RxPsnLopsEvents", "RxPsnES", "RxPsnSES", "RxPsnUAS",
    "TxPsnDiscardPkts", "RxPsnOowDiscardPkts",
]
TDM_COUNTERS = ["DS1ES-L", "DS1SES-L", "DS1CV-L", "DS1LOSS-L", "DS1UAS-L"]
OC12_COUNTERS = ["ES-S", "SES-S", "CV-S", "SEFS-S", "ES-L", "SES-L", "CV-L", "UAS-L"]
T3_COUNTERS = [
    "P-bit Coding Violation", "C-bit Coding Violation", "P-bit Err Secs",
    "Unavailable Secs", "Line Errored Secs", "AIS Defect Secs", "LOS Defect Secs",
]

# GSX PERFMON is columnar: "<Counter>:   <errors>   <Minor> <Major> <Critical>"
# e.g. "Unavailable Seconds:              772       TRUE    TRUE    TRUE"
# We check the leading Errors value (first number after the colon).
#
# IMPORTANT: only the "PERFMON CURRENT" sections hold actual error counts.
# The "PERFMON THRESHOLDS" section lists CONFIG LIMITS (e.g. "Line Errored
# Seconds: 518 648 778") using similar names -- those must NOT be read as
# errors, or a healthy circuit gets falsely flagged. We therefore scan only
# the current-performance region and stop at the THRESHOLDS section.
GSX_PM_COUNTERS = [
    "Code Violations", "Errored Seconds", "Severely Errored Seconds",
    "SEF/AIS Seconds", "Controlled Slip Seconds", "Unavailable Seconds",
]

# ---- Fiber (GE uplink) physical-layer health ----
# Physical PM error counters on the 1250 fiber ports (ge-ts2/1, ge-ts5/1).
# Flag any of these that read > 0. The last group (PCS/FEC) reads N/A on 1G
# optics; flag only when numeric and > 0.
FIBER_ERR_COUNTERS = [
    "Rx Error Pkts",
    "Rx CRC Align Error Pkts",
    "Collision Errors",
    "Rx Jabber Pkts",
    "Rx Fragments",
    "Rx Undersize Pkts",
    "Rx Oversize Pkts",
    "PCS-ES", "PCS-SES", "PCS-UAS", "FEC-UCE",
]
# Received optical power floor. Rx weaker (more negative) than this is flagged.
# (TX is shown but NOT flagged for now -- pending a per-transceiver threshold
#  command that will supply real per-optic limits; see TODO.)
FIBER_RX_DBM_FLOOR = -10.0

# ---- NNI resolution + physical-NNI (1800-side) health ----
def _optical_value(text, field):
    """Return float dBm for an optical field (MinRxPower/TxPower), else None."""
    m = re.search(r'^\s*' + re.escape(field) + r'\s*:\s*(-?\d+\.?\d*)',
                  text, re.MULTILINE)
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            return None
    return None


def resolve_nni_from_description(desc_output):
    """
    Parse 'show interfaces description | grep <prefix>' output from the 1800.
    Returns (logical_iface, physical_iface, status):
      status 'ok'        -> one NNI found; logical e.g. xe-ts13/3.570,
                            physical e.g. xe-ts13/3
      status 'none'      -> no interface line matched
      status 'ambiguous' -> matched >1 distinct physical interface (can't tell
                            which circuit -> caller flags + skips)
    """
    ifaces = []
    for line in (desc_output or "").splitlines():
        m = re.match(r'^\s*([a-z]+-ts\d+/\d+(?:\.\d+)?)\b', line)
        if m:
            ifaces.append(m.group(1))
    ifaces = sorted(set(ifaces))
    if not ifaces:
        return None, None, "none"
    # group by physical base (xe-ts13/3.570 -> xe-ts13/3); one base = one NNI
    bases = {}
    for name in ifaces:
        bases.setdefault(name.split(".")[0], []).append(name)
    if len(bases) > 1:
        return None, None, "ambiguous"
    base = list(bases)[0]
    subs = [n for n in bases[base] if "." in n]
    logical = subs[0] if subs else base
    return logical, base, "ok"


def check_nni_health(physical_pm):
    """
    Physical NNI health (1800 side) from 'show interfaces physical pm'.
    Flags FIBER_ERR_COUNTERS > 0 and MinRxPower < floor. Returns (flags, info).
    Optical fields here are MinRxPower/TxPower (not the transceiver 'laser'
    format used on the 1250). TX shown in info, not flagged.
    """
    flags, info = [], []
    for counter in FIBER_ERR_COUNTERS:
        val = _fiber_counter_value(physical_pm, counter)
        if val is not None and val > 0:
            flags.append("{}: {}".format(counter, val))
    rx = _optical_value(physical_pm, "MinRxPower")
    tx = _optical_value(physical_pm, "TxPower")
    if rx is not None and rx < FIBER_RX_DBM_FLOOR:
        flags.append("Rx power {} dBm (< {})".format(rx, FIBER_RX_DBM_FLOOR))
    if rx is not None or tx is not None:
        info.append("NNI optics  Rx {} / Tx {} dBm".format(
            rx if rx is not None else "?", tx if tx is not None else "?"))
    return flags, info


# ---- Logical EVC / sub-interface health ----
# Logical sub-interface PM (ge-tsX/1.0 on the 1250; xe-tsX/Y.VLAN on the 1800).
# Flag Rx packet discards (> 0), reported as the raw count plus the discard
# ratio: discards / (Rx Pass Pkts + Rx Discard Pkts), as a percent -- so a
# large-looking count can be judged in context (321765 is alarming alone, but
# ~0.1% of traffic is usually not). Packets only; octets are not flagged.
# Tx Discard reads "NA" on these platforms and is ignored.


def check_evc_health(evc_by_iface):
    """
    Shared logical-EVC health check for the DIAGNOSTIC SUMMARY.

    evc_by_iface: {iface_name: <logical pm text>}
    Returns list of "[ !! ]"-worthy flag strings (empty if no Rx discards).
    Each flag: "<iface> Rx Discard Pkts: <n> (<pct>)".
    """
    flags = []
    for iface in sorted(evc_by_iface):
        pm = evc_by_iface[iface] or ""
        discard = _fiber_counter_value(pm, "Rx Discard Pkts")
        if discard is None or discard <= 0:
            continue
        passed = _fiber_counter_value(pm, "Rx Pass Pkts")
        if passed is not None and (passed + discard) > 0:
            ratio = discard / float(passed + discard) * 100.0
            pct = "{:.2f}%".format(ratio) if ratio >= 0.01 else "<0.01%"
        else:
            pct = "ratio n/a"
        flags.append("{} Rx Discard Pkts: {} ({})".format(iface, discard, pct))
    return flags



def _fiber_counter_value(pm_text, counter):
    """Return int value of a fiber PM counter, or None if absent/N/A."""
    # lines look like:  "Rx CRC Align Error Pkts    :  0"
    m = re.search(r'^\s*' + re.escape(counter) + r'\s*:\s*(\S+)',
                  pm_text, re.MULTILINE)
    if not m:
        return None
    tok = m.group(1)
    if tok.upper() == "N/A":
        return None
    try:
        return int(tok)
    except ValueError:
        return None


def _fiber_laser_rx_tx(laser_text):
    """Return (rx_dbm, tx_dbm) floats from '| grep laser' output, None if absent."""
    rx = tx = None
    mrx = re.search(r'Rx-laser-power[^:]*:\s*(-?\d+\.?\d*)', laser_text)
    mtx = re.search(r'Tx-laser-power[^:]*:\s*(-?\d+\.?\d*)', laser_text)
    if mrx:
        try: rx = float(mrx.group(1))
        except ValueError: pass
    if mtx:
        try: tx = float(mtx.group(1))
        except ValueError: pass
    return rx, tx


def check_fiber_health(fiber_by_port):
    """
    Shared fiber/IXC uplink health check for the DIAGNOSTIC SUMMARY.

    fiber_by_port: {port_name: {"pm": <physical pm text>, "laser": <grep laser text>}}
       (pm may be the concatenation of the 24hour + 15min PM output)

    Returns (flags, info):
      flags -- list of "[ !! ]"-worthy strings (error counters >0, Rx laser < floor)
      info  -- list of informational strings (laser Rx/Tx levels per port)
    TX laser is reported in `info` only (not flagged) for now.
    """
    flags, info = [], []
    for port in sorted(fiber_by_port):
        data = fiber_by_port[port] or {}
        pm    = data.get("pm", "") or ""
        laser = data.get("laser", "") or ""

        for counter in FIBER_ERR_COUNTERS:
            val = _fiber_counter_value(pm, counter)
            if val is not None and val > 0:
                flags.append("{} {}: {}".format(port, counter, val))

        rx, tx = _fiber_laser_rx_tx(laser)
        if rx is not None and rx < FIBER_RX_DBM_FLOOR:
            flags.append("{} Rx laser {} dBm (< {})".format(port, rx, FIBER_RX_DBM_FLOOR))
        if rx is not None or tx is not None:
            info.append("{} laser  Rx {} / Tx {} dBm".format(
                port,
                "{}".format(rx) if rx is not None else "?",
                "{}".format(tx) if tx is not None else "?"))
    return flags, info



def _gsx_current_perf_region(text):
    """
    Return only the portion of GSX output that holds CURRENT performance data
    (PERFMON CURRENT FIFTEENMIN / DAY), excluding the THRESHOLDS config table
    and the STATISTICS block. Returns "" if no current-perf section is found.
    """
    region = []
    capture = False
    for line in text.splitlines():
        up = line.upper()
        if "PERFMON CURRENT" in up or "CURRENT PERFORMANCE" in up or "CURRENT DAY PERFORMANCE" in up:
            capture = True
        elif "THRESHOLD" in up:
            capture = False   # stop before the config-limits table
        elif up.strip().startswith("CMD:") and "PERFMON" not in up:
            capture = False
        if capture:
            region.append(line)
    return "\n".join(region)


def _check_gsx_counters(text):
    """
    Return ['Counter: value', ...] for any non-zero GSX PERFMON counter, read
    ONLY from the current-performance region (never the THRESHOLDS table).
    A counter can appear twice (Near End / Far End Path); report the max seen.
    The leading anchor (start-of-line) avoids matching 'Code Violations' inside
    'Line Code Violations' / 'Path Code Violations'.
    """
    region = _gsx_current_perf_region(text)
    if not region:
        return []
    hits = {}
    for c in GSX_PM_COUNTERS:
        # ^\s* anchors to the start of the line so "Code Violations:" does not
        # match "Line Code Violations:" or "Path Code Violations:".
        pat = re.compile(r'^\s*{}\s*:\s+([0-9]+)\b'.format(re.escape(c)), re.MULTILINE)
        for m in pat.finditer(region):
            val = int(m.group(1))
            if val > 0:
                hits[c] = max(hits.get(c, 0), val)
    return ["{}: {}".format(c, v) for c, v in hits.items()]


# ---- FULL ROUTE BLOCK ----
def build_route_block(ds1, host_1250, loopback_ip, muse_id,
                      hub_name, hub_ip, oc12, mux_data):
    gsx_assign = "{}-{}-{}".format(
        mux_data.get("gsx_slot") or "?",
        mux_data.get("gsx_port") or "?",
        mux_data.get("gsx_t1")   or "?")
    lines = [
        SEP,
        "  FULL T1 ROUTE  --  {}".format(ds1.upper()),
        SEP, "",
        "  HOP 1 -- NPT-1250",
        "    Host       : {}".format(host_1250),
        "    Loopback   : {}".format(loopback_ip),
        "    DS1        : {}".format(ds1),
        "    MUSE       : {}".format(muse_id),
        "", SEP2,
        "  HOP 2 -- NPT-1800 Hub",
        "    Hub        : {}".format(hub_name),
        "    IP         : {}".format(hub_ip),
        "    {:<10} : {}".format(_oc_label(oc12), oc12),
        "", SEP2,
        "  HOP 3 -- Cisco NCS 4216 MUX",
        "    MUX        : {}".format(mux_data.get("mux_name", "?")),
        "    IP         : {}".format(mux_data.get("mux_ip", "?")),
        "    Active Path: SONET {}".format(mux_data.get("active_sonet") or "?"),
        "    ACR Group  : {}".format(mux_data.get("acr_group", "?")),
        "    CEM Group  : {} (VTG {}, T1 {})".format(
            mux_data.get("cem_group", "?"),
            mux_data.get("vtg") or "?",
            mux_data.get("t1")  or "?"),
        "    GSX CE     : CE{}:{}".format(
            mux_data.get("gsx_ce_iface", "?"), mux_data.get("gsx_cem_id", "?")),
        "", SEP2,
        "  HOP 4 -- GSX",
        "    Node       : {}".format(mux_data.get("gsx_node") or "?"),
        "    Assignment : {}".format(gsx_assign),
        "    T1 Command : SHOW T1 T1-1-{}".format(gsx_assign),
        "", SEP,
        "  SUMMARY",
        "  1250 {}  |  {}  |  {}".format(ds1, muse_id, oc12),
        "  {} ACR {} CEM {}  |  CE{}:{}  |  {} {}".format(
            mux_data.get("mux_name", "?"), mux_data.get("acr_group", "?"),
            mux_data.get("cem_group", "?"),
            mux_data.get("gsx_ce_iface", "?"), mux_data.get("gsx_cem_id", "?"),
            mux_data.get("gsx_node") or "?", gsx_assign),
        SEP,
    ]
    return "\n".join(lines)


# ---- PEERLESS (PARTIAL) ROUTE BLOCK ----
def build_peerless_block(ds1, host_1250, loopback_ip, muse_id,
                         hub_name, hub_ip, oc12, slot_num):
    lines = [
        SEP,
        "  PARTIAL T1 ROUTE  --  {}".format(ds1.upper()),
        "  NOTE: ts{} detected. No Bandwidth MUX or GSX. Peerless circuit.".format(slot_num),
        SEP, "",
        "  HOP 1 -- NPT-1250",
        "    Host       : {}".format(host_1250),
        "    Loopback   : {}".format(loopback_ip),
        "    DS1        : {}".format(ds1),
        "    MUSE       : {}".format(muse_id),
        "", SEP2,
        "  HOP 2 -- NPT-1800 Hub",
        "    Hub        : {}".format(hub_name),
        "    IP         : {}".format(hub_ip),
        "    {:<10} : {}".format(_oc_label(oc12), oc12),
        "", SEP,
        "  Route ends at 1800 -- ts21/ts24 is customer-facing (Peerless).",
        SEP,
    ]
    return "\n".join(lines)


# ---- DIAGNOSTIC SUMMARY (vertical route, OK/!! indicators, X connectors) ----
def build_diagnostic_summary(ds1_list, ds1_map, pm_results, oc12_results,
                             hub_results, mux_results, all_oc12_stats,
                             all_t3_stats, peerless, errors, gsx_pm_results=None,
                             fiber_results=None, evc_results=None):
    gsx_pm_results = gsx_pm_results or {}
    fiber_results = fiber_results or {}
    evc_results = evc_results or {}
    # Fiber uplink (NNI physical) + EVC (logical) health are per-1250 (shared by
    # all DS1s in the run); compute once.
    fiber_flags, fiber_info = check_fiber_health(fiber_results) if fiber_results else ([], [])
    evc_flags = check_evc_health(evc_results) if evc_results else []

    def _emit_1800_nni(hub, out):
        """Render the 1800 NNI/EVC health lines (the 'bottom' of the 1800 block)."""
        nni = (hub or {}).get("nni") or {}
        status = nni.get("status")
        if not status:
            return  # no NNI data collected (older run / not available)
        if status == "ambiguous":
            out.append("  [ !! ] NNI ambiguous ({} matches) -- not checked".format(
                nni.get("prefix", "?")))
            return
        if status in ("none", "error"):
            out.append("  [ .. ] NNI not resolved ({})".format(status))
            return
        nflags, ninfo = check_nni_health(nni.get("phys_pm", ""))
        phys = nni.get("physical", "?")
        if nflags:
            for f in nflags:
                out.append("  [ !! ] NNI {} {}".format(phys, f))
        else:
            out.append("  [ OK ] NNI {} PMs clean".format(phys))
        for i in ninfo:
            out.append("         {}".format(i))
        eflags = check_evc_health({nni.get("logical", "evc"): nni.get("evc_pm", "")})
        if eflags:
            for f in eflags:
                out.append("  [ !! ] EVC {}".format(f))
        else:
            out.append("  [ OK ] EVC {} PMs clean".format(nni.get("logical", "?")))

    lines = []

    for ds1 in ds1_list:
        lines.append(SEP)
        lines.append("  DIAGNOSTIC SUMMARY  --  {}".format(ds1.upper()))
        lines.append(SEP)
        lines.append("")

        if ds1 in errors:
            lines.append("  COLLECTION FAILED: {}".format(errors[ds1]))
            lines.append("")
            continue

        pm   = pm_results.get(ds1, "")
        oc12 = oc12_results.get(ds1, "")
        oc_lbl = _oc_label(oc12)
        hub  = hub_results.get(ds1, {})
        mux  = mux_results.get(ds1, {})
        oc12_base = oc12.split(":")[0] if oc12 else ""
        oc12_key  = "{}|{}".format(hub.get("hub_ip", ""), oc12_base)
        oc12_stat = all_oc12_stats.get(oc12_key, "")
        fa        = mux.get("facility_alarm", "")
        gsx_node  = mux.get("gsx_node", "?")
        gsx_slot  = mux.get("gsx_slot", "?")
        gsx_port  = mux.get("gsx_port", "?")
        gsx_t1    = mux.get("gsx_t1", "?")
        gsx_assign = "{}-{}-{}".format(gsx_slot, gsx_port, gsx_t1)

        # common 1250 TDM/CES detection
        ces_hits = _check_counters(pm, CES_COUNTERS)
        tdm_hits = _check_counters(pm, TDM_COUNTERS)
        phys_los  = bool(re.search(r'ds1/\d+\s+LOS', pm))
        alarm_los = bool(re.search(r'DS1LOS-L', pm) and
                         re.search(r'port-name=ds1-{}'.format(re.escape(ds1)), pm, re.IGNORECASE))
        oc12_errs = _check_counters(oc12_stat, OC12_COUNTERS)
        oc12_alarms = [l.strip() for l in oc12_stat.splitlines()
                       if "R-DS1AIS-P" in l or "AIS-V" in l]

        if ds1 in peerless:
            lines.append("  Peerless circuit (ts{}).".format(peerless[ds1]))
            lines.append("")
            lines.append("         Peerless Network")
            lines.append("")
            lines.append("              X")
            lines.append("")
            # 1800
            for e in oc12_errs:
                lines.append("  [ !! ] {} PM {}".format(oc_lbl, e))
            if not oc12_errs:
                lines.append("  [ OK ] {} PMs clean".format(oc_lbl))
            lines.append("  {}".format(
                _ok_or(oc12_alarms, "{} alarms ({} present)".format(oc_lbl, len(oc12_alarms))
                       if oc12_alarms else "{} alarms clean".format(oc_lbl))))
            lines.append("         {}".format(oc12))
            lines.append("         1800  --  {}  ({})".format(
                hub.get("hub_name", "?"), hub.get("hub_ip", "?")))
            _emit_1800_nni(hub, lines)
            lines.append("")
            lines.append("              X")
            lines.append("")
            # 1250 fiber/IXC uplink (NNI physical + optical health)
            if fiber_flags:
                for f in fiber_flags:
                    lines.append("  [ !! ] NNI {}".format(f))
            else:
                lines.append("  [ OK ] NNI PMs clean")
            for i in fiber_info:
                lines.append("         {}".format(i))
            # 1250 EVC (logical sub-interface) health
            if evc_flags:
                for f in evc_flags:
                    lines.append("  [ !! ] EVC {}".format(f))
            else:
                lines.append("  [ OK ] EVC PMs clean")
            # 1250 -- CES above the identifier line; only dirty TDM below
            if _CES_DISABLED_RE.search(pm):
                lines.append("  [ -- ] CES PMs disabled")
            elif ces_hits:
                for e in ces_hits:
                    lines.append("  [ !! ] CES {}".format(e))
            else:
                lines.append("  [ OK ] CES PMs clean")
            lines.append("         1250  --  {}".format(
                ds1_map.get(ds1, {}).get("loopback_ip", "?")))
            lines.append("         ds1-{}  {}".format(
                ds1, ds1_map.get(ds1, {}).get("muse_id", "?")))
            if phys_los or alarm_los:
                lines.append("  [ !! ] TDM  LOS -- loss of signal from LEC")
            elif tdm_hits:
                for e in tdm_hits:
                    lines.append("  [ !! ] TDM {}".format(e))
            else:
                lines.append("  [ OK ] TDM PMs clean")
            lines.append("")
            continue

        # ---- FULL ROUTE: GSX -> MUX -> 1800 -> 1250 (top-down) ----
        gsx_pm = gsx_pm_results.get(ds1, "")
        # Operational/alarm status = the GSX's "down" indicator (like TDM LOS)
        gsx_down = bool(re.search(r'Operational Status:\s*DOWN', gsx_pm, re.IGNORECASE))
        gsx_alarm_m = re.search(r'Alarm Status:\s*(\S+)', gsx_pm)
        gsx_alarm = gsx_alarm_m.group(1) if gsx_alarm_m else ""
        gsx_hits = _check_gsx_counters(gsx_pm)

        lines.append("         GSX  --  {}  (current 15 min / 24 hr)".format(gsx_node))
        if gsx_down:
            lines.append("  [ !! ] GSX DOWN-DS1ALARM{}".format(
                " ({})".format(gsx_alarm) if gsx_alarm and gsx_alarm.upper() != "NONE" else ""))
        if gsx_hits:
            for e in gsx_hits:
                lines.append("  [ !! ] GSX {}".format(e))
        if not gsx_down and not gsx_hits:
            lines.append("  [ OK ] GSX PMs clean")
        lines.append("         {}".format(gsx_assign))
        lines.append("")
        lines.append("              X")
        lines.append("")

        # MUX / T3
        t3_iface = mux.get("gsx_ce_iface", "")
        t3_stat  = all_t3_stats.get(t3_iface, "")
        t3_errs  = _check_counters(t3_stat, T3_COUNTERS)
        fa_alarm = ("LP_AIS" in fa) if fa else False

        if t3_errs:
            for e in t3_errs:
                lines.append("  [ !! ] T3 {}".format(e))
        else:
            lines.append("  [ OK ] T3 clean")
        lines.append("         CE{}:{}".format(
            t3_iface, mux.get("gsx_cem_id", "?")))
        lines.append("         MUX  --  {}".format(mux.get("mux_name", "?")))
        lines.append("         {} | SONET {}  ACR {}  CEM {}".format(
            oc12, mux.get("active_sonet", "?"), mux.get("acr_group", "?"),
            mux.get("cem_group", "?")))
        fa_list = mux.get("facility_alarms") or []
        if fa_list:
            for sev, syslog in fa_list:
                note = ("  (AIS from LEC/1250 direction -- signal loss at bottom of route)"
                        if "DS1_AIS" in syslog.upper() else "")
                lines.append("  [ !! ] {} {}{}".format(sev, syslog, note))
        else:
            lines.append("  [ OK ] No alarms")
        nb_conflict = mux.get("netbox_conflict")
        if nb_conflict:
            lines.append("  [ !! ] {}".format(nb_conflict))

        lines.append("")
        lines.append("              X")
        lines.append("")

        # 1800
        if oc12_errs:
            for e in oc12_errs:
                lines.append("  [ !! ] {} PM {}".format(oc_lbl, e))
        else:
            lines.append("  [ OK ] {} PMs clean".format(oc_lbl))
        if oc12_alarms:
            lines.append("  [ !! ] {} {} alarm(s) present".format(len(oc12_alarms), oc_lbl))
        else:
            lines.append("  [ OK ] {} alarms clean".format(oc_lbl))
        lines.append("         {}".format(oc12))
        lines.append("         1800  --  {}  ({})".format(
            hub.get("hub_name", "?"), hub.get("hub_ip", "?")))
        _emit_1800_nni(hub, lines)

        lines.append("")
        lines.append("              X")
        lines.append("")

        # 1250 fiber/IXC uplink (NNI physical + optical health, faces the core)
        if fiber_flags:
            for f in fiber_flags:
                lines.append("  [ !! ] NNI {}".format(f))
        else:
            lines.append("  [ OK ] NNI PMs clean")
        for i in fiber_info:
            lines.append("         {}".format(i))
        # 1250 EVC (logical sub-interface) health
        if evc_flags:
            for f in evc_flags:
                lines.append("  [ !! ] EVC {}".format(f))
        else:
            lines.append("  [ OK ] EVC PMs clean")

        # 1250 -- CES above the identifier line; only dirty TDM below
        if _CES_DISABLED_RE.search(pm):
            lines.append("  [ -- ] CES PMs disabled")
        elif ces_hits:
            for e in ces_hits:
                lines.append("  [ !! ] CES {}".format(e))
        else:
            lines.append("  [ OK ] CES PMs clean")
        lines.append("         1250  --  {}".format(
            ds1_map.get(ds1, {}).get("loopback_ip", "?")))
        lines.append("         ds1-{}  {}".format(
            ds1, ds1_map.get(ds1, {}).get("muse_id", "?")))
        if phys_los or alarm_los:
            lines.append("  [ !! ] TDM  LOS -- loss of signal from LEC")
        elif tdm_hits:
            for e in tdm_hits:
                lines.append("  [ !! ] TDM {}".format(e))
        else:
            lines.append("  [ OK ] TDM PMs clean")
        lines.append("")

    lines.append(SEP)
    return "\n".join(lines)


# ---- RUN SUMMARY ONE-LINER (fault direction) ----
def run_summary_line(ds1, ds1_map, pm_results, oc12_results,
                     hub_results, mux_results, all_oc12_stats, peerless):
    pm       = pm_results.get(ds1, "")
    oc12     = oc12_results.get(ds1, "")
    oc_lbl   = _oc_label(oc12)
    hub      = hub_results.get(ds1, {})
    mux      = mux_results.get(ds1, {})
    oc12_base = oc12.split(":")[0] if oc12 else ""
    oc12_key  = "{}|{}".format(hub.get("hub_ip", ""), oc12_base)
    oc12_stat = all_oc12_stats.get(oc12_key, "")
    fa        = mux.get("facility_alarm", "")

    phys_los  = bool(re.search(r'ds1/\d+\s+LOS', pm))
    alarm_los = bool(re.search(r'DS1LOS-L', pm) and
                     re.search(r'port-name=ds1-{}'.format(re.escape(ds1)), pm, re.IGNORECASE))
    uas_m     = re.search(r'DS1UAS-L\s*:\s*([1-9]\d*)', pm)
    loss_m    = re.search(r'DS1LOSS-L\s*:\s*([1-9]\d*)', pm)

    if ds1 in peerless:
        findings = []
        oc12_pm_errs = []
        for c in ["ES-S", "SES-S", "CV-S", "ES-L", "SES-L", "UAS-L"]:
            m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(c), oc12_stat)
            if m:
                oc12_pm_errs.append("{}={}".format(c, m.group(1)))
        if phys_los or alarm_los:
            findings.append("1250: DS1LOS")
        elif uas_m:
            findings.append("1250: DS1UAS-L={}".format(uas_m.group(1)))
        elif loss_m:
            findings.append("1250: DS1LOSS-L={}".format(loss_m.group(1)))
        if oc12_pm_errs:
            findings.append("1800 {}: {}".format(oc_lbl, ", ".join(oc12_pm_errs)))
        if not findings:
            return "  {}  --  PASS (Peerless -- ts{})  |  All clean".format(
                ds1.upper(), peerless[ds1])
        return "  {}  --  PASS (Peerless -- ts{})  |  {}".format(
            ds1.upper(), peerless[ds1], "  |  ".join(findings))

    # If key route data is missing (netbox not populated), we can't confirm the
    # circuit is healthy -- mark FAIL rather than silently passing.
    missing = []
    if not oc12:
        missing.append("1800/OC not resolved")
    if not hub.get("hub_ip"):
        missing.append("hub IP unknown")
    if not mux or not mux.get("mux_name") or mux.get("mux_name") == "?":
        missing.append("MUX not found")
    if missing:
        return "  {}  --  FAIL  |  Route incomplete: {}  |  Check Netbox".format(
            ds1.upper(), ", ".join(missing))

    findings = []
    suggest  = []

    if phys_los or alarm_los:
        findings.append("1250: DS1LOS")
        suggest.append("Trouble from TDM direction -- engage LEC")
    elif uas_m:
        findings.append("1250: DS1UAS-L={}".format(uas_m.group(1)))
        suggest.append("Trouble from TDM direction -- engage LEC")
    elif loss_m:
        findings.append("1250: DS1LOSS-L={}".format(loss_m.group(1)))
        suggest.append("Trouble from TDM direction -- engage LEC")

    # Scan all CES counters and report the one with the highest value.
    # (First-hit logic missed worse errors -- e.g. showing Overrun=8 when ES=1627.)
    _ces_max_c, _ces_max_v = None, 0
    for c in ["RxPsnLostPkts", "RxPsnOverrunEvents", "RxPsnUnderrunEvents",
              "RxPsnLopsEvents", "RxPsnES", "RxPsnSES", "RxPsnUAS", "TxPsnDiscardPkts"]:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(c), pm)
        if m:
            val = int(m.group(1))
            if val > _ces_max_v:
                _ces_max_v, _ces_max_c = val, c
    if _ces_max_c:
        findings.append("1250 CES: {}={}".format(_ces_max_c, _ces_max_v))
        suggest.append("Trouble from IXC direction")

    oc12_pm_errs = []
    for c in ["ES-S", "SES-S", "CV-S", "ES-L", "SES-L", "UAS-L"]:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(c), oc12_stat)
        if m:
            oc12_pm_errs.append("{}={}".format(c, m.group(1)))
    if oc12_pm_errs:
        findings.append("1800 {}: {}".format(oc_lbl, ", ".join(oc12_pm_errs)))
        suggest.append("Trouble from IXC direction -- {} errors on 1800".format(oc_lbl))

    oc12_alarm_count = sum(1 for line in oc12_stat.splitlines()
                           if "R-DS1AIS-P" in line or "AIS-V" in line)
    if oc12_alarm_count:
        findings.append("1800: {} {} alarm(s)".format(oc12_alarm_count, oc_lbl))
        suggest.append("Trouble from TDM direction -- remote AIS on {}".format(oc_lbl))

    if fa and "LP_AIS" in fa:
        if phys_los or alarm_los or uas_m:
            findings.append("MUX: LP_AIS (downstream of LEC issue)")
        else:
            findings.append("MUX: LP_AIS")
            suggest.append("Trouble from TDM direction -- signal loss upstream of 1800")

    nb_conflict = mux.get("netbox_conflict")
    if nb_conflict:
        findings.append(nb_conflict)

    if not findings:
        return "  {}  --  PASS  |  All clean".format(ds1.upper())
    finding_str = "  |  ".join(findings)
    suggest_str = " / ".join(sorted(set(suggest)))
    if suggest_str:
        return "  {}  --  PASS  |  {}  |  Suggest: {}".format(
            ds1.upper(), finding_str, suggest_str)
    return "  {}  --  PASS  |  {}".format(ds1.upper(), finding_str)
