#!/usr/bin/env python3
"""
output_builders.py -- Stage B polished output for the standalone Autotester.

Faithful port of the SecureCRT builders:
  - build_route_block        (FULL T1 ROUTE, HOP 1-4 + SUMMARY)
  - build_peerless_block     (PARTIAL T1 ROUTE, ends at 1800)
  - build_diagnostic_summary (per-DS1 vertical route w/ [ OK ]/[ !! ] + X connectors)
  - run_summary_line         (one-liner PASS + standardized Clean/Dirty per hop/side)

The 'X' between hops is intentional (NOT '|' -- a pipe breaks JIRA table rendering).

Built by P. Capps.
"""

import re
import textwrap

SEP  = "=" * 58
SEP2 = "-" * 58


def _wrap_note(text, indent="         "):
    """Wrap a verdict paragraph to report width with a uniform indent."""
    return textwrap.wrap(text, width=72, initial_indent=indent,
                         subsequent_indent=indent,
                         break_on_hyphens=False, break_long_words=False)


def _ais_verdict(tdm_los, tdm_ais_in, tdm_hits, mid_flags,
                 muse_id, oc12, acr, cem):
    """
    Cross-hop correlation for a DS1_AIS facility alarm on the MUX.

    AIS is generated AT the point of failure and travels downstream only --
    so where the AIS originated is determined by what the upstream hops
    (collected in this same run) look like. Finite symptom matrix, walked
    top-priority-first:

      1. 1250 TDM shows LOS/LOF        -> LEC handoff failure. The 1250
         lost its input and is itself inserting the AIS the MUX sees.
      2. 1250 TDM shows incoming AIS   -> failure deeper in the LEC network;
         the LEC's gear generated it, the 1250 is passing it through.
      3. 1250 TDM clean, middle dirty  -> transport fault between 1250 and
         MUX (CES/EVC/NNI/OC); AIS is a symptom of that segment.
      4. everything clean              -> the 1800 is inserting AIS into
         this VT: nothing stitched to the timeslot (or stitched to a
         different one). Provisioning/mapping gap, not a broken link --
         clean PMs everywhere are EXPECTED in this case, because AIS is a
         valid framed signal that transports without errors.
    """
    if tdm_los:
        return ("VERDICT: The 1250 has lost its incoming signal from the "
                "LEC (LOS) and is inserting AIS downstream -- the MUX alarm "
                "is the echo of that loss. Trouble is at the LEC handoff "
                "(cabling / smartjack / LEC last mile). Engage the LEC.")
    if tdm_ais_in:
        return ("VERDICT: The 1250 is RECEIVING AIS from the LEC -- the "
                "failure is upstream inside the LEC network, before our "
                "handoff. The 1250 is passing it through untouched. Engage "
                "the LEC and reference the incoming AIS at our demarc.")
    if mid_flags:
        return ("VERDICT: The 1250's TDM input is clean, but the transport "
                "path between the 1250 and MUX shows trouble ({}) -- the "
                "AIS is most likely a symptom of that segment. Work the "
                "dirty segment first; the AIS should clear with it."
                .format(", ".join(mid_flags[:4])))
    if tdm_hits:
        return ("VERDICT: The 1250's TDM input shows errors ({}) but no "
                "hard LOS/AIS, and the transport path is clean. Marginal "
                "signal from the LEC direction -- monitor, and engage the "
                "LEC if the counters keep climbing."
                .format(", ".join(h.split(":")[0].strip() for h in tdm_hits[:3])))
    return ("VERDICT: The MUX sees AIS but the 1250's TDM input AND the "
            "entire 1250<->1800 transport path are clean. A clean path "
            "carries AIS without logging a single error, so this pattern "
            "means the AIS is being inserted by the 1800 itself -- almost "
            "always because nothing is stitched into this VT timeslot "
            "(or the circuit is stitched to a different one). Check 1800 "
            "provisioning: verify {} is cross-connected to {} (expected "
            "CEM {} on ACR {}). Corroborate on the MUX with 'show cem "
            "circuit interface cem-acr {} {}' -- actively incrementing "
            "Lbits = far end reporting no attachment circuit."
            .format(muse_id or "the MUSE circuit", oc12 or "?",
                    cem or "?", acr or "?", acr or "?", cem or "?"))


# ---- helpers ----
def _ok_or(flagged, label):
    return "[ !! ] {}".format(label) if flagged else "[ OK ] {}".format(label)


def _check_counters(text, counters):
    """Return ['COUNTER: value', ...] for any non-zero counter found in text."""
    hits = []
    for c in counters:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(re.escape(c)), text)
        if m:
            hits.append("{}: {}".format(c, m.group(1)))
    return hits


def _cd(dirty, tag=None):
    """Clean/Dirty tag for the Run Summary, with an optional short hint of
    which counter/alarm tripped it -- name only, never the raw value.
    Several MUX/CEM counters are cumulative-since-last-"clear" and the exact
    figures aren't meaningful without a baseline (see run_summary_line)."""
    if not dirty:
        return "Clean"
    return "Dirty ({})".format(tag) if tag else "Dirty"


def _oc_label(oc_iface):
    """Derive the OC speed label from an interface identifier.
    'oc48-ts20/1:13:1' -> 'OC48', 'oc12-ts2/1:6:3' -> 'OC12',
    'oc-ts5/1:2:1' -> 'OC', '' or None -> 'OC'.
    """
    m = re.match(r'oc(\d+)-', (oc_iface or '').lower())
    return "OC{}".format(m.group(1)) if m else "OC"


def _parse_cd(val):
    """'Clean' / 'Dirty (TAG)' / 'Disabled' -> (dirty_bool, tag_or_state)."""
    val = (val or "").strip()
    if val.startswith("Dirty"):
        m = re.search(r'\(([^)]*)\)', val)
        return True, (m.group(1) if m else "")
    return False, val


def _cite_flagged_line(diag_text, keyword):
    """First '[ !! ]' line in this DS1's diagnostic text mentioning
    `keyword` (case-insensitive) -- best-effort citation of the actual
    flagged detail for a hop, instead of naming the hop with no value."""
    if not keyword:
        return None
    kw = keyword.lower()
    for ln in diag_text.splitlines():
        s = ln.strip()
        if s.startswith("[ !! ]") and kw in s.lower():
            return s
    return None


def _ds1_review(segs, diag_text):
    """
    One-liner review + suggested next step for a DS1, derived from the
    standardized per-hop Clean/Dirty verdicts. Finite symptom matrix,
    walked bottom-up: faults cascade DOWNSTREAM (away from the LEC,
    toward the GSX), so the lowest dirty hop is the root cause and
    anything dirty above it is usually a knock-on effect.

    Returns None when a DS1_AIS VERDICT already covers this DS1 (the
    caller skips the generic review in that case).

    Returns a tuple (review_text, secondary_text).  review_text is the
    main REVIEW: paragraph.  secondary_text is the "Other dirty
    segment(s)..." sentence when multiple hops are dirty, or "" when not.
    The caller renders them as separate paragraphs.
    """
    joined = "  |  ".join(segs)
    if "Route incomplete" in joined:
        reason = next((s for s in segs if "Route incomplete" in s), "Route incomplete")
        return ("REVIEW: {} -- hop health can't be verified end-to-end "
                "until the route resolves. Fix the circuit documentation "
                "(Netbox) and re-run before drawing conclusions.".format(reason), "")

    peerless = "network-side" in joined
    tdm = ces = s1250 = snet = smux = st3 = (False, "")
    for seg in segs[1:]:
        if seg.startswith("NOTE:"):
            continue
        m = re.match(r'1250: TDM (.+?) / CES (.+)$', seg)
        if m:
            tdm, ces = _parse_cd(m.group(1)), _parse_cd(m.group(2))
            continue
        m = re.match(r'1800: 1250-side (.+?) / (?:MUX|network)-side (.+)$', seg)
        if m:
            s1250, snet = _parse_cd(m.group(1)), _parse_cd(m.group(2))
            continue
        m = re.match(r'MUX: 1800-side (.+?) / GSX-side (.+)$', seg)
        if m:
            smux, st3 = _parse_cd(m.group(1)), _parse_cd(m.group(2))

    gsx_dirty = bool(re.search(r'\[ !! \] GSX', diag_text))

    # Route order, bottom (LEC) -> top (GSX). (order, name, dirty, tag)
    hops = [
        (0, "1250 TDM",       tdm[0],  tdm[1]),
        (1, "1250 CES",       ces[0],  ces[1]),
        (2, "1800 1250-side", s1250[0], s1250[1]),
        (3, "1800 {}".format("network-side" if peerless else "MUX-side"),
                              snet[0], snet[1]),
        (4, "MUX 1800-side",  smux[0], smux[1]),
        (5, "MUX GSX-side",   st3[0],  st3[1]),
        (6, "GSX",            gsx_dirty, ""),
    ]
    dirty = [h for h in hops if h[2]]

    if not dirty:
        note = (" (CES PMs are disabled, so the packet side couldn't be "
                "verified.)" if ces[1] == "Disabled" else "")
        return ("REVIEW: Every hop tested clean in both directions -- no "
                "active fault on this route at test time.{} If trouble is "
                "still being reported, suspect an intermittent issue or "
                "something outside the tested span (LEC last mile / "
                "customer equipment) and re-run during the trouble window."
                .format(note), "")

    order, name, _, tag = dirty[0]
    if order == 0:
        if "LOS" in (tag or "").upper():
            body = ("The 1250 has no incoming signal from the LEC ({}) -- "
                    "every hop above it is clean or just echoing that loss "
                    "downstream. The fault is at or beyond the LEC handoff; "
                    "engage the LEC.".format(tag))
        else:
            body = ("The 1250 is taking TDM errors ({}) from the LEC "
                    "direction while the path above it is clean -- marginal "
                    "signal at the handoff. Monitor, and engage the LEC if "
                    "the counters keep climbing.".format(tag))
    elif order == 1:
        body = ("The 1250's packet (CES) side shows {} while the T1 itself "
                "(TDM) and every hop above are clean -- this points at the "
                "packet transport between the 1250 and 1800 (timing/jitter/"
                "buffer), not the physical circuit. These PM counters "
                "accumulate, so re-run and compare before chasing it: "
                "static counts = historical event, climbing counts = "
                "active issue.".format(tag))
    elif order == 2:
        # BUG (found live 2026-08-06, NOE-4644): a DS1's diagnostic text can
        # carry TWO independent optical readings -- the 1800's own NNI/EVC
        # physical PM (check_nni_health, printed as "NNI optics  Rx x / Tx
        # y dBm") and the 1250's own GE fiber uplink laser (check_fiber_
        # health, printed as "[ !! ] NNI <port> Rx laser x dBm (< floor)").
        # side_1250_cd (the tag driving THIS hop) is actually set by the
        # fiber-uplink check, not the 1800's NNI check -- but the original
        # fix here always cited the 1800's "NNI optics" line regardless,
        # which is a genuinely different (and often still-clean) reading.
        # On NOE-4644 that meant citing a clean -3.2/-2.4 dBm reading while
        # the ACTUAL flagged one (ge-ts5/1, -34.0 dBm) sat unmentioned a
        # few lines below -- not a fabricated number, just the wrong one
        # for what tripped this specific flag. Fixed: cite whichever line
        # actually carries the "[ !! ]" dBm flag, whichever check produced
        # it, instead of assuming it's the 1800-side reading.
        flagged = [ln.strip() for ln in diag_text.splitlines()
                   if ln.strip().startswith("[ !! ]") and "dBm" in ln]
        reading = (" (already flagged above -- {})".format(flagged[0])) if flagged else ""
        body = ("The 1800's 1250-facing side is dirty ({}) while the 1250 "
                "below it and everything above are clean -- the trouble is "
                "on the NNI/EVC segment between the 1250 and 1800{}. This "
                "points at physical fiber degradation or a dirty connector "
                "on that span; if the 1250's own reading also comes back "
                "clean, it's possible the fault sits further out in the "
                "LEC's fiber path than this NNI check can see from our "
                "side -- worth engaging the LEC if nothing turns up "
                "locally.".format(tag, reading))
    elif order == 3:
        # tag here is often a generic label ("R-DS1AIS") rather than the
        # actual device alarm text -- cite the real "[ !! ] ... alarm(s):
        # ..." line (now showing the actual alarm names, 2026-08-07) when
        # one can be found, same pattern as the order-2 NNI fix.
        cited = _cite_flagged_line(diag_text, "alarm")
        detail = " ({})".format(cited) if cited else ""
        if peerless:
            body = ("The 1800's network-facing side shows {} while our side "
                    "of the route is clean{} -- the trouble is toward the "
                    "Peerless network handoff. Engage Peerless.".format(tag, detail))
        else:
            body = ("The OC path between the 1800 and MUX shows {} while "
                    "both ends are otherwise clean{} -- SONET transport "
                    "segment. Check the optics/path between the 1800 and "
                    "MUX.".format(tag, detail))
    elif order == 4:
        body = ("The MUX's 1800-facing facility shows {} with a clean path "
                "below it -- check the MUX SONET facility and CEM "
                "connection state on the MUX itself.".format(tag))
    elif order == 5:
        body = ("The T3 between the MUX and GSX shows {} while the entire "
                "route below the MUX is clean -- the fault is isolated to "
                "the MUX<->GSX span. Check the T3 port and cabling.".format(tag))
    else:
        body = ("The GSX side shows trouble while the entire route below "
                "it is clean -- the issue is at the GSX port itself, not "
                "the transport. Check the GSX T1/port state.")

    secondary = ""
    if len(dirty) > 1:
        # Generalizes the light-level fix (v1.70): a secondary/non-root
        # dirty hop used to be named only ("Other dirty segments (1800
        # 1250-side, GSX)...") with no actual value -- the same class of
        # "real fault, silently under-detailed" miss the light-level bug
        # was, just for every OTHER counter type too (T3, OC, GSX, etc.),
        # not only light levels. Now cites the actual flagged line when one
        # can be found for that hop, falling back to name+tag (old
        # behavior) only if no matching line turns up.
        # Returned separately (not appended to body) so the caller can
        # render it as its own paragraph with a blank line before it.
        other_bits = []
        for h in dirty[1:]:
            name, tag = h[1], h[3]
            search_terms = [tag] if tag else []
            if "GSX" in name:
                search_terms.append("GSX")
            cited = None
            for term in search_terms:
                cited = _cite_flagged_line(diag_text, term)
                if cited:
                    break
            other_bits.append(cited if cited else "{} ({})".format(name, tag or "flagged"))
        secondary = ("Other dirty segment(s) also flagged: {} -- likely "
                     "knock-on effects of the root cause above, but worth a "
                     "quick independent look -- clear the root first, then "
                     "re-run.".format("; ".join(other_bits)))
    return "REVIEW: " + body, secondary


def _light_level_blurb(diag_text):
    """
    Always states light-level status explicitly for this DS1 -- either
    flagged out-of-spec readings, or a clean confirmation -- regardless of
    which hop the REVIEW text picked as the PRIMARY root cause this run.
    Reuses FIBER_RX_DBM_FLOOR, the exact same threshold that trips the
    "[ !! ]" dBm flags, so this can never disagree with those flags.

    BUG #1 (found live 2026-08-06, NOE-4644, first occurrence): a DS1's
    diagnostic block can carry TWO independent optical readings -- the
    1800's own NNI/EVC physical PM ("NNI optics  Rx x / Tx y dBm") and the
    1250's own GE fiber uplink laser ("[ !! ] NNI <port> Rx laser x dBm
    (< floor)"). The original version only ever checked the FIRST ("NNI
    optics") reading and declared "Light levels look fine" off a genuinely
    clean -3.2/-2.4 dBm reading while a SEPARATE flagged -34.0 dBm reading
    (ge-ts5/1) sat elsewhere in the same block, unmentioned.

    BUG #2 (found live 2026-08-06, NOE-4644, SECOND occurrence -- the first
    fix over-corrected): made this go silent entirely whenever ANY "[ !! ]
    ... dBm" flag existed anywhere in the block, to avoid contradicting a
    flagged reading with a false "fine" claim. But that meant a genuinely
    out-of-spec light level got dropped from the paragraph ENTIRELY the
    moment a DIFFERENT hop (CES, in this case) became the primary root
    cause -- _ds1_review()'s citation only covers the hop it's actually
    talking about, not every other flagged item. Silence isn't a false
    claim, but it's still a miss: "light levels out of spec" needs to
    surface every run it's true, not only on runs where it happens to also
    be the root cause.

    Fixed: never go silent when something's actually flagged. If ANY
    "[ !! ] ... dBm" line exists, state it explicitly as OUT OF SPEC
    (redundant with the REVIEW text on runs where it's also the root
    cause -- that's fine, silence was the actual bug). Only when nothing
    at all is flagged does this confirm clean, citing every distinct
    reading found (both the 1800-side and 1250-side checks).
    """
    bad = [ln.strip() for ln in diag_text.splitlines()
           if ln.strip().startswith("[ !! ]") and "dBm" in ln]
    if bad:
        return "Light levels OUT OF SPEC: {}.".format("; ".join(bad))

    readings = []
    for m in re.finditer(r'NNI optics\s+Rx\s+(-?[\d.]+)\s*/\s*Tx\s+(-?[\d.]+)\s*dBm', diag_text):
        readings.append("1800 NNI/EVC Rx {} / Tx {} dBm".format(m.group(1), m.group(2)))
    for m in re.finditer(r'(\S+)\s+laser\s+Rx\s+(-?[\d.]+)\s*/\s*Tx\s+(-?[\d.]+)\s*dBm', diag_text):
        readings.append("1250 {} Rx {} / Tx {} dBm".format(m.group(1), m.group(2), m.group(3)))
    if not readings:
        return ""
    return ("Light levels look fine ({}, all at or better than the {:.1f} "
            "dBm floor).".format("; ".join(readings), FIBER_RX_DBM_FLOOR))


def build_jira_summary(ds1_map, run_summary_block, diag_text_parts):
    """
    Per-DS1 brief summary for the JIRA comment (visible without expanding
    anything): DS1 assignment as a header, that DS1's per-hop Clean/Dirty
    one-liner split onto readable lines beneath it, plus any DS1_AIS
    VERDICT paragraph lifted from that DS1's diagnostic summary. Rinse and
    repeat per DS1 -- each can have different symptoms.

    run_summary_block layout: [SEP, title, SEP, "", <one line per DS1>...],
    in ds1_map iteration order. diag_text_parts is parallel to ds1_map too.
    """
    per_ds1_lines = run_summary_block[4:4 + len(ds1_map)]
    out = []
    for idx, ds1 in enumerate(ds1_map):
        line = per_ds1_lines[idx] if idx < len(per_ds1_lines) else ""
        segs = [s.strip() for s in line.split("  |  ") if s.strip()]
        out.append(segs[0] if segs else ds1.upper())
        for seg in segs[1:]:
            out.append("  {}".format(seg))

        # Lift the wrapped VERDICT paragraph(s) out of this DS1's
        # diagnostic summary (9-space-indented block starting "VERDICT:").
        diag = diag_text_parts[idx] if idx < len(diag_text_parts) else ""
        verdicts, current = [], None
        for dl in diag.splitlines():
            if dl.strip().startswith("VERDICT:"):
                if current:
                    verdicts.append(" ".join(current))
                current = [dl.strip()]
            elif current is not None:
                if dl.startswith("         ") and dl.strip():
                    current.append(dl.strip())
                else:
                    verdicts.append(" ".join(current))
                    current = None
        if current:
            verdicts.append(" ".join(current))
        for v in verdicts:
            out.extend(textwrap.wrap(
                v, width=72, initial_indent="  ", subsequent_indent="  ",
                break_on_hyphens=False, break_long_words=False))

        # One-liner review + suggested next step (finite symptom matrix).
        # Skipped when a DS1_AIS VERDICT above already explains this DS1.
        # _ds1_review returns (review_text, secondary_text); secondary is
        # the "Other dirty segment(s)..." sentence when multiple hops are
        # dirty -- rendered as its own paragraph with a blank line before
        # it so it doesn't run on at the end of the REVIEW paragraph.
        if not verdicts:
            review, secondary = _ds1_review(segs, diag)
            if review:
                out.extend(textwrap.wrap(
                    review, width=72, initial_indent="  ",
                    subsequent_indent="  ", break_on_hyphens=False,
                    break_long_words=False))
            if secondary:
                out.append("")
                out.extend(textwrap.wrap(
                    secondary, width=72, initial_indent="",
                    subsequent_indent="  ", break_on_hyphens=False,
                    break_long_words=False))

        blurb = _light_level_blurb(diag)
        if blurb:
            out.append("")
            out.extend(textwrap.wrap(
                blurb, width=72, initial_indent="",
                subsequent_indent="  ", break_on_hyphens=False,
                break_long_words=False))
        out.append("")
    return "\n".join(out).rstrip()


# Marker written by npt1250_client.query_ds1_pms when the device returns
# "switch of this interface object is off" (pm-collection-enable not set).
_CES_DISABLED_RE = re.compile(r'CES PMs not enabled', re.IGNORECASE)

CEM_CIRCUIT_COUNTERS = [
    "Pkts Missing", "Failure Counts",
    "Generated Lbits", "Received Lbits",
    "Generated Rbits", "Received Rbits",
]

CES_COUNTERS = [
    "RxPsnLostPkts", "RxPsnOverrunEvents", "RxPsnUnderrunEvents",
    "RxPsnLopsEvents", "RxPsnES", "RxPsnSES", "RxPsnUAS",
    "TxPsnDiscardPkts", "RxPsnOowDiscardPkts",
]
TDM_COUNTERS = ["DS1ES-L", "DS1SES-L", "DS1CV-L", "DS1LOSS-L", "DS1UAS-L"]
OC12_COUNTERS = ["ES-S", "SES-S", "CV-S", "SEFS-S", "ES-L", "SES-L", "CV-L", "UAS-L"]
T3_COUNTERS = [
    "P-bit Coding Violation", "C-bit Coding Violation", "P-bit Err Secs",
    "Unavailable Secs", "Line Errored Secs", "AIS Defect Secs", "LOS Defect Secs",
]

# GSX PERFMON is columnar: "<Counter>:   <errors>   <Minor> <Major> <Critical>"
# e.g. "Unavailable Seconds:              772       TRUE    TRUE    TRUE"
# We check the leading Errors value (first number after the colon).
#
# IMPORTANT: only the "PERFMON CURRENT" sections hold actual error counts.
# The "PERFMON THRESHOLDS" section lists CONFIG LIMITS (e.g. "Line Errored
# Seconds: 518 648 778") using similar names -- those must NOT be read as
# errors, or a healthy circuit gets falsely flagged. We therefore scan only
# the current-performance region and stop at the THRESHOLDS section.
GSX_PM_COUNTERS = [
    "Code Violations", "Errored Seconds", "Severely Errored Seconds",
    "SEF/AIS Seconds", "Controlled Slip Seconds", "Unavailable Seconds",
]

# ---- Fiber (GE uplink) physical-layer health ----
# Physical PM error counters on the 1250 fiber ports (ge-ts2/1, ge-ts5/1).
# Flag any of these that read > 0. The last group (PCS/FEC) reads N/A on 1G
# optics; flag only when numeric and > 0.
FIBER_ERR_COUNTERS = [
    "Rx Error Pkts",
    "Rx CRC Align Error Pkts",
    "Collision Errors",
    "Rx Jabber Pkts",
    "Rx Fragments",
    "Rx Undersize Pkts",
    "Rx Oversize Pkts",
    "PCS-ES", "PCS-SES", "PCS-UAS", "FEC-UCE",
]
# Received optical power floor. Rx weaker (more negative) than this is flagged.
# (TX is shown but NOT flagged for now -- pending a per-transceiver threshold
#  command that will supply real per-optic limits; see TODO.)
FIBER_RX_DBM_FLOOR = -10.0

# ---- NNI resolution + physical-NNI (1800-side) health ----
def _optical_value(text, field):
    """Return float dBm for an optical field (MinRxPower/TxPower), else None."""
    m = re.search(r'^\s*' + re.escape(field) + r'\s*:\s*(-?\d+\.?\d*)',
                  text, re.MULTILINE)
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            return None
    return None


def resolve_nni_from_description(desc_output):
    """
    Parse 'show interfaces description | grep <prefix>' output from the 1800.
    Returns (logical_iface, physical_iface, status):
      status 'ok'        -> one NNI found; logical e.g. xe-ts13/3.570,
                            physical e.g. xe-ts13/3
      status 'none'      -> no interface line matched
      status 'ambiguous' -> matched >1 distinct physical interface (can't tell
                            which circuit -> caller flags + skips)
    """
    ifaces = []
    for line in (desc_output or "").splitlines():
        m = re.match(r'^\s*([a-z]+-ts\d+/\d+(?:\.\d+)?)\b', line)
        if m:
            ifaces.append(m.group(1))
    ifaces = sorted(set(ifaces))
    if not ifaces:
        return None, None, "none"
    # group by physical base (xe-ts13/3.570 -> xe-ts13/3); one base = one NNI
    bases = {}
    for name in ifaces:
        bases.setdefault(name.split(".")[0], []).append(name)
    if len(bases) > 1:
        return None, None, "ambiguous"
    base = list(bases)[0]
    subs = [n for n in bases[base] if "." in n]
    logical = subs[0] if subs else base
    return logical, base, "ok"


def check_nni_health(physical_pm):
    """
    Physical NNI health (1800 side) from 'show interfaces physical pm'.
    Flags FIBER_ERR_COUNTERS > 0 and MinRxPower < floor. Returns (flags, info).
    Optical fields here are MinRxPower/TxPower (not the transceiver 'laser'
    format used on the 1250). TX shown in info, not flagged.
    """
    flags, info = [], []
    for counter in FIBER_ERR_COUNTERS:
        val = _fiber_counter_value(physical_pm, counter)
        if val is not None and val > 0:
            flags.append("{}: {}".format(counter, val))
    rx = _optical_value(physical_pm, "MinRxPower")
    tx = _optical_value(physical_pm, "TxPower")
    if rx is not None and rx < FIBER_RX_DBM_FLOOR:
        flags.append("Rx power {} dBm (< {})".format(rx, FIBER_RX_DBM_FLOOR))
    if rx is not None or tx is not None:
        info.append("NNI optics  Rx {} / Tx {} dBm".format(
            rx if rx is not None else "?", tx if tx is not None else "?"))
    return flags, info


# ---- Logical EVC / sub-interface health ----
# Logical sub-interface PM (ge-tsX/1.0 on the 1250; xe-tsX/Y.VLAN on the 1800).
# Flag Rx packet discards (> 0), reported as the raw count plus the discard
# ratio: discards / (Rx Pass Pkts + Rx Discard Pkts), as a percent -- so a
# large-looking count can be judged in context (321765 is alarming alone, but
# ~0.1% of traffic is usually not). Packets only; octets are not flagged.
# Tx Discard reads "NA" on these platforms and is ignored.


def check_evc_health(evc_by_iface):
    """
    Shared logical-EVC health check for the DIAGNOSTIC SUMMARY.

    evc_by_iface: {iface_name: <logical pm text>}
    Returns list of "[ !! ]"-worthy flag strings (empty if no Rx discards).
    Each flag: "<iface> Rx Discard Pkts: <n> (<pct>)".
    """
    flags = []
    for iface in sorted(evc_by_iface):
        pm = evc_by_iface[iface] or ""
        discard = _fiber_counter_value(pm, "Rx Discard Pkts")
        if discard is None or discard <= 0:
            continue
        passed = _fiber_counter_value(pm, "Rx Pass Pkts")
        if passed is not None and (passed + discard) > 0:
            ratio = discard / float(passed + discard) * 100.0
            pct = "{:.2f}%".format(ratio) if ratio >= 0.01 else "<0.01%"
        else:
            pct = "ratio n/a"
        flags.append("{} Rx Discard Pkts: {} ({})".format(iface, discard, pct))
    return flags



def _fiber_counter_value(pm_text, counter):
    """Return int value of a fiber PM counter, or None if absent/N/A."""
    # lines look like:  "Rx CRC Align Error Pkts    :  0"
    m = re.search(r'^\s*' + re.escape(counter) + r'\s*:\s*(\S+)',
                  pm_text, re.MULTILINE)
    if not m:
        return None
    tok = m.group(1)
    if tok.upper() == "N/A":
        return None
    try:
        return int(tok)
    except ValueError:
        return None


def _fiber_laser_rx_tx(laser_text):
    """Return (rx_dbm, tx_dbm) floats from '| grep laser' output, None if absent."""
    rx = tx = None
    mrx = re.search(r'Rx-laser-power[^:]*:\s*(-?\d+\.?\d*)', laser_text)
    mtx = re.search(r'Tx-laser-power[^:]*:\s*(-?\d+\.?\d*)', laser_text)
    if mrx:
        try: rx = float(mrx.group(1))
        except ValueError: pass
    if mtx:
        try: tx = float(mtx.group(1))
        except ValueError: pass
    return rx, tx


def check_fiber_health(fiber_by_port):
    """
    Shared fiber/IXC uplink health check for the DIAGNOSTIC SUMMARY.

    fiber_by_port: {port_name: {"pm": <physical pm text>, "laser": <grep laser text>}}
       (pm may be the concatenation of the 24hour + 15min PM output)

    Returns (flags, info):
      flags -- list of "[ !! ]"-worthy strings (error counters >0, Rx laser < floor)
      info  -- list of informational strings (laser Rx/Tx levels per port)
    TX laser is reported in `info` only (not flagged) for now.
    """
    flags, info = [], []
    for port in sorted(fiber_by_port):
        data = fiber_by_port[port] or {}
        pm    = data.get("pm", "") or ""
        laser = data.get("laser", "") or ""

        for counter in FIBER_ERR_COUNTERS:
            val = _fiber_counter_value(pm, counter)
            if val is not None and val > 0:
                flags.append("{} {}: {}".format(port, counter, val))

        rx, tx = _fiber_laser_rx_tx(laser)
        if rx is not None and rx < FIBER_RX_DBM_FLOOR:
            flags.append("{} Rx laser {} dBm (< {})".format(port, rx, FIBER_RX_DBM_FLOOR))
        if rx is not None or tx is not None:
            info.append("{} laser  Rx {} / Tx {} dBm".format(
                port,
                "{}".format(rx) if rx is not None else "?",
                "{}".format(tx) if tx is not None else "?"))
    return flags, info



def _gsx_current_perf_region(text):
    """
    Return only the portion of GSX output that holds CURRENT performance data
    (PERFMON CURRENT FIFTEENMIN / DAY), excluding the THRESHOLDS config table
    and the STATISTICS block. Returns "" if no current-perf section is found.
    """
    region = []
    capture = False
    for line in text.splitlines():
        up = line.upper()
        if "PERFMON CURRENT" in up or "CURRENT PERFORMANCE" in up or "CURRENT DAY PERFORMANCE" in up:
            capture = True
        elif "THRESHOLD" in up:
            capture = False   # stop before the config-limits table
        elif up.strip().startswith("CMD:") and "PERFMON" not in up:
            capture = False
        if capture:
            region.append(line)
    return "\n".join(region)


def _check_gsx_counters(text):
    """
    Return ['Counter: value', ...] for any non-zero GSX PERFMON counter, read
    ONLY from the current-performance region (never the THRESHOLDS table).
    A counter can appear twice (Near End / Far End Path); report the max seen.
    The leading anchor (start-of-line) avoids matching 'Code Violations' inside
    'Line Code Violations' / 'Path Code Violations'.
    """
    region = _gsx_current_perf_region(text)
    if not region:
        return []
    hits = {}
    for c in GSX_PM_COUNTERS:
        # ^\s* anchors to the start of the line so "Code Violations:" does not
        # match "Line Code Violations:" or "Path Code Violations:".
        pat = re.compile(r'^\s*{}\s*:\s+([0-9]+)\b'.format(re.escape(c)), re.MULTILINE)
        for m in pat.finditer(region):
            val = int(m.group(1))
            if val > 0:
                hits[c] = max(hits.get(c, 0), val)
    return ["{}: {}".format(c, v) for c, v in hits.items()]


# ---- FULL ROUTE BLOCK ----
def build_route_block(ds1, host_1250, loopback_ip, muse_id,
                      hub_name, hub_ip, oc12, mux_data):
    gsx_assign = "{}-{}-{}".format(
        mux_data.get("gsx_slot") or "?",
        mux_data.get("gsx_port") or "?",
        mux_data.get("gsx_t1")   or "?")
    lines = [
        SEP,
        "  FULL T1 ROUTE  --  {}".format(ds1.upper()),
        SEP, "",
        "  HOP 1 -- NPT-1250",
        "    Host       : {}".format(host_1250),
        "    Loopback   : {}".format(loopback_ip),
        "    DS1        : {}".format(ds1),
        "    MUSE       : {}".format(muse_id),
        "", SEP2,
        "  HOP 2 -- NPT-1800 Hub",
        "    Hub        : {}".format(hub_name),
        "    IP         : {}".format(hub_ip),
        "    {:<10} : {}".format(_oc_label(oc12), oc12),
        "", SEP2,
        "  HOP 3 -- Cisco NCS 4216 MUX",
        "    MUX        : {}".format(mux_data.get("mux_name", "?")),
        "    IP         : {}".format(mux_data.get("mux_ip", "?")),
        "    Active Path: SONET {}".format(mux_data.get("active_sonet") or "?"),
        "    ACR Group  : {}".format(mux_data.get("acr_group", "?")),
        "    CEM Group  : {} (VTG {}, T1 {})".format(
            mux_data.get("cem_group", "?"),
            mux_data.get("vtg") or "?",
            mux_data.get("t1")  or "?"),
        "    GSX CE     : CE{}:{}".format(
            mux_data.get("gsx_ce_iface", "?"), mux_data.get("gsx_cem_id", "?")),
        "", SEP2,
        "  HOP 4 -- GSX",
        "    Node       : {}".format(mux_data.get("gsx_node") or "?"),
        "    IP         : {}".format(mux_data.get("gsx_ip") or "?"),
        "    Assignment : {}".format(gsx_assign),
        "    T1 Command : SHOW T1 T1-1-{}".format(gsx_assign),
        "", SEP,
        "  SUMMARY",
        "  1250 {}  |  {}  |  {}".format(ds1, muse_id, oc12),
        "  {} ACR {} CEM {}  |  CE{}:{}  |  {} {}".format(
            mux_data.get("mux_name", "?"), mux_data.get("acr_group", "?"),
            mux_data.get("cem_group", "?"),
            mux_data.get("gsx_ce_iface", "?"), mux_data.get("gsx_cem_id", "?"),
            mux_data.get("gsx_node") or "?", gsx_assign),
        SEP,
    ]
    return "\n".join(lines)


# ---- PEERLESS (PARTIAL) ROUTE BLOCK ----
def build_peerless_block(ds1, host_1250, loopback_ip, muse_id,
                         hub_name, hub_ip, oc12, slot_num):
    lines = [
        SEP,
        "  PARTIAL T1 ROUTE  --  {}".format(ds1.upper()),
        "  NOTE: ts{} detected. No Bandwidth MUX or GSX. Peerless circuit.".format(slot_num),
        SEP, "",
        "  HOP 1 -- NPT-1250",
        "    Host       : {}".format(host_1250),
        "    Loopback   : {}".format(loopback_ip),
        "    DS1        : {}".format(ds1),
        "    MUSE       : {}".format(muse_id),
        "", SEP2,
        "  HOP 2 -- NPT-1800 Hub",
        "    Hub        : {}".format(hub_name),
        "    IP         : {}".format(hub_ip),
        "    {:<10} : {}".format(_oc_label(oc12), oc12),
        "", SEP,
        "  Route ends at 1800 -- ts21/ts24 is customer-facing (Peerless).",
        SEP,
    ]
    return "\n".join(lines)


# ---- DIAGNOSTIC SUMMARY (vertical route, OK/!! indicators, X connectors) ----
def build_diagnostic_summary(ds1_list, ds1_map, pm_results, oc12_results,
                             hub_results, mux_results, all_oc12_stats,
                             all_t3_stats, peerless, errors, gsx_pm_results=None,
                             fiber_results=None, evc_results=None):
    gsx_pm_results = gsx_pm_results or {}
    fiber_results = fiber_results or {}
    evc_results = evc_results or {}
    # Fiber uplink (NNI physical) + EVC (logical) health are per-1250 (shared by
    # all DS1s in the run); compute once.
    fiber_flags, fiber_info = check_fiber_health(fiber_results) if fiber_results else ([], [])
    evc_flags = check_evc_health(evc_results) if evc_results else []

    def _emit_1800_nni(hub, out):
        """Render the 1800 NNI/EVC health lines (the 'bottom' of the 1800 block)."""
        nni = (hub or {}).get("nni") or {}
        status = nni.get("status")
        if not status:
            return  # no NNI data collected (older run / not available)
        if status == "ambiguous":
            out.append("  [ !! ] NNI ambiguous ({} matches) -- not checked".format(
                nni.get("prefix", "?")))
            return
        if status in ("none", "error"):
            out.append("  [ .. ] NNI not resolved ({})".format(status))
            return
        nflags, ninfo = check_nni_health(nni.get("phys_pm", ""))
        phys = nni.get("physical", "?")
        if nflags:
            for f in nflags:
                out.append("  [ !! ] NNI {} {}".format(phys, f))
        else:
            out.append("  [ OK ] NNI {} PMs clean".format(phys))
        for i in ninfo:
            out.append("         {}".format(i))
        eflags = check_evc_health({nni.get("logical", "evc"): nni.get("evc_pm", "")})
        if eflags:
            for f in eflags:
                out.append("  [ !! ] EVC {}".format(f))
        else:
            out.append("  [ OK ] EVC {} PMs clean".format(nni.get("logical", "?")))

    lines = []

    for ds1 in ds1_list:
        lines.append(SEP)
        lines.append("  DIAGNOSTIC SUMMARY  --  {}".format(ds1.upper()))
        lines.append(SEP)
        lines.append("")

        if ds1 in errors:
            lines.append("  COLLECTION FAILED: {}".format(errors[ds1]))
            lines.append("")
            continue

        pm   = pm_results.get(ds1, "")
        oc12 = oc12_results.get(ds1, "")
        oc_lbl = _oc_label(oc12)
        hub  = hub_results.get(ds1, {})
        mux  = mux_results.get(ds1, {})
        oc12_base = oc12.split(":")[0] if oc12 else ""
        oc12_key  = "{}|{}".format(hub.get("hub_ip", ""), oc12_base)
        oc12_stat = all_oc12_stats.get(oc12_key, "")
        fa        = mux.get("facility_alarm", "")
        gsx_node  = mux.get("gsx_node", "?")
        gsx_slot  = mux.get("gsx_slot", "?")
        gsx_port  = mux.get("gsx_port", "?")
        gsx_t1    = mux.get("gsx_t1", "?")
        gsx_assign = "{}-{}-{}".format(gsx_slot, gsx_port, gsx_t1)

        # common 1250 TDM/CES detection
        ces_hits = _check_counters(pm, CES_COUNTERS)
        tdm_hits = _check_counters(pm, TDM_COUNTERS)
        phys_los  = bool(re.search(r'ds1/\d+\s+LOS', pm))
        alarm_los = bool(re.search(r'DS1LOS-L', pm) and
                         re.search(r'port-name=ds1-{}'.format(re.escape(ds1)), pm, re.IGNORECASE))
        oc12_errs = _check_counters(oc12_stat, OC12_COUNTERS)
        oc12_alarms = [l.strip() for l in oc12_stat.splitlines()
                       if "R-DS1AIS-P" in l or "AIS-V" in l]

        if ds1 in peerless:
            lines.append("  Peerless circuit (ts{}).".format(peerless[ds1]))
            lines.append("")
            lines.append("         Peerless Network")
            lines.append("")
            lines.append("              X")
            lines.append("")
            # 1800 -- has TWO independent interfaces (MUX/network-facing OC,
            # and 1250-facing NNI/EVC) that can be dirty independently of
            # each other. Label both explicitly -- "OC clean" sitting right
            # above "NNI dirty" with no divider read as contradictory
            # information about "the 1800" (confirmed live 2026-08-06),
            # when really they're two different links off the same box.
            # The "1800 -- {name} ({ip})" identifier sits BETWEEN the two
            # sub-sections (not at the top) -- matches the existing
            # convention this function already uses elsewhere (e.g. the
            # 1250 section's own "1250 -- {ip}" line sits between its CES
            # and TDM readings, not above all of them). Reordered per
            # direction 2026-08-07 -- the original top-of-block placement
            # read awkwardly next to that established pattern.
            lines.append("         -- network-facing side ({}) --".format(oc12 or oc_lbl))
            for e in oc12_errs:
                lines.append("  [ !! ] {} PM {}".format(oc_lbl, e))
            if not oc12_errs:
                lines.append("  [ OK ] {} PMs clean".format(oc_lbl))
            # Show the actual matched alarm line(s), not just a count --
            # "(1 present)" told the reader nothing without logging into
            # the device to look it up, which defeats the point of this
            # report (2026-08-07 direction).
            if oc12_alarms:
                lines.append("  [ !! ] {} alarm(s): {}".format(
                    oc_lbl, "; ".join(oc12_alarms)))
            else:
                lines.append("  [ OK ] {} alarms clean".format(oc_lbl))
            lines.append("         {}".format(oc12))
            lines.append("         1800  --  {}  ({})".format(
                hub.get("hub_name", "?"), hub.get("hub_ip", "?")))
            lines.append("         -- 1250-facing side (NNI/EVC) --")
            _emit_1800_nni(hub, lines)
            lines.append("")
            lines.append("              X")
            lines.append("")
            # 1250 fiber/IXC uplink (NNI physical + optical health)
            if fiber_flags:
                for f in fiber_flags:
                    lines.append("  [ !! ] NNI {}".format(f))
            else:
                lines.append("  [ OK ] NNI PMs clean")
            for i in fiber_info:
                lines.append("         {}".format(i))
            # 1250 EVC (logical sub-interface) health
            if evc_flags:
                for f in evc_flags:
                    lines.append("  [ !! ] EVC {}".format(f))
            else:
                lines.append("  [ OK ] EVC PMs clean")
            # 1250 -- CES above the identifier line; only dirty TDM below
            if _CES_DISABLED_RE.search(pm):
                lines.append("  [ -- ] CES PMs disabled")
            elif ces_hits:
                for e in ces_hits:
                    lines.append("  [ !! ] CES {}".format(e))
            else:
                lines.append("  [ OK ] CES PMs clean")
            lines.append("         1250  --  {}".format(
                ds1_map.get(ds1, {}).get("loopback_ip", "?")))
            lines.append("         ds1-{}  {}".format(
                ds1, ds1_map.get(ds1, {}).get("muse_id", "?")))
            if phys_los or alarm_los:
                lines.append("  [ !! ] TDM  LOS -- loss of signal from LEC")
            elif tdm_hits:
                for e in tdm_hits:
                    lines.append("  [ !! ] TDM {}".format(e))
            else:
                lines.append("  [ OK ] TDM PMs clean")
            lines.append("")
            continue

        # ---- FULL ROUTE: GSX -> MUX -> 1800 -> 1250 (top-down) ----
        gsx_pm = gsx_pm_results.get(ds1, "")
        # Operational/alarm status = the GSX's "down" indicator (like TDM LOS)
        gsx_down = bool(re.search(r'Operational Status:\s*DOWN', gsx_pm, re.IGNORECASE))
        gsx_alarm_m = re.search(r'Alarm Status:\s*(\S+)', gsx_pm)
        gsx_alarm = gsx_alarm_m.group(1) if gsx_alarm_m else ""
        gsx_hits = _check_gsx_counters(gsx_pm)

        lines.append("         GSX  --  {}  (current 15 min / 24 hr)".format(gsx_node))
        if gsx_down:
            lines.append("  [ !! ] GSX DOWN-DS1ALARM{}".format(
                " ({})".format(gsx_alarm) if gsx_alarm and gsx_alarm.upper() != "NONE" else ""))
        if gsx_hits:
            for e in gsx_hits:
                lines.append("  [ !! ] GSX {}".format(e))
        if not gsx_down and not gsx_hits:
            lines.append("  [ OK ] GSX PMs clean")
        lines.append("         {}".format(gsx_assign))
        lines.append("")
        lines.append("              X")
        lines.append("")

        # MUX / T3
        t3_iface = mux.get("gsx_ce_iface", "")
        t3_stat  = all_t3_stats.get(t3_iface, "")
        t3_errs  = _check_counters(t3_stat, T3_COUNTERS)
        fa_alarm = ("LP_AIS" in fa) if fa else False

        if t3_errs:
            for e in t3_errs:
                lines.append("  [ !! ] T3 {}".format(e))
        else:
            lines.append("  [ OK ] T3 clean")
        lines.append("         CE{}:{}".format(
            t3_iface, mux.get("gsx_cem_id", "?")))
        lines.append("         MUX  --  {}".format(mux.get("mux_name", "?")))
        lines.append("         {} | SONET {}  ACR {}  CEM {}".format(
            oc12, mux.get("active_sonet", "?"), mux.get("acr_group", "?"),
            mux.get("cem_group", "?")))
        fa_list = mux.get("facility_alarms") or []
        if fa_list:
            # Cross-hop inputs for the DS1_AIS verdict -- all collected in
            # this same run, so the tool can walk the troubleshooting logic
            # itself instead of leaving a static direction hint.
            tdm_ais_in = bool(re.search(r'DS1AIS', pm) and
                              re.search(r'port-name=ds1-{}'.format(re.escape(ds1)),
                                        pm, re.IGNORECASE))
            mid_flags = []
            if ces_hits:
                mid_flags.append("CES {}".format(ces_hits[0].split(":")[0].strip()))
            if evc_flags:
                mid_flags.append("EVC")
            if fiber_flags:
                mid_flags.append("NNI")
            if oc12_errs:
                mid_flags.append("{} {}".format(
                    oc_lbl, oc12_errs[0].split(":")[0].strip()))
            if oc12_alarms:
                mid_flags.append("{} alarms".format(oc_lbl))

            for sev, syslog in fa_list:
                lines.append("  [ !! ] {} {}".format(sev, syslog))
                if "DS1_AIS" in syslog.upper():
                    verdict = _ais_verdict(
                        (phys_los or alarm_los), tdm_ais_in, tdm_hits,
                        mid_flags, ds1_map.get(ds1, {}).get("muse_id"),
                        oc12, mux.get("acr_group"), mux.get("cem_group"))
                    lines.extend(_wrap_note(verdict))
        else:
            lines.append("  [ OK ] No alarms")
        nb_conflict = mux.get("netbox_conflict")
        if nb_conflict:
            lines.append("  [ !! ] {}".format(nb_conflict))

        # CEM circuit health (item 14). Pkts Missing / Failure Counts / Lbits /
        # Rbits are cumulative-since-last-"clear cem circuit" (see the CEM
        # Hairpin Loop MOP), not a current-state reading -- a mature circuit
        # shows large non-zero values regardless of health. They no longer
        # drive an [ OK ]/[ !! ] verdict here; the raw counters are still in
        # the MUX Stats section (>> CEM Circuit Health) for reference.
        cem_h = mux.get("cem_health") or {}
        if cem_h:
            conn_state = cem_h.get("connection_state", "")
            xc_ok = cem_h.get("xconnect_ok", True)
            if conn_state and conn_state.upper() != "UP":
                lines.append("  [ !! ] Connection State: {}".format(conn_state))
            elif conn_state == "UP":
                lines.append("  [ OK ] Connection UP")
            if not xc_ok:
                lines.append("  [ !! ] Xconnect leg(s) DOWN")

        lines.append("")
        lines.append("              X")
        lines.append("")

        # 1800 -- has TWO independent interfaces (MUX-facing OC, and
        # 1250-facing NNI/EVC) that can be dirty independently of each
        # other. Label both explicitly -- see the matching comment in the
        # Peerless branch above for why (confirmed live 2026-08-06: read as
        # contradictory "1800 clean" vs "1800 dirty" without this). The
        # "1800 -- {name} ({ip})" identifier sits BETWEEN the two
        # sub-sections, matching this function's existing convention
        # elsewhere (reordered 2026-08-07, was at the top before).
        lines.append("         -- MUX-facing side ({}) --".format(oc12 or oc_lbl))
        if oc12_errs:
            for e in oc12_errs:
                lines.append("  [ !! ] {} PM {}".format(oc_lbl, e))
        else:
            lines.append("  [ OK ] {} PMs clean".format(oc_lbl))
        # Show the actual matched alarm line(s), not just a count (2026-08-07
        # direction -- same fix as the Peerless branch above).
        if oc12_alarms:
            lines.append("  [ !! ] {} alarm(s): {}".format(
                oc_lbl, "; ".join(oc12_alarms)))
        else:
            lines.append("  [ OK ] {} alarms clean".format(oc_lbl))
        lines.append("         {}".format(oc12))
        lines.append("         1800  --  {}  ({})".format(
            hub.get("hub_name", "?"), hub.get("hub_ip", "?")))
        lines.append("         -- 1250-facing side (NNI/EVC) --")
        _emit_1800_nni(hub, lines)

        lines.append("")
        lines.append("              X")
        lines.append("")

        # 1250 fiber/IXC uplink (NNI physical + optical health, faces the core)
        if fiber_flags:
            for f in fiber_flags:
                lines.append("  [ !! ] NNI {}".format(f))
        else:
            lines.append("  [ OK ] NNI PMs clean")
        for i in fiber_info:
            lines.append("         {}".format(i))
        # 1250 EVC (logical sub-interface) health
        if evc_flags:
            for f in evc_flags:
                lines.append("  [ !! ] EVC {}".format(f))
        else:
            lines.append("  [ OK ] EVC PMs clean")

        # 1250 -- CES above the identifier line; only dirty TDM below
        if _CES_DISABLED_RE.search(pm):
            lines.append("  [ -- ] CES PMs disabled")
        elif ces_hits:
            for e in ces_hits:
                lines.append("  [ !! ] CES {}".format(e))
        else:
            lines.append("  [ OK ] CES PMs clean")
        lines.append("         1250  --  {}".format(
            ds1_map.get(ds1, {}).get("loopback_ip", "?")))
        lines.append("         ds1-{}  {}".format(
            ds1, ds1_map.get(ds1, {}).get("muse_id", "?")))
        if phys_los or alarm_los:
            lines.append("  [ !! ] TDM  LOS -- loss of signal from LEC")
        elif tdm_hits:
            for e in tdm_hits:
                lines.append("  [ !! ] TDM {}".format(e))
        else:
            lines.append("  [ OK ] TDM PMs clean")
        lines.append("")

    lines.append(SEP)
    return "\n".join(lines)


# ---- RUN SUMMARY ONE-LINER (standardized Clean/Dirty per hop/side) ----
def run_summary_line(ds1, ds1_map, pm_results, oc12_results,
                     hub_results, mux_results, all_oc12_stats, all_t3_stats,
                     peerless, fiber_results=None, evc_results=None):
    """
    One-liner per DS1: Clean/Dirty per hop, split by direction where a hop
    has two distinct sides:
      1250: TDM / CES
      1800: 1250-side (NNI+EVC) / MUX-side (OC PM + alarms)
      MUX:  1800-side (facility alarms + connection state) / GSX-side (T3)

    Dirty tags name the counter/alarm that tripped it -- never the raw value.
    CEM Pkts Missing / Failure Counts / Lbits / Rbits are deliberately NOT
    part of this (see build_diagnostic_summary's CEM section for why): they
    are cumulative-since-last-"clear cem circuit" counters, not a current-
    state reading, so treating any non-zero value as "Dirty" would flag
    almost every mature circuit regardless of real health.
    """
    fiber_results = fiber_results or {}
    evc_results = evc_results or {}

    pm       = pm_results.get(ds1, "")
    oc12     = oc12_results.get(ds1, "")
    hub      = hub_results.get(ds1, {})
    mux      = mux_results.get(ds1, {})
    oc12_base = oc12.split(":")[0] if oc12 else ""
    oc12_key  = "{}|{}".format(hub.get("hub_ip", ""), oc12_base)
    oc12_stat = all_oc12_stats.get(oc12_key, "")

    # ---- 1250: TDM / CES ----
    phys_los  = bool(re.search(r'ds1/\d+\s+LOS', pm))
    alarm_los = bool(re.search(r'DS1LOS-L', pm) and
                     re.search(r'port-name=ds1-{}'.format(re.escape(ds1)), pm, re.IGNORECASE))
    tdm_hits = _check_counters(pm, TDM_COUNTERS)
    if phys_los or alarm_los:
        tdm_cd = _cd(True, "DS1LOS")
    elif tdm_hits:
        tdm_cd = _cd(True, tdm_hits[0].split(":")[0].strip())
    else:
        tdm_cd = _cd(False)

    if _CES_DISABLED_RE.search(pm):
        ces_cd = "Disabled"
    else:
        # Worst (highest-value) CES counter drives the tag -- value not shown.
        _ces_max_c, _ces_max_v = None, 0
        for c in CES_COUNTERS:
            m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(re.escape(c)), pm)
            if m:
                val = int(m.group(1))
                if val > _ces_max_v:
                    _ces_max_v, _ces_max_c = val, c
        ces_cd = _cd(bool(_ces_max_c), _ces_max_c)

    line_1250 = "1250: TDM {} / CES {}".format(tdm_cd, ces_cd)

    # ---- 1800: 1250-side (NNI+EVC) / MUX-side (OC PM + alarms) ----
    fiber_flags, _ = check_fiber_health(fiber_results) if fiber_results else ([], [])
    evc_flags = check_evc_health(evc_results) if evc_results else []
    if fiber_flags:
        side_1250_cd = _cd(True, "NNI")
    elif evc_flags:
        side_1250_cd = _cd(True, "EVC")
    else:
        side_1250_cd = _cd(False)

    oc12_pm_errs = _check_counters(
        oc12_stat, ["ES-S", "SES-S", "CV-S", "ES-L", "SES-L", "UAS-L"])
    oc12_alarm_count = sum(1 for line in oc12_stat.splitlines()
                           if "R-DS1AIS-P" in line or "AIS-V" in line)
    if oc12_pm_errs:
        side_net_cd = _cd(True, oc12_pm_errs[0].split(":")[0].strip())
    elif oc12_alarm_count:
        side_net_cd = _cd(True, "R-DS1AIS")
    else:
        side_net_cd = _cd(False)

    if ds1 in peerless:
        # Peerless ends at the 1800 -- the "other side" is the Peerless
        # customer network, not a Bandwidth MUX, so label it accordingly.
        line_1800 = "1800: 1250-side {} / network-side {}".format(
            side_1250_cd, side_net_cd)
        return "  {}  --  PASS (Peerless -- ts{})  |  {}  |  {}".format(
            ds1.upper(), peerless[ds1], line_1250, line_1800)

    line_1800 = "1800: 1250-side {} / MUX-side {}".format(side_1250_cd, side_net_cd)

    # If key route data is missing (netbox not populated), we can't confirm the
    # circuit is healthy -- mark FAIL rather than silently passing.
    missing = []
    if not oc12:
        missing.append("1800/OC not resolved")
    if not hub.get("hub_ip"):
        missing.append("hub IP unknown")
    if not mux or not mux.get("mux_name") or mux.get("mux_name") == "?":
        missing.append("MUX not found")
    if missing:
        return "  {}  --  FAIL  |  Route incomplete: {}  |  Check Netbox".format(
            ds1.upper(), ", ".join(missing))

    # ---- MUX: 1800-side (facility alarms + connection state) / GSX-side (T3) ----
    t3_iface = mux.get("gsx_ce_iface", "")
    t3_stat  = all_t3_stats.get(t3_iface, "")
    t3_errs  = _check_counters(t3_stat, T3_COUNTERS)
    side_gsx_cd = _cd(bool(t3_errs), t3_errs[0].split(":")[0].strip() if t3_errs else None)

    fa_alarms = mux.get("facility_alarms") or []
    cem_h = mux.get("cem_health") or {}
    conn_state = (cem_h.get("connection_state") or "")
    conn_bad = bool(conn_state) and conn_state.upper() not in ("UP", "?")
    xc_bad = cem_h.get("xconnect_ok") is False
    if fa_alarms:
        side_1800m_cd = _cd(True, fa_alarms[0][1])
    elif conn_bad:
        side_1800m_cd = _cd(True, "Connection")
    elif xc_bad:
        side_1800m_cd = _cd(True, "Xconnect")
    else:
        side_1800m_cd = _cd(False)

    line_mux = "MUX: 1800-side {} / GSX-side {}".format(side_1800m_cd, side_gsx_cd)

    parts = [line_1250, line_1800, line_mux]

    nb_conflict = mux.get("netbox_conflict")
    if nb_conflict:
        parts.append("NOTE: {}".format(nb_conflict))

    return "  {}  --  PASS  |  {}".format(ds1.upper(), "  |  ".join(parts))
