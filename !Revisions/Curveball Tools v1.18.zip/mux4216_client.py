#!/usr/bin/env python3
"""
mux4216_client.py -- Cisco NCS 4216 MUX client (paramiko), subclass of
BaseDeviceClient.

The MUX needs LEGACY algorithms re-enabled (confirmed via ssh -vv):
    kex     diffie-hellman-group14-sha1   (still in paramiko)
    hostkey ssh-rsa                        (still in paramiko -- NOT the removed DSA)
    cipher  aes###-ctr / mac hmac-sha2/sha1 (modern enough, default-compatible)
So unlike the GSX, the MUX works with paramiko -- we just pin the two legacy algos.

Prompt ends "#". Paging disabled with "terminal length 0" (sent post-login).
Has an authorization banner before the prompt (base reader handles it).

This file currently provides the CLIENT + a connection test. The full
query_4216_batch port (ACR/Netbox reconciliation) is the next step once the
transport is validated.

Built by P. Capps.
"""

import re
import sys

try:
    import paramiko
except ImportError:
    print("ERROR: paramiko not installed. Run:  pip install paramiko")
    sys.exit(1)

from device_base import BaseDeviceClient


class MUX4216Client(BaseDeviceClient):
    PROMPT_RE = re.compile(r'[\w.\-]+#\s*$')   # MUX prompt ends with "#"
    CONN_TIMEOUT = 30

    def _connect_transport(self, conn_timeout):
        """
        Cisco NCS 4216 offers only legacy kex (dh-group14-sha1) and ssh-rsa
        hostkey. Build a Transport with disabled_algorithms={} so nothing is
        pre-disabled, then pin the legacy set paramiko still supports.
        """
        import socket
        sock = socket.create_connection((self.ip, 22), timeout=min(conn_timeout, 30))
        transport = paramiko.Transport(sock, disabled_algorithms={})
        try:
            so = transport.get_security_options()
            so.kex = ("diffie-hellman-group14-sha1",)
            so.key_types = ("ssh-rsa",)
            # ciphers/macs left at paramiko defaults (MUX offers aes-ctr +
            # hmac-sha2/sha1, all of which paramiko supports by default).
        except Exception as e:
            transport.close()
            raise RuntimeError(
                "MUX legacy-algo setup failed: {} (paramiko {})".format(
                    e, getattr(paramiko, "__version__", "?")))

        transport.start_client(timeout=min(conn_timeout, 30))
        transport.auth_password(self.username, self.password)

        self._transport = transport
        self.client = paramiko.SSHClient()
        # keep a handle so close() works; attach the live transport
        self.client._transport = transport

    def _open_shell(self):
        # Open the channel directly from the manually-built transport.
        chan = self._transport.open_session(timeout=self.CONN_TIMEOUT)
        chan.get_pty()
        chan.invoke_shell()
        return chan

    def _post_login(self):
        # Disable paging for the session (session-only, non-persistent).
        self.run("terminal length 0")

    # ---- query_4216_batch port (ACR + Netbox reconciliation) ----
    @staticmethod
    def _parse_oc12(oc12):
        m = re.match(r'oc\d*-(ts\d+)/(\d+):(\d+):(\d+)', oc12)
        if not m:
            raise RuntimeError("Cannot parse OC interface: {}".format(oc12))
        return {"ts_slot": m.group(1), "port": m.group(2),
                "sts": m.group(3), "ds1": m.group(4)}

    def query_batch(self, mux_name, mux_ip, ds1_oc12_map, ds1_hostname_map, netbox):
        """
        Port of query_4216_batch. Netbox-first SONET resolution (ts3-bug fix).
        Returns (mux_results, t3_stats, mux_name, mux_ip, errors).
        `netbox` is a NetboxClient (or None -> legacy ACR-guess w/ UNVERIFIED flag).
        """
        mux_results = {}
        t3_stats    = {}
        errors      = {}

        # Pull ACR groups once
        raw_acr = self.run("show acr group")
        acr_groups = []
        for line in raw_acr.splitlines():
            m = re.match(r'\s*(\d+)\s+SONET\s+([\d/]+)\s+SONET\s+([\d/]+)\s+SONET\s+([\d/]+)', line)
            if m:
                acr_groups.append({
                    "acr": m.group(1), "working": m.group(2),
                    "protect": m.group(3), "active": m.group(4),
                })
        if not acr_groups:
            raise RuntimeError("Could not parse ACR groups from {}".format(mux_name))

        for ds1, oc12 in ds1_oc12_map.items():
            try:
                parts = self._parse_oc12(oc12)
                sts   = parts["sts"]
                ds1_n = parts["ds1"]
                expected_cem = "{}{}".format(int(sts), str(int(ds1_n)).zfill(2))

                # ---- NETBOX-FIRST SONET RESOLUTION (ts3-bug fix) ----
                hostname_1800 = ds1_hostname_map.get(ds1, "")
                oc_base = oc12.split(":")[0]
                netbox_sonet = netbox_mux = None
                if netbox is not None:
                    netbox_sonet, netbox_mux = netbox.oc_to_sonet(hostname_1800, oc_base)

                netbox_conflict = None
                acr_num = cem_group = vtg_num = t1_num = active_sonet = None

                # Ambiguous Netbox match -> treat like a failed lookup (legacy
                # guess) but say WHY, so it's distinguishable from "not found".
                nb_ambiguous = (netbox_sonet == "__AMBIGUOUS__")
                if nb_ambiguous:
                    netbox_sonet = None

                if netbox_sonet:
                    matched_acr = None
                    for acr in acr_groups:
                        if acr["working"] == netbox_sonet:
                            matched_acr = acr
                            break
                    if not matched_acr:
                        raise RuntimeError(
                            "NETBOX/MUX MISMATCH: Netbox SONET {} not found in any "
                            "ACR working column on {}. Cannot verify path -- "
                            "marking FAIL (not guessing).".format(netbox_sonet, mux_name))

                    acr_num      = matched_acr["acr"]
                    active_sonet = matched_acr["active"]
                    if matched_acr["active"] != netbox_sonet:
                        netbox_conflict = (
                            "CONFLICT: circuit on PROTECT -- Netbox working {}, "
                            "MUX active {}".format(netbox_sonet, matched_acr["active"]))

                    raw_sts = self.run(
                        "show run controller SONET-ACR {} | section sts-1 {}".format(acr_num, sts))
                    for line in raw_sts.splitlines():
                        if "cem-group" in line:
                            mc = re.search(r'vtg\s+(\d+)\s+t1\s+(\d+)\s+cem-group\s+(\d+)', line)
                            if mc:
                                cg = mc.group(3)
                                if cg == expected_cem or cg == str(int(sts) * 100 + int(ds1_n)):
                                    cem_group = cg
                                    vtg_num   = mc.group(1)
                                    t1_num    = mc.group(2)
                                    break
                    if not cem_group:
                        cem_group = expected_cem
                else:
                    if nb_ambiguous:
                        netbox_conflict = ("WARNING: Netbox has multiple interfaces "
                                           "matching {} -- path UNVERIFIED (legacy ACR-guess "
                                           "used)".format(oc_base))
                    else:
                        netbox_conflict = ("WARNING: Netbox lookup failed for {} -- "
                                           "path is UNVERIFIED (legacy ACR-guess used)".format(oc_base))
                    for acr in acr_groups:
                        raw_sts = self.run(
                            "show run controller SONET-ACR {} | section sts-1 {}".format(acr["acr"], sts))
                        for line in raw_sts.splitlines():
                            if "cem-group" in line:
                                mc = re.search(r'vtg\s+(\d+)\s+t1\s+(\d+)\s+cem-group\s+(\d+)', line)
                                if mc:
                                    cg = mc.group(3)
                                    if cg == expected_cem or cg == str(int(sts) * 100 + int(ds1_n)):
                                        acr_num      = acr["acr"]
                                        cem_group    = cg
                                        vtg_num      = mc.group(1)
                                        t1_num       = mc.group(2)
                                        active_sonet = acr["active"]
                                        break
                        if cem_group:
                            break
                    if not cem_group:
                        cem_group    = expected_cem
                        acr_num      = acr_groups[0]["acr"]
                        active_sonet = acr_groups[0]["active"]

                # xconnect -> GSX CE interface + CEM id
                raw_xc = self.run("show xconnect all | i {}:{}".format(acr_num, cem_group))
                gsx_ce_iface = gsx_cem_id = None
                for line in raw_xc.splitlines():
                    if "CE{}:{}".format(acr_num, cem_group) in line:
                        ces = re.findall(r'CE([\d/]+):(\d+)', line)
                        for ce_iface, ce_id in ces:
                            if "/" in ce_iface:
                                gsx_ce_iface = ce_iface
                                gsx_cem_id   = ce_id
                                break
                if not gsx_ce_iface:
                    raise RuntimeError("No GSX xconnect for ACR {}:{}".format(acr_num, cem_group))

                # T3 description -> GSX node/slot/port
                raw_t3 = self.run("show controllers t3 {} | inc [Dd]escription".format(gsx_ce_iface))
                gsx_desc = gsx_node = gsx_slot = gsx_port = None
                for line in raw_t3.splitlines():
                    if "escription" in line:
                        md = re.search(r'[Dd]escription[:\s]+(\S+)', line)
                        if md:
                            gsx_desc = md.group(1)
                            p = gsx_desc.split("-")
                            if len(p) >= 3:
                                gsx_node = p[0]
                                gsx_slot = p[1]
                                gsx_port = p[2]
                            break

                gsx_t1 = str(int(gsx_cem_id) % 100) if gsx_cem_id else "?"

                mux_results[ds1] = {
                    "mux_name":        mux_name,
                    "mux_ip":          mux_ip,
                    "active_sonet":    active_sonet,
                    "netbox_conflict": netbox_conflict,
                    "acr_group":       acr_num,
                    "cem_group":       cem_group,
                    "vtg":             vtg_num,
                    "t1":              t1_num,
                    "gsx_ce_iface":    gsx_ce_iface,
                    "gsx_cem_id":      gsx_cem_id,
                    "gsx_desc":        gsx_desc,
                    "gsx_node":        gsx_node,
                    "gsx_slot":        gsx_slot,
                    "gsx_port":        gsx_port,
                    "gsx_t1":          gsx_t1,
                }

                # Per-DS1 facility alarm -- full path match.
                # The command lists a row ONLY when a facility is in alarm; no
                # match => not in alarm (healthy). Row columns:
                #   Source | Time | Severity | Syslog String | Description [Index]
                fa_path = "{}.{}/{}/{}".format(
                    active_sonet or "?", sts, vtg_num or "?", t1_num or "?")
                cmd_fa = "show facility-alarm status | inc {}".format(fa_path)
                raw_fa = self.run(cmd_fa)
                fa_lines = ["  >> Facility Alarm Status", "  CMD: {}".format(cmd_fa)]
                fa_alarms = []   # parsed (severity, syslog) for the diagnostic summary
                for line in raw_fa.splitlines():
                    clean = line.rstrip()
                    if clean:
                        fa_lines.append("    {}".format(clean))
                    # Parse only real alarm rows: must start with a facility
                    # Source (e.g. "SONET 0/3/0.2 PATH") and contain a severity.
                    m = re.search(
                        r'\b(CRITICAL|MAJOR|MINOR|WARNING)\b\s+(\S+)', clean)
                    if m and clean and clean[0] not in (" ", "-") \
                            and not clean.lower().startswith(("source", "system")):
                        fa_alarms.append((m.group(1), m.group(2)))
                fa_lines.append("")
                mux_results[ds1]["facility_alarm"] = "\n".join(fa_lines)
                mux_results[ds1]["facility_alarms"] = fa_alarms

                # T3 stats once per unique T3 interface (DS3 level only)
                if gsx_ce_iface and gsx_ce_iface not in t3_stats:
                    stat_lines = []
                    stat_lines.append("  T3: {}  ({})".format(gsx_ce_iface, mux_name))
                    stat_lines.append("  MUX IP: {}".format(mux_ip))
                    stat_lines.append("")
                    cmd = "show controllers t3 {}".format(gsx_ce_iface)
                    raw_ctrl = self.run(cmd)
                    stat_lines.append("  >> T3 Controller Errors (DS3 level)")
                    stat_lines.append("  CMD: {}".format(cmd))
                    for line in raw_ctrl.splitlines():
                        clean = line.rstrip()
                        if not clean:
                            continue
                        if re.match(r'\s*T3\s+[\d/]+\.\d+\s+T1', clean):
                            break
                        stat_lines.append("    {}".format(clean))
                    stat_lines.append("")
                    t3_stats[gsx_ce_iface] = "\n".join(stat_lines)

            except Exception as e:
                errors[ds1] = str(e)

        return mux_results, t3_stats, mux_name, mux_ip, errors


# ============================================================
# STANDALONE TEST -- exercise query_batch (ACR + Netbox reconciliation)
# Feeds the Maryville values the pipeline would produce:
#   ds1 ts3/8 -> oc12-ts1/1:11:14, 1800 host ces01.lax1
# ============================================================
def main():
    import getpass
    from netbox_client import NetboxClient, load_netbox_config

    print("=" * 60)
    print("  MUX (NCS 4216) CLIENT -- query_batch test")
    print("=" * 60)

    ip       = input("MUX IP [10.243.65.4]: ").strip() or "10.243.65.4"
    mux_name = input("MUX name [LAX1-MUX-02]: ").strip() or "LAX1-MUX-02"
    ds1      = input("DS1 [ts3/8]: ").strip() or "ts3/8"
    oc12     = input("OC12 [oc12-ts1/1:11:14]: ").strip() or "oc12-ts1/1:11:14"
    host1800 = input("1800 host [ces01.lax1]: ").strip() or "ces01.lax1"

    user = input("MUX username: ").strip()
    pw   = getpass.getpass("MUX password: ")
    if not user or not pw:
        print("No credentials. Exiting.")
        return

    url, token = load_netbox_config()
    netbox = NetboxClient(url, token)
    print("\nNetbox config loaded: {}".format(netbox.ok()))

    c = MUX4216Client(ip, user, pw)
    print("[connecting -- legacy algos enabled]")
    try:
        c.connect()
    except Exception as e:
        print("[!] connect failed: {}: {}".format(type(e).__name__, e))
        return
    print("  host: {}".format(c.hostname))

    ds1_oc12_map     = {ds1: oc12}
    ds1_hostname_map = {ds1: host1800}

    print("\n[query_batch -- ACR/Netbox reconciliation]")
    mux_results, t3_stats, mn, mip, errors = c.query_batch(
        mux_name, ip, ds1_oc12_map, ds1_hostname_map, netbox)

    for d, r in mux_results.items():
        print("-" * 50)
        print("  DS1: {}".format(d))
        print("  Active SONET: {}  ACR {}  CEM {} (VTG {}, T1 {})".format(
            r["active_sonet"], r["acr_group"], r["cem_group"], r["vtg"], r["t1"]))
        print("  GSX CE: {}  ->  node {} slot {} port {} t1 {}".format(
            r["gsx_ce_iface"], r["gsx_node"], r["gsx_slot"], r["gsx_port"], r["gsx_t1"]))
        if r["netbox_conflict"]:
            print("  FLAG: {}".format(r["netbox_conflict"]))
        print()
        print(r.get("facility_alarm", ""))
    for d, err in errors.items():
        print("  {} -> ERROR: {}".format(d, err))

    print("\n[T3 stats]")
    for iface, text in t3_stats.items():
        print(text)

    c.close()
    print("\n[done] query_batch reconciliation tested.")


if __name__ == "__main__":
    main()
