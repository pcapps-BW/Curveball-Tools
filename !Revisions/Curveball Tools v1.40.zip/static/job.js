/**
 * job.js -- shared submit/poll/render logic for every Curveball Tools web
 * form. Each tool page has identical structure:
 *   <form id="runForm" data-run-url="/api/<slug>/run"> ... </form>
 *   #statusPanel (.msg, .warning)  -- shown while running
 *   #reportPanel (a.download, pre) -- shown when done
 *   #formError                     -- shown on validation/submit errors
 *
 * initJobForm() wires the form up. One tool = one call, at the bottom of
 * that tool's template.
 */
function initJobForm(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  const runUrl = form.dataset.runUrl;

  // Error div lives inside the form when present (supports multiple forms
  // per page, e.g. the DS1 Test Builder's run + monitor forms).
  const formError = form.querySelector('.field-error') || document.getElementById('formError');
  const statusPanel = document.getElementById('statusPanel');
  const statusMsg = statusPanel.querySelector('.msg');
  const statusWarning = statusPanel.querySelector('.warning');
  const statusLog = statusPanel.querySelector('.log');
  const reportPanel = document.getElementById('reportPanel');
  const reportPre = reportPanel.querySelector('pre');
  const downloadLink = reportPanel.querySelector('a.download');
  const verdictBadge = reportPanel.querySelector('.verdict-badge');
  let pollTimer = null;
  let loggedLines = 0;

  function formatElapsed(sec) {
    const m = Math.floor(sec / 60), s = sec % 60;
    return m > 0 ? (m + 'm ' + s + 's') : (s + 's');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    formError.textContent = '';
    if (pollTimer) clearInterval(pollTimer);
    reportPanel.style.display = 'none';
    verdictBadge.style.display = 'none';
    statusPanel.style.display = 'block';
    statusWarning.style.display = 'none';
    statusLog.style.display = 'none';
    statusLog.textContent = '';
    loggedLines = 0;
    statusMsg.textContent = 'Submitting...';

    const fd = new FormData(form);
    let res, data;
    try {
      res = await fetch(runUrl, { method: 'POST', body: fd });
      data = await res.json();
    } catch (err) {
      statusPanel.style.display = 'none';
      formError.textContent = 'Could not reach the server: ' + err;
      return;
    }
    if (!res.ok) {
      statusPanel.style.display = 'none';
      formError.textContent = data.error || 'Unknown error.';
      return;
    }

    const jobId = data.job_id;
    pollTimer = setInterval(() => pollStatus(jobId), 2000);
    pollStatus(jobId);
  });

  function appendLog(lines) {
    if (!lines || lines.length <= loggedLines) return;
    const newLines = lines.slice(loggedLines);
    loggedLines = lines.length;
    if (newLines.length) {
      statusLog.style.display = 'block';
      statusLog.textContent += (statusLog.textContent ? '\n' : '') + newLines.join('\n');
      statusLog.scrollTop = statusLog.scrollHeight;
    }
  }

  async function pollStatus(jobId) {
    let res, data;
    try {
      res = await fetch('/api/job/' + jobId);
      data = await res.json();
    } catch (err) {
      statusMsg.textContent = 'Lost contact with the server -- it may still be running. Retrying...';
      return;
    }

    appendLog(data.log);

    if (data.status === 'running') {
      statusMsg.textContent = 'Running' + (data.label ? (' -- ' + data.label) : '') +
        '... elapsed ' + formatElapsed(data.elapsed);
      statusWarning.style.display = data.warning ? 'block' : 'none';
    } else if (data.status === 'done') {
      clearInterval(pollTimer);
      statusMsg.textContent = 'Done in ' + formatElapsed(data.elapsed) + '.';
      statusWarning.style.display = 'none';
      reportPanel.style.display = 'block';
      reportPre.textContent = data.report;
      downloadLink.href = data.download_url;
      if (data.verdict) {
        const flagged = data.verdict.flagged || [];
        verdictBadge.style.display = 'inline-block';
        if (data.verdict.verdict === 'clean') {
          verdictBadge.className = 'verdict-badge ok';
          verdictBadge.textContent = 'PASS -- ' + data.verdict.checked + ' DS1(s) clean';
        } else {
          verdictBadge.className = 'verdict-badge fail';
          verdictBadge.textContent = 'ISSUES DETECTED -- ' + flagged.join(', ');
        }
      } else {
        verdictBadge.style.display = 'none';
      }
    } else if (data.status === 'error') {
      clearInterval(pollTimer);
      statusMsg.textContent = 'Error after ' + formatElapsed(data.elapsed) + ': ' + data.error;
      statusWarning.style.display = 'none';
    }
  }
}

/** Shared JIRA-checkbox toggle: shows/hides the ticket field. */
function initJiraToggle(checkboxId, wrapId) {
  const cb = document.getElementById(checkboxId);
  const wrap = document.getElementById(wrapId);
  if (!cb || !wrap) return;
  cb.addEventListener('change', (e) => {
    wrap.style.display = e.target.checked ? 'block' : 'none';
  });
}
