#!/usr/bin/env python3
"""
netbox_client.py -- Netbox API client (requests) for the standalone tool.

Replaces the SecureCRT PowerShell/Invoke-RestMethod workaround with direct
requests calls. Two lookups:
  - oc_to_sonet(hostname_1800, oc_interface) -> (sonet_path, mux_name)
      the ts3-bug fix: true OC->SONET mapping, source of truth for MUX ACR match
  - gsx_mgmt_ips(gsx_netbox_name) -> {"1-1":[ips], "1-2":[ips]}
      for the GSX hop (device name = short node + 1800 site suffix)

Config (NETBOX_URL / NETBOX_TOKEN) read from autotester_config.txt.

Built by P. Capps.
"""

import re
import sys

try:
    import requests
except ImportError:
    print("ERROR: requests not installed. Run:  pip install requests")
    sys.exit(1)

CONFIG_PATH = r"C:\Claude\autotester_config.txt"


def load_netbox_config(path=CONFIG_PATH):
    url = token = ""
    try:
        with open(path, "r") as cfg:
            for line in cfg:
                line = line.strip()
                if line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                if key == "NETBOX_URL":
                    url = val.strip().rstrip("/")
                elif key == "NETBOX_TOKEN":
                    token = val.strip()
    except FileNotFoundError:
        pass
    return url, token


class NetboxClient:
    def __init__(self, base_url, token):
        self.base_url = base_url.rstrip("/") if base_url else ""
        self.session = requests.Session()
        if token:
            self.session.headers.update({
                "Authorization": "Token {}".format(token),
                "Accept": "application/json",
            })

    def ok(self):
        return bool(self.base_url and self.session.headers.get("Authorization"))

    # ---- OC12 -> SONET (ts3-bug fix) ----
    def oc_to_sonet(self, hostname_1800, oc_interface):
        """Returns (sonet_path, mux_name) or (None, None)."""
        if not self.ok():
            return None, None
        url = "{}/api/dcim/interfaces/?device={}&name={}".format(
            self.base_url, hostname_1800, oc_interface)
        try:
            r = self.session.get(url, timeout=15)
            r.raise_for_status()
            data = r.json()
        except Exception:
            return None, None
        results = data.get("results", [])
        if not results:
            return None, None
        iface = results[0]
        endpoints = iface.get("connected_endpoints") or []
        if not endpoints:
            return None, None
        ep = endpoints[0]
        sonet_path = ep.get("name") or ep.get("display")
        dev = ep.get("device") or {}
        mux_name = dev.get("name") or dev.get("display")
        return sonet_path, mux_name

    # ---- GSX mgmt IPs ----
    @staticmethod
    def derive_gsx_device_name(gsx_node, hostname_1800):
        """LAXGSX04 + (ces01.lax1 -> lax1) = LAXGSX04.lax1"""
        if "." in hostname_1800:
            suffix = hostname_1800.split(".", 1)[1]
            return "{}.{}".format(gsx_node, suffix)
        return gsx_node

    def gsx_mgmt_ips(self, gsx_device_name):
        """Returns {"1-1":[ips], "1-2":[ips]} (CIDR stripped) or {}."""
        if not self.ok():
            return {}
        url = "{}/api/ipam/ip-addresses/?device={}".format(self.base_url, gsx_device_name)
        try:
            r = self.session.get(url, timeout=15)
            r.raise_for_status()
            data = r.json()
        except Exception:
            return {}
        cards = {}
        for item in data.get("results", []):
            assigned = item.get("assigned_object") or {}
            iface_name = assigned.get("name", "")
            m = re.match(r'MGMT-(\d+)-(\d+)-(\d+)', iface_name)
            if not m:
                continue
            card_key = "{}-{}".format(m.group(1), m.group(2))
            addr = item.get("address", "")
            ip = addr.split("/")[0] if addr else ""
            if ip:
                cards.setdefault(card_key, []).append(ip)
        return cards


if __name__ == "__main__":
    # quick standalone check
    url, token = load_netbox_config()
    nb = NetboxClient(url, token)
    print("Netbox config loaded:", nb.ok())
    if nb.ok():
        s, m = nb.oc_to_sonet("ces01.lax1", "oc12-ts1/1")
        print("oc_to_sonet(ces01.lax1, oc12-ts1/1) ->", s, m)
        ips = nb.gsx_mgmt_ips("LAXGSX04.lax1")
        print("gsx_mgmt_ips(LAXGSX04.lax1) ->", ips)
