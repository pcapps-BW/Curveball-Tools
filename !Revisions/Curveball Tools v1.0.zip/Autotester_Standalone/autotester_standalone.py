#!/usr/bin/env python3
"""
autotester_standalone.py -- T1 Route Tracer w/ PMs (standalone orchestrator).

One launch -> prompt for creds once -> walk the full route for each DS1:
    1250 (MUSE/hub/loopback + DS1 PMs)
    1800 (MUSE -> OC12 + OC12 stats)   [grouped per hub]
    MUX  (Netbox reconciliation -> SONET/ACR/CEM + GSX assignment + T3)  [per loc]
    GSX  (plink pull of T1 stats)      [non-Peerless only; assignment FROM the MUX]
-> polished .txt matching the SecureCRT Autotester format:
   RUN SUMMARY -> DIAGNOSTIC SUMMARY -> ROUTE BLOCKS -> SHARED INFRA STATS ->
   PER-DS1 PMs.

Data flows in-memory hop to hop -- nothing about downstream devices is entered
by hand. Shared creds for 1250/1800/MUX; separate creds for GSX.

Built by P. Capps.
"""

import sys
import getpass
import datetime

from netbox_client import NetboxClient, load_netbox_config
from npt1250_client import NPT1250Client
from npt1800_client import NPT1800Client, HUB_IPS
from mux4216_client import MUX4216Client
from gsx_client import GSXClient, find_plink, find_live_ip
from output_builders import (
    build_route_block, build_peerless_block,
    build_diagnostic_summary, run_summary_line, SEP, SEP2,
)
from jira_client import post_comment, valid_ticket

# loc -> MUX (from SecureCRT LOC_TO_MUX)
LOC_TO_MUX = {
    "atl": {"name": "ATL1-MUX-02", "ip": "10.243.35.11"},
    "jfk": {"name": "JFK1-MUX-02", "ip": "192.168.246.19"},
    "dfw": {"name": "DFW1-MUX-04", "ip": "10.243.1.17"},
    "lax": {"name": "LAX1-MUX-02", "ip": "10.243.65.4"},
}


# Launcher menu metadata (read by launcher.py auto-discovery).
TOOL_INFO = {
    'name': 'Autotester',
    'ran_from': '1250',
    'desc': 'Traces a T1 circuit end-to-end (1250 -> 1800 -> MUX -> GSX), pulls PMs at each hop, and flags faults.',
    'requires': '1250 IP, DS1(s), infrastructure creds, GSX creds',
    'order': 10,
}


def collect_inputs(session=None):
    """Prompt for inputs; return params dict (or None to abort)."""
    session = session if session is not None else {}

    default_ip = session.get("ip_1250")
    prompt = "1250 IP" + (" [{}]".format(default_ip) if default_ip else "")
    ip_1250 = input(prompt + ": ").strip()
    if not ip_1250 and default_ip:
        ip_1250 = default_ip

    default_ds1 = session.get("ds1_list")
    prompt = "DS1(s) comma-sep (e.g. ts3/8,ts3/9)"
    if default_ds1:
        prompt += " [{}]".format(",".join(default_ds1))
    ds1_raw = input(prompt + ": ").strip()
    if not ds1_raw and default_ds1:
        ds1_list = list(default_ds1)
    else:
        ds1_list = [d.strip() for d in ds1_raw.split(",") if d.strip()]
    if not ip_1250 or not ds1_list:
        print("Need a 1250 IP and at least one DS1.")
        return None

    jira_ticket = None
    if input("Add to JIRA? (y/n) [n]: ").strip().lower() in ("y", "yes"):
        while True:
            jira_ticket = input("JIRA number (NOE-XXXX): ").strip().upper()
            if valid_ticket(jira_ticket):
                break
            if not jira_ticket:
                print("  (blank -- skipping JIRA)")
                jira_ticket = None
                break
            print("  Invalid format. Expected NOE-XXXX (e.g. NOE-1234).")

    open_when_done = input("Open results file when done? (y/n) [y]: ").strip().lower()
    open_when_done = open_when_done in ("", "y", "yes")

    print("\n-- Credentials --")
    infra_user = session.get("infra_user")
    infra_pass = session.get("infra_pass")
    if not (infra_user and infra_pass):
        infra_user = input("Infrastructure username (1250/1800/MUX): ").strip()
        infra_pass = getpass.getpass("Infrastructure password: ")
    gsx_user = session.get("gsx_user")
    gsx_pass = session.get("gsx_pass")
    if not (gsx_user and gsx_pass):
        gsx_user = input("GSX username: ").strip()
        gsx_pass = getpass.getpass("GSX password: ")
    if not (infra_user and infra_pass and gsx_user and gsx_pass):
        print("Missing credentials.")
        return None

    return {
        "ip_1250": ip_1250,
        "ds1_list": ds1_list,
        "infra_user": infra_user,
        "infra_pass": infra_pass,
        "gsx_user": gsx_user,
        "gsx_pass": gsx_pass,
        "jira_ticket": jira_ticket,
        "open_when_done": open_when_done,
    }


def run(params):
    """Execute the full route trace given a params dict (no prompting)."""
    ip_1250 = params["ip_1250"]
    ds1_list = params["ds1_list"]
    infra_user = params["infra_user"]
    infra_pass = params["infra_pass"]
    gsx_user = params["gsx_user"]
    gsx_pass = params["gsx_pass"]
    jira_ticket = params.get("jira_ticket")
    open_when_done = params.get("open_when_done", True)

    # Netbox
    nb_url, nb_token = load_netbox_config()
    netbox = NetboxClient(nb_url, nb_token)
    print("\nNetbox config loaded: {}".format(netbox.ok()))

    plink_path = find_plink()
    print("plink found: {}".format(bool(plink_path)))

    # Two output streams:
    #   progress()  -> console only (live hop-by-hop status; kept OUT of the file)
    #   emit()      -> BOTH the console and the .txt report (the full polished output)
    report = []
    def progress(s=""):
        print(s)
    def emit(s=""):
        report.append(s)
        print(s)

    # ---------- HOP 1: 1250 ----------
    progress("\n" + "=" * 64)
    progress("  HOP 1 -- NPT-1250 ({})".format(ip_1250))
    progress("=" * 64)
    c1250 = NPT1250Client(ip_1250, infra_user, infra_pass)
    try:
        c1250.connect()
    except Exception as e:
        progress("[!] 1250 connect failed: {}: {}".format(type(e).__name__, e))
        _write(["1250 connect FAILED: {}: {}".format(type(e).__name__, e)],
               "connect_fail")
        return
    host_1250 = c1250.hostname
    progress("  host: {}".format(host_1250))

    ds1_map, step1_errors = c1250.query_batch(ds1_list)
    for ds1, info in ds1_map.items():
        progress("  {} -> MUSE {} | hub {} | loopback {}".format(
            ds1, info["muse_id"], info["hub_ip"], info["loopback_ip"]))
    for ds1, err in step1_errors.items():
        progress("  {} -> ERROR: {}".format(ds1, err))

    ds1_pms = c1250.query_ds1_pms(list(ds1_map.keys()))
    c1250.close()

    if not ds1_map:
        progress("[!] No valid DS1s on this 1250. Exiting.")
        _write(["No valid DS1s found on {}.".format(host_1250)], host_1250)
        return

    # ---------- HOP 2: 1800 (grouped by hub IP) ----------
    progress("\n" + "=" * 64)
    progress("  HOP 2 -- NPT-1800")
    progress("=" * 64)

    # group ds1s by hub ip
    hub_groups = {}
    for ds1, info in ds1_map.items():
        hub_groups.setdefault(info["hub_ip"], {})[ds1] = info

    oc12_results   = {}   # ds1 -> oc12
    oc12_stats_all = {}   # key -> stats text
    hub_hostnames  = {}   # ds1 -> 1800 hostname
    loc_codes      = {}   # ds1 -> loc
    peerless_all   = {}   # ds1 -> slot (customer)
    hub_results    = {}   # ds1 -> {hub_name, hub_ip, hub_hostname} (for builders)
    for hub_ip, group in hub_groups.items():
        c1800 = NPT1800Client(hub_ip, infra_user, infra_pass)
        try:
            c1800.connect()
        except Exception as e:
            progress("[!] 1800 {} connect failed: {}: {}".format(hub_ip, type(e).__name__, e))
            continue
        (oc12_map, oc12_stats, hub_name, hub_hostname,
         loc_code, errs, peerless_cust) = c1800.query_batch(hub_ip, group)
        c1800.close()

        progress("  hub {} ({}) loc={}".format(hub_hostname, hub_name, loc_code))
        for ds1, oc12 in oc12_map.items():
            oc12_results[ds1] = oc12
            hub_hostnames[ds1] = hub_hostname
            loc_codes[ds1] = loc_code
            hub_results[ds1] = {"hub_name": hub_name, "hub_ip": hub_ip,
                                "hub_hostname": hub_hostname}
            progress("    {} -> {}".format(ds1, oc12))
        for ds1, err in errs.items():
            progress("    {} -> ERROR: {}".format(ds1, err))
        for k, v in oc12_stats.items():
            oc12_stats_all[k] = v
        for ds1, slot in peerless_cust.items():
            peerless_all[ds1] = slot
        if peerless_cust:
            progress("    Peerless (customer): {}".format(peerless_cust))

    # ---------- HOP 3: MUX (grouped by loc) ----------
    progress("\n" + "=" * 64)
    progress("  HOP 3 -- Cisco NCS 4216 MUX")
    progress("=" * 64)

    # group non-Peerless ds1s by loc
    mux_groups = {}
    for ds1, oc12 in oc12_results.items():
        if ds1 in peerless_all:
            continue   # Peerless has no MUX/GSX
        loc = loc_codes.get(ds1, "")
        mux_groups.setdefault(loc, {})[ds1] = oc12

    mux_results_all = {}
    t3_stats_all    = {}
    for loc, ds1_oc12_map in mux_groups.items():
        mux_info = LOC_TO_MUX.get(loc)
        if not mux_info:
            progress("  [!] No MUX mapping for loc '{}'".format(loc))
            continue
        hostmap = {d: hub_hostnames.get(d, "") for d in ds1_oc12_map}
        cmux = MUX4216Client(mux_info["ip"], infra_user, infra_pass)
        try:
            cmux.connect()
        except Exception as e:
            progress("  [!] MUX {} connect failed: {}: {}".format(
                mux_info["ip"], type(e).__name__, e))
            continue
        mux_results, t3_stats, mn, mip, errs = cmux.query_batch(
            mux_info["name"], mux_info["ip"], ds1_oc12_map, hostmap, netbox)
        cmux.close()

        for ds1, r in mux_results.items():
            mux_results_all[ds1] = r
            progress("  {} -> SONET {} ACR {} CEM {} | GSX {}-{}-{}-{}".format(
                ds1, r["active_sonet"], r["acr_group"], r["cem_group"],
                r["gsx_node"], r["gsx_slot"], r["gsx_port"], r["gsx_t1"]))
            if r["netbox_conflict"]:
                progress("     FLAG: {}".format(r["netbox_conflict"]))
        for ds1, err in errs.items():
            progress("  {} -> ERROR: {}".format(ds1, err))
        for k, v in t3_stats.items():
            t3_stats_all[k] = v

    # ---------- HOP 4: GSX (per non-Peerless ds1, assignment FROM MUX) ----------
    progress("\n" + "=" * 64)
    progress("  HOP 4 -- GSX")
    progress("=" * 64)

    gsx_results = {}   # ds1 -> list of (label, cmd, output)
    if not plink_path:
        progress("  [!] plink not found -- skipping GSX hop.")
    else:
        for ds1, r in mux_results_all.items():
            node = r.get("gsx_node")
            slot = r.get("gsx_slot")
            port = r.get("gsx_port")
            t1   = r.get("gsx_t1")
            if not (node and slot and port and t1):
                progress("  {} -> incomplete GSX assignment, skipping".format(ds1))
                continue
            host_1800 = hub_hostnames.get(ds1, "")
            gsx_dev = netbox.derive_gsx_device_name(node, host_1800)
            cards = netbox.gsx_mgmt_ips(gsx_dev)
            if not cards:
                progress("  {} -> no GSX mgmt IPs from Netbox for {}".format(ds1, gsx_dev))
                continue
            card_key, live_ip = find_live_ip(cards)
            if not live_ip:
                progress("  {} -> no reachable GSX mgmt IP".format(ds1))
                continue
            progress("  {} -> GSX {} ({}) card {} -> T1-1-{}-{}-{}".format(
                ds1, node, live_ip, card_key, slot, port, t1))
            g = GSXClient(live_ip, gsx_user, gsx_pass, plink_path)
            try:
                g.connect()
                stats = g.pull_t1_stats(slot, port, t1)
                gsx_results[ds1] = stats
            except Exception as e:
                progress("     [!] GSX pull failed: {}: {}".format(type(e).__name__, e))
            finally:
                g.close()

    # ---------- STAGE B: POLISHED OUTPUT (SecureCRT order/format) ----------
    step1_errors_all = dict(step1_errors)  # ds1 -> error (1250 no-MUSE etc.)

    # 1) RUN SUMMARY (fault-direction one-liners)
    run_summary_block = [SEP, "  RUN SUMMARY  --  {}".format(host_1250), SEP, ""]
    for ds1 in ds1_map:
        run_summary_block.append(run_summary_line(
            ds1, ds1_map, ds1_pms, oc12_results, hub_results,
            mux_results_all, oc12_stats_all, peerless_all))
    run_summary_block += ["", SEP]
    for ln in run_summary_block:
        emit(ln)

    # 2) DIAGNOSTIC SUMMARY (quick "snapshot" view)
    # Flatten GSX per-DS1 stats into a single text blob per DS1 for counter review.
    gsx_pm_results = {}
    for ds1, stats in gsx_results.items():
        gsx_pm_results[ds1] = "\n".join(
            "{}\n{}".format(cmd, out) for (label, cmd, out) in stats)
    diag_text = build_diagnostic_summary(
        list(ds1_map.keys()), ds1_map, ds1_pms, oc12_results,
        hub_results, mux_results_all, oc12_stats_all,
        t3_stats_all, peerless_all, step1_errors_all, gsx_pm_results)
    emit("")
    emit(diag_text)

    # 3) PER-DS1 ROUTE BLOCKS
    emit("")
    for ds1 in ds1_map:
        info = ds1_map[ds1]
        hub  = hub_results.get(ds1, {})
        oc12 = oc12_results.get(ds1, "")
        if ds1 in peerless_all:
            emit(build_peerless_block(
                ds1, host_1250, info.get("loopback_ip", "?"), info.get("muse_id", "?"),
                hub.get("hub_name", "?"), hub.get("hub_ip", "?"), oc12,
                peerless_all[ds1]))
        elif ds1 in mux_results_all:
            emit(build_route_block(
                ds1, host_1250, info.get("loopback_ip", "?"), info.get("muse_id", "?"),
                hub.get("hub_name", "?"), hub.get("hub_ip", "?"), oc12,
                mux_results_all[ds1]))
        emit("")

    # ---- "In the weeds" stats below ----

    # 4) SHARED INFRASTRUCTURE STATS
    emit("\n" + SEP)
    emit("  SHARED INFRASTRUCTURE STATS")
    emit(SEP)

    emit("\n" + SEP2)
    emit("  NPT-1800 OC12 STATS")
    emit(SEP2)
    emit("")
    for k, v in oc12_stats_all.items():
        emit(v)

    # MUX section: per-DS1 facility alarms grouped, then per-T3 controller stats
    emit("\n" + SEP2)
    emit("  CISCO 4216 MUX STATS")
    emit(SEP2)
    emit("")
    emit("  >> Per-DS1 Facility Alarms")
    for ds1 in ds1_map:
        r = mux_results_all.get(ds1)
        if r and r.get("facility_alarm"):
            emit("")
            emit("  -- {} --".format(ds1.upper()))
            emit(r["facility_alarm"])
    for k, v in t3_stats_all.items():
        emit(v)

    # 5) PER DS1 PERFORMANCE MONITORS
    emit("\n" + SEP)
    emit("  PER DS1 PERFORMANCE MONITORS")
    emit(SEP)
    for ds1 in ds1_map:
        emit("\n" + SEP2)
        emit("  -- {} --".format(ds1.upper()))
        emit("")
        emit(ds1_pms.get(ds1, "  (none)"))
        if ds1 in peerless_all:
            emit("\n  (Peerless/customer circuit -- no MUX/GSX PMs)")
        elif ds1 in gsx_results:
            emit("\n  >> GSX T1 STATS")
            for label, cmd, out in gsx_results[ds1]:
                emit("  >> {}".format(label))
                emit("  CMD: {}".format(cmd))
                emit(out)
                emit("")

    out_path = _write(report, host_1250)

    # ---------- POST TO JIRA (if requested up front) ----------
    if jira_ticket and out_path:
        progress("\n[JIRA] Posting results to {} ...".format(jira_ticket))
        # results_text = run summary + diagnostic summary; pm_text = per-DS1 PMs
        results_text = "\n".join(run_summary_block) + "\n\n" + diag_text
        pm_lines = ["PER DS1 PERFORMANCE MONITORS", ""]
        for ds1 in ds1_map:
            pm_lines.append("-- {} --".format(ds1.upper()))
            pm_lines.append(ds1_pms.get(ds1, "  (none)"))
            pm_lines.append("")
        pm_text = "\n".join(pm_lines)
        ok, msg = post_comment(
            jira_ticket, host_1250, len(ds1_map), results_text, pm_text)
        progress("[JIRA] {}".format(msg) if ok else "[JIRA] FAILED: {}".format(msg))

    # ---------- AUTO-OPEN THE RESULTS FILE ----------
    if open_when_done and out_path:
        try:
            import os as _os
            _os.startfile(out_path)   # Windows: opens in default handler
        except Exception as e:
            progress("[!] could not auto-open file: {}".format(e))


def _write(report, host="run"):
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = r"C:\Claude\Autotester_standalone_{}_{}.txt".format(ts, host)
    try:
        with open(out_path, "w") as f:
            f.write("\n".join(report))
        print("\n[written] {}".format(out_path))
        return out_path
    except Exception as e:
        print("\n[!] write failed: {}".format(e))
        return None


def main():
    print("=" * 64)
    print("  AUTOTESTER STANDALONE -- T1 Route Tracer w/ PMs")
    print("=" * 64)
    params = collect_inputs()
    if params:
        run(params)


if __name__ == "__main__":
    main()
