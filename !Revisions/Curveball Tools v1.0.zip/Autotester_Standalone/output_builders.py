#!/usr/bin/env python3
"""
output_builders.py -- Stage B polished output for the standalone Autotester.

Faithful port of the SecureCRT builders:
  - build_route_block        (FULL T1 ROUTE, HOP 1-4 + SUMMARY)
  - build_peerless_block     (PARTIAL T1 ROUTE, ends at 1800)
  - build_diagnostic_summary (per-DS1 vertical route w/ [ OK ]/[ !! ] + X connectors)
  - run_summary_line         (one-liner PASS + findings + fault-direction suggestion)

The 'X' between hops is intentional (NOT '|' -- a pipe breaks JIRA table rendering).

Built by P. Capps.
"""

import re

SEP  = "=" * 58
SEP2 = "-" * 58


# ---- helpers ----
def _ok_or(flagged, label):
    return "[ !! ] {}".format(label) if flagged else "[ OK ] {}".format(label)


def _check_counters(text, counters):
    """Return ['COUNTER: value', ...] for any non-zero counter found in text."""
    hits = []
    for c in counters:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(re.escape(c)), text)
        if m:
            hits.append("{}: {}".format(c, m.group(1)))
    return hits


CES_COUNTERS = [
    "RxPsnLostPkts", "RxPsnOverrunEvents", "RxPsnUnderrunEvents",
    "RxPsnLopsEvents", "RxPsnES", "RxPsnSES", "RxPsnUAS",
    "TxPsnDiscardPkts", "RxPsnOowDiscardPkts",
]
TDM_COUNTERS = ["DS1ES-L", "DS1SES-L", "DS1CV-L", "DS1LOSS-L", "DS1UAS-L"]
OC12_COUNTERS = ["ES-S", "SES-S", "CV-S", "SEFS-S", "ES-L", "SES-L", "CV-L", "UAS-L"]
T3_COUNTERS = [
    "P-bit Coding Violation", "C-bit Coding Violation", "P-bit Err Secs",
    "Unavailable Secs", "Line Errored Secs", "AIS Defect Secs", "LOS Defect Secs",
]

# GSX PERFMON is columnar: "<Counter>:   <errors>   <Minor> <Major> <Critical>"
# e.g. "Unavailable Seconds:              772       TRUE    TRUE    TRUE"
# We check the leading Errors value (first number after the colon).
#
# IMPORTANT: only the "PERFMON CURRENT" sections hold actual error counts.
# The "PERFMON THRESHOLDS" section lists CONFIG LIMITS (e.g. "Line Errored
# Seconds: 518 648 778") using similar names -- those must NOT be read as
# errors, or a healthy circuit gets falsely flagged. We therefore scan only
# the current-performance region and stop at the THRESHOLDS section.
GSX_PM_COUNTERS = [
    "Code Violations", "Errored Seconds", "Severely Errored Seconds",
    "SEF/AIS Seconds", "Controlled Slip Seconds", "Unavailable Seconds",
]


def _gsx_current_perf_region(text):
    """
    Return only the portion of GSX output that holds CURRENT performance data
    (PERFMON CURRENT FIFTEENMIN / DAY), excluding the THRESHOLDS config table
    and the STATISTICS block. Returns "" if no current-perf section is found.
    """
    region = []
    capture = False
    for line in text.splitlines():
        up = line.upper()
        if "PERFMON CURRENT" in up or "CURRENT PERFORMANCE" in up or "CURRENT DAY PERFORMANCE" in up:
            capture = True
        elif "THRESHOLD" in up:
            capture = False   # stop before the config-limits table
        elif up.strip().startswith("CMD:") and "PERFMON" not in up:
            capture = False
        if capture:
            region.append(line)
    return "\n".join(region)


def _check_gsx_counters(text):
    """
    Return ['Counter: value', ...] for any non-zero GSX PERFMON counter, read
    ONLY from the current-performance region (never the THRESHOLDS table).
    A counter can appear twice (Near End / Far End Path); report the max seen.
    The leading anchor (start-of-line) avoids matching 'Code Violations' inside
    'Line Code Violations' / 'Path Code Violations'.
    """
    region = _gsx_current_perf_region(text)
    if not region:
        return []
    hits = {}
    for c in GSX_PM_COUNTERS:
        # ^\s* anchors to the start of the line so "Code Violations:" does not
        # match "Line Code Violations:" or "Path Code Violations:".
        pat = re.compile(r'^\s*{}\s*:\s+([0-9]+)\b'.format(re.escape(c)), re.MULTILINE)
        for m in pat.finditer(region):
            val = int(m.group(1))
            if val > 0:
                hits[c] = max(hits.get(c, 0), val)
    return ["{}: {}".format(c, v) for c, v in hits.items()]


# ---- FULL ROUTE BLOCK ----
def build_route_block(ds1, host_1250, loopback_ip, muse_id,
                      hub_name, hub_ip, oc12, mux_data):
    gsx_assign = "{}-{}-{}".format(
        mux_data.get("gsx_slot") or "?",
        mux_data.get("gsx_port") or "?",
        mux_data.get("gsx_t1")   or "?")
    lines = [
        SEP,
        "  FULL T1 ROUTE  --  {}".format(ds1.upper()),
        SEP, "",
        "  HOP 1 -- NPT-1250",
        "    Host       : {}".format(host_1250),
        "    Loopback   : {}".format(loopback_ip),
        "    DS1        : {}".format(ds1),
        "    MUSE       : {}".format(muse_id),
        "", SEP2,
        "  HOP 2 -- NPT-1800 Hub",
        "    Hub        : {}".format(hub_name),
        "    IP         : {}".format(hub_ip),
        "    OC12       : {}".format(oc12),
        "", SEP2,
        "  HOP 3 -- Cisco NCS 4216 MUX",
        "    MUX        : {}".format(mux_data.get("mux_name", "?")),
        "    IP         : {}".format(mux_data.get("mux_ip", "?")),
        "    Active Path: SONET {}".format(mux_data.get("active_sonet") or "?"),
        "    ACR Group  : {}".format(mux_data.get("acr_group", "?")),
        "    CEM Group  : {} (VTG {}, T1 {})".format(
            mux_data.get("cem_group", "?"),
            mux_data.get("vtg") or "?",
            mux_data.get("t1")  or "?"),
        "    GSX CE     : CE{}:{}".format(
            mux_data.get("gsx_ce_iface", "?"), mux_data.get("gsx_cem_id", "?")),
        "", SEP2,
        "  HOP 4 -- GSX",
        "    Node       : {}".format(mux_data.get("gsx_node") or "?"),
        "    Assignment : {}".format(gsx_assign),
        "    T1 Command : SHOW T1 T1-1-{}".format(gsx_assign),
        "", SEP,
        "  SUMMARY",
        "  1250 {}  |  {}  |  {}".format(ds1, muse_id, oc12),
        "  {} ACR {} CEM {}  |  CE{}:{}  |  {} {}".format(
            mux_data.get("mux_name", "?"), mux_data.get("acr_group", "?"),
            mux_data.get("cem_group", "?"),
            mux_data.get("gsx_ce_iface", "?"), mux_data.get("gsx_cem_id", "?"),
            mux_data.get("gsx_node") or "?", gsx_assign),
        SEP,
    ]
    return "\n".join(lines)


# ---- PEERLESS (PARTIAL) ROUTE BLOCK ----
def build_peerless_block(ds1, host_1250, loopback_ip, muse_id,
                         hub_name, hub_ip, oc12, slot_num):
    lines = [
        SEP,
        "  PARTIAL T1 ROUTE  --  {}".format(ds1.upper()),
        "  NOTE: ts{} detected. No Bandwidth MUX or GSX. Peerless circuit.".format(slot_num),
        SEP, "",
        "  HOP 1 -- NPT-1250",
        "    Host       : {}".format(host_1250),
        "    Loopback   : {}".format(loopback_ip),
        "    DS1        : {}".format(ds1),
        "    MUSE       : {}".format(muse_id),
        "", SEP2,
        "  HOP 2 -- NPT-1800 Hub",
        "    Hub        : {}".format(hub_name),
        "    IP         : {}".format(hub_ip),
        "    OC12       : {}".format(oc12),
        "", SEP,
        "  Route ends at 1800 -- ts21/ts24 is customer-facing (Peerless).",
        SEP,
    ]
    return "\n".join(lines)


# ---- DIAGNOSTIC SUMMARY (vertical route, OK/!! indicators, X connectors) ----
def build_diagnostic_summary(ds1_list, ds1_map, pm_results, oc12_results,
                             hub_results, mux_results, all_oc12_stats,
                             all_t3_stats, peerless, errors, gsx_pm_results=None):
    gsx_pm_results = gsx_pm_results or {}
    lines = []

    for ds1 in ds1_list:
        lines.append(SEP)
        lines.append("  DIAGNOSTIC SUMMARY  --  {}".format(ds1.upper()))
        lines.append(SEP)
        lines.append("")

        if ds1 in errors:
            lines.append("  COLLECTION FAILED: {}".format(errors[ds1]))
            lines.append("")
            continue

        pm   = pm_results.get(ds1, "")
        oc12 = oc12_results.get(ds1, "")
        hub  = hub_results.get(ds1, {})
        mux  = mux_results.get(ds1, {})
        oc12_base = oc12.split(":")[0] if oc12 else ""
        oc12_key  = "{}|{}".format(hub.get("hub_ip", ""), oc12_base)
        oc12_stat = all_oc12_stats.get(oc12_key, "")
        fa        = mux.get("facility_alarm", "")
        gsx_node  = mux.get("gsx_node", "?")
        gsx_slot  = mux.get("gsx_slot", "?")
        gsx_port  = mux.get("gsx_port", "?")
        gsx_t1    = mux.get("gsx_t1", "?")
        gsx_assign = "{}-{}-{}".format(gsx_slot, gsx_port, gsx_t1)

        # common 1250 TDM/CES detection
        ces_hits = _check_counters(pm, CES_COUNTERS)
        tdm_hits = _check_counters(pm, TDM_COUNTERS)
        phys_los  = bool(re.search(r'ds1/\d+\s+LOS', pm))
        alarm_los = bool(re.search(r'DS1LOS-L', pm) and
                         re.search(r'port-name=ds1-{}'.format(re.escape(ds1)), pm, re.IGNORECASE))
        oc12_errs = _check_counters(oc12_stat, OC12_COUNTERS)
        oc12_alarms = [l.strip() for l in oc12_stat.splitlines()
                       if "R-DS1AIS-P" in l or "AIS-V" in l]

        if ds1 in peerless:
            lines.append("  Peerless circuit (ts{}).".format(peerless[ds1]))
            lines.append("")
            lines.append("         Peerless Network")
            lines.append("")
            lines.append("              X")
            lines.append("")
            # 1800
            for e in oc12_errs:
                lines.append("  [ !! ] OC12 PM {}".format(e))
            if not oc12_errs:
                lines.append("  [ OK ] OC12 PMs clean")
            lines.append("  {}".format(
                _ok_or(oc12_alarms, "OC12 alarms ({} present)".format(len(oc12_alarms))
                       if oc12_alarms else "clean")))
            lines.append("         1800  --  {}  ({})".format(
                hub.get("hub_name", "?"), hub.get("hub_ip", "?")))
            lines.append("         {}".format(oc12))
            lines.append("")
            lines.append("              X")
            lines.append("")
            # 1250
            lines.append("         1250  --  {}".format(
                ds1_map.get(ds1, {}).get("loopback_ip", "?")))
            lines.append("         ds1-{}  {}".format(
                ds1, ds1_map.get(ds1, {}).get("muse_id", "?")))
            if ces_hits:
                for e in ces_hits:
                    lines.append("           CES [ !! ] {}".format(e))
            else:
                lines.append("           CES [ OK ] clean")
            if phys_los or alarm_los:
                lines.append("  [ !! ] TDM  LOS -- loss of signal from LEC")
            elif tdm_hits:
                for e in tdm_hits:
                    lines.append("  [ !! ] TDM {}".format(e))
            else:
                lines.append("  [ OK ] TDM PMs clean")
            lines.append("")
            continue

        # ---- FULL ROUTE: GSX -> MUX -> 1800 -> 1250 (top-down) ----
        gsx_pm = gsx_pm_results.get(ds1, "")
        # Operational/alarm status = the GSX's "down" indicator (like TDM LOS)
        gsx_down = bool(re.search(r'Operational Status:\s*DOWN', gsx_pm, re.IGNORECASE))
        gsx_alarm_m = re.search(r'Alarm Status:\s*(\S+)', gsx_pm)
        gsx_alarm = gsx_alarm_m.group(1) if gsx_alarm_m else ""
        gsx_hits = _check_gsx_counters(gsx_pm)

        if gsx_down:
            lines.append("  [ !! ] GSX DOWN-DS1ALARM{}".format(
                " ({})".format(gsx_alarm) if gsx_alarm and gsx_alarm.upper() != "NONE" else ""))
        if gsx_hits:
            for e in gsx_hits:
                lines.append("  [ !! ] GSX {}".format(e))
        if not gsx_down and not gsx_hits:
            lines.append("  [ OK ] GSX PMs clean")

        lines.append("         GSX  --  {}".format(gsx_node))
        lines.append("         {}".format(gsx_assign))
        lines.append("")
        lines.append("              X")
        lines.append("")

        # MUX / T3
        t3_iface = mux.get("gsx_ce_iface", "")
        t3_stat  = all_t3_stats.get(t3_iface, "")
        t3_errs  = _check_counters(t3_stat, T3_COUNTERS)
        fa_alarm = ("LP_AIS" in fa) if fa else False

        if t3_errs:
            for e in t3_errs:
                lines.append("  [ !! ] T3 {}".format(e))
        else:
            lines.append("  [ OK ] T3 clean")
        lines.append("         MUX  --  {}".format(mux.get("mux_name", "?")))
        lines.append("         SONET {}  ACR {}  CEM {}".format(
            mux.get("active_sonet", "?"), mux.get("acr_group", "?"),
            mux.get("cem_group", "?")))
        lines.append("         1800-facing: {}  GSX-facing: CE{}:{}".format(
            oc12, t3_iface, mux.get("gsx_cem_id", "?")))
        if fa_alarm:
            fa_loc = fa.split("inc ")[-1].split("\n")[0].strip() if "inc " in fa else "facility"
            lines.append("  [ !! ] LP_AIS on {}".format(fa_loc))
        else:
            lines.append("  [ OK ] Facility alarm clean")
        nb_conflict = mux.get("netbox_conflict")
        if nb_conflict:
            lines.append("  [ !! ] {}".format(nb_conflict))

        lines.append("")
        lines.append("              X")
        lines.append("")

        # 1800
        if oc12_errs:
            for e in oc12_errs:
                lines.append("  [ !! ] OC12 PM {}".format(e))
        else:
            lines.append("  [ OK ] OC12 PMs clean")
        if oc12_alarms:
            lines.append("  [ !! ] {} OC12 alarm(s) present".format(len(oc12_alarms)))
        else:
            lines.append("  [ OK ] OC12 alarms clean")
        lines.append("         1800  --  {}  ({})".format(
            hub.get("hub_name", "?"), hub.get("hub_ip", "?")))
        lines.append("         {}".format(oc12))

        lines.append("")
        lines.append("              X")
        lines.append("")

        # 1250
        if ces_hits:
            for e in ces_hits:
                lines.append("  [ !! ] CES {}".format(e))
        else:
            lines.append("  [ OK ] CES PMs clean")
        lines.append("         1250  --  {}".format(
            ds1_map.get(ds1, {}).get("loopback_ip", "?")))
        lines.append("         ds1-{}  {}".format(
            ds1, ds1_map.get(ds1, {}).get("muse_id", "?")))
        if ces_hits:
            for e in ces_hits:
                lines.append("           CES [ !! ] {}".format(e))
        else:
            lines.append("           CES [ OK ] clean")
        if phys_los or alarm_los:
            lines.append("  [ !! ] TDM  LOS -- loss of signal from LEC")
        elif tdm_hits:
            for e in tdm_hits:
                lines.append("  [ !! ] TDM {}".format(e))
        else:
            lines.append("  [ OK ] TDM PMs clean")
        lines.append("")

    lines.append(SEP)
    return "\n".join(lines)


# ---- RUN SUMMARY ONE-LINER (fault direction) ----
def run_summary_line(ds1, ds1_map, pm_results, oc12_results,
                     hub_results, mux_results, all_oc12_stats, peerless):
    pm       = pm_results.get(ds1, "")
    oc12     = oc12_results.get(ds1, "")
    hub      = hub_results.get(ds1, {})
    mux      = mux_results.get(ds1, {})
    oc12_base = oc12.split(":")[0] if oc12 else ""
    oc12_key  = "{}|{}".format(hub.get("hub_ip", ""), oc12_base)
    oc12_stat = all_oc12_stats.get(oc12_key, "")
    fa        = mux.get("facility_alarm", "")

    phys_los  = bool(re.search(r'ds1/\d+\s+LOS', pm))
    alarm_los = bool(re.search(r'DS1LOS-L', pm) and
                     re.search(r'port-name=ds1-{}'.format(re.escape(ds1)), pm, re.IGNORECASE))
    uas_m     = re.search(r'DS1UAS-L\s*:\s*([1-9]\d*)', pm)
    loss_m    = re.search(r'DS1LOSS-L\s*:\s*([1-9]\d*)', pm)

    if ds1 in peerless:
        findings = []
        oc12_pm_errs = []
        for c in ["ES-S", "SES-S", "CV-S", "ES-L", "SES-L", "UAS-L"]:
            m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(c), oc12_stat)
            if m:
                oc12_pm_errs.append("{}={}".format(c, m.group(1)))
        if phys_los or alarm_los:
            findings.append("1250: DS1LOS")
        elif uas_m:
            findings.append("1250: DS1UAS-L={}".format(uas_m.group(1)))
        elif loss_m:
            findings.append("1250: DS1LOSS-L={}".format(loss_m.group(1)))
        if oc12_pm_errs:
            findings.append("1800 OC12: {}".format(", ".join(oc12_pm_errs)))
        if not findings:
            return "  {}  --  PASS (Peerless -- ts{})  |  All clean".format(
                ds1.upper(), peerless[ds1])
        return "  {}  --  PASS (Peerless -- ts{})  |  {}".format(
            ds1.upper(), peerless[ds1], "  |  ".join(findings))

    findings = []
    suggest  = []

    if phys_los or alarm_los:
        findings.append("1250: DS1LOS")
        suggest.append("Trouble from TDM direction -- engage LEC")
    elif uas_m:
        findings.append("1250: DS1UAS-L={}".format(uas_m.group(1)))
        suggest.append("Trouble from TDM direction -- engage LEC")
    elif loss_m:
        findings.append("1250: DS1LOSS-L={}".format(loss_m.group(1)))
        suggest.append("Trouble from TDM direction -- engage LEC")

    for c in ["RxPsnLostPkts", "RxPsnOverrunEvents", "RxPsnUnderrunEvents",
              "RxPsnLopsEvents", "RxPsnES", "RxPsnSES", "RxPsnUAS", "TxPsnDiscardPkts"]:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(c), pm)
        if m:
            findings.append("1250 CES: {}={}".format(c, m.group(1)))
            suggest.append("Trouble from IXC direction")
            break

    oc12_pm_errs = []
    for c in ["ES-S", "SES-S", "CV-S", "ES-L", "SES-L", "UAS-L"]:
        m = re.search(r'{}\s*:\s*([1-9]\d*)'.format(c), oc12_stat)
        if m:
            oc12_pm_errs.append("{}={}".format(c, m.group(1)))
    if oc12_pm_errs:
        findings.append("1800 OC12: {}".format(", ".join(oc12_pm_errs)))
        suggest.append("Trouble from IXC direction -- OC12 errors on 1800")

    oc12_alarm_count = sum(1 for line in oc12_stat.splitlines()
                           if "R-DS1AIS-P" in line or "AIS-V" in line)
    if oc12_alarm_count:
        findings.append("1800: {} OC12 alarm(s)".format(oc12_alarm_count))
        suggest.append("Trouble from TDM direction -- remote AIS on OC12")

    if fa and "LP_AIS" in fa:
        if phys_los or alarm_los or uas_m:
            findings.append("MUX: LP_AIS (downstream of LEC issue)")
        else:
            findings.append("MUX: LP_AIS")
            suggest.append("Trouble from TDM direction -- signal loss upstream of 1800")

    nb_conflict = mux.get("netbox_conflict")
    if nb_conflict:
        findings.append(nb_conflict)

    if not findings:
        return "  {}  --  PASS  |  All clean".format(ds1.upper())
    finding_str = "  |  ".join(findings)
    suggest_str = " / ".join(sorted(set(suggest)))
    if suggest_str:
        return "  {}  --  PASS  |  {}  |  Suggest: {}".format(
            ds1.upper(), finding_str, suggest_str)
    return "  {}  --  PASS  |  {}".format(ds1.upper(), finding_str)
