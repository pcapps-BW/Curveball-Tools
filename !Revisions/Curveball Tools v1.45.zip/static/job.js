/**
 * job.js -- shared submit/poll/render logic for every Curveball Tools web
 * form. Each tool page has identical structure:
 *   <form id="runForm" data-run-url="/api/<slug>/run"> ... </form>
 *   #statusPanel (.msg, .warning)  -- shown while running
 *   #reportPanel (a.download, pre) -- shown when done
 *   #formError                     -- shown on validation/submit errors
 *
 * initJobForm() wires the form up. One tool = one call, at the bottom of
 * that tool's template.
 */
function initJobForm(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  const runUrl = form.dataset.runUrl;

  // Error div lives inside the form when present (supports multiple forms
  // per page, e.g. the DS1 Test Builder's run + monitor forms).
  const formError = form.querySelector('.field-error') || document.getElementById('formError');
  const statusPanel = document.getElementById('statusPanel');
  const statusMsg = statusPanel.querySelector('.msg');
  const statusWarning = statusPanel.querySelector('.warning');
  const statusLog = statusPanel.querySelector('.log');
  const stopBtn = statusPanel.querySelector('.stop-btn');
  let currentJobId = null;
  const reportPanel = document.getElementById('reportPanel');
  const reportPre = reportPanel.querySelector('pre');
  const downloadLink = reportPanel.querySelector('a.download');
  const verdictBadge = reportPanel.querySelector('.verdict-badge');
  let pollTimer = null;
  let loggedLines = 0;

  function formatElapsed(sec) {
    const m = Math.floor(sec / 60), s = sec % 60;
    return m > 0 ? (m + 'm ' + s + 's') : (s + 's');
  }

  // ---- JIRA-result notification -------------------------------------------
  // When the live log shows the JIRA post result, pop a notification so the
  // user knows the script/report is on the ticket and they can continue.
  // Desktop notification when permitted (works from another tab/window),
  // in-page toast as well, alert() as the last-resort fallback.
  let jiraNotified = false;

  function showToast(msg, ok) {
    let t = document.getElementById('cbToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'cbToast';
      document.body.appendChild(t);
      t.addEventListener('click', () => { t.style.display = 'none'; });
    }
    t.className = ok ? 'ok' : 'err';
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._hideTimer);
    t._hideTimer = setTimeout(() => { t.style.display = 'none'; }, 12000);
  }

  function notifyJira(msg, ok) {
    if (jiraNotified) return;
    jiraNotified = true;
    const title = ok ? 'Curveball Tools -- posted to JIRA' : 'Curveball Tools -- JIRA post FAILED';
    let desktopShown = false;
    if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification(title, { body: msg }); desktopShown = true; } catch (e) {}
    }
    showToast(title + '\n' + msg, ok);
    if (!desktopShown && !ok) alert(title + '\n\n' + msg);
  }

  function scanForJiraResult(lines) {
    for (const ln of lines) {
      const s = (ln || '').trim();
      if (/^\[JIRA\] FAILED/.test(s)) { notifyJira(s, false); return; }
      if (/^\[JIRA\] (Comment posted|Comment too large -- attached|File attached)/.test(s)) {
        notifyJira(s + ' -- ready to continue.', true);
        return;
      }
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    formError.textContent = '';
    if (pollTimer) clearInterval(pollTimer);
    reportPanel.style.display = 'none';
    verdictBadge.style.display = 'none';
    statusPanel.style.display = 'block';
    statusWarning.style.display = 'none';
    statusLog.style.display = 'none';
    statusLog.textContent = '';
    loggedLines = 0;
    jiraNotified = false;
    statusMsg.textContent = 'Submitting...';

    // Ask for desktop-notification permission on first use, so the JIRA
    // "posted" alert can reach the user even from another tab/window.
    if ('Notification' in window && Notification.permission === 'default') {
      try { Notification.requestPermission(); } catch (e) {}
    }

    const fd = new FormData(form);
    let res, data;
    try {
      res = await fetch(runUrl, { method: 'POST', body: fd });
      data = await res.json();
    } catch (err) {
      statusPanel.style.display = 'none';
      formError.textContent = 'Could not reach the server: ' + err;
      return;
    }
    if (!res.ok) {
      statusPanel.style.display = 'none';
      formError.textContent = data.error || 'Unknown error.';
      return;
    }

    const jobId = data.job_id;
    currentJobId = jobId;
    pollTimer = setInterval(() => pollStatus(jobId), 2000);
    pollStatus(jobId);
  });

  // Stop button (shown only for stoppable jobs, e.g. the GSX Monitor).
  // Panels are shared across forms on a page -- bind once.
  if (stopBtn && !stopBtn.dataset.bound) {
    stopBtn.dataset.bound = '1';
    stopBtn.addEventListener('click', async () => {
      if (!currentJobId) return;
      stopBtn.disabled = true;
      stopBtn.textContent = 'Stopping...';
      try { await fetch('/api/job/' + currentJobId + '/stop', { method: 'POST' }); }
      catch (e) { /* next poll reflects reality either way */ }
    });
  }

  function resetStopBtn(show) {
    if (!stopBtn) return;
    if (show) {
      stopBtn.style.display = 'inline-block';
    } else {
      stopBtn.style.display = 'none';
      stopBtn.disabled = false;
      stopBtn.textContent = 'Stop';
    }
  }

  function appendLog(lines) {
    if (!lines || lines.length <= loggedLines) return;
    const newLines = lines.slice(loggedLines);
    loggedLines = lines.length;
    if (newLines.length) {
      statusLog.style.display = 'block';
      statusLog.textContent += (statusLog.textContent ? '\n' : '') + newLines.join('\n');
      statusLog.scrollTop = statusLog.scrollHeight;
      scanForJiraResult(newLines);
    }
  }

  async function pollStatus(jobId) {
    let res, data;
    try {
      res = await fetch('/api/job/' + jobId);
      data = await res.json();
    } catch (err) {
      statusMsg.textContent = 'Lost contact with the server -- it may still be running. Retrying...';
      return;
    }

    appendLog(data.log);

    // Page-specific hook: lets a template react to job data each poll
    // (e.g. the DS1 Test Builder auto-fills its GSX Monitor form from
    // data.extras.gsx_targets).
    if (window.onJobData) {
      try { window.onJobData(data); } catch (e) { /* non-fatal */ }
    }

    if (data.status === 'running') {
      statusMsg.textContent = 'Running' + (data.label ? (' -- ' + data.label) : '') +
        '... elapsed ' + formatElapsed(data.elapsed);
      statusWarning.style.display = data.warning ? 'block' : 'none';
      resetStopBtn(!!data.stoppable);
    } else if (data.status === 'done') {
      clearInterval(pollTimer);
      resetStopBtn(false);
      statusMsg.textContent = 'Done in ' + formatElapsed(data.elapsed) + '.';
      statusWarning.style.display = 'none';
      reportPanel.style.display = 'block';
      reportPre.textContent = data.report;
      downloadLink.href = data.download_url;
      if (data.verdict) {
        const flagged = data.verdict.flagged || [];
        verdictBadge.style.display = 'inline-block';
        if (data.verdict.verdict === 'clean') {
          verdictBadge.className = 'verdict-badge ok';
          verdictBadge.textContent = 'PASS -- ' + data.verdict.checked + ' DS1(s) clean';
        } else {
          verdictBadge.className = 'verdict-badge fail';
          verdictBadge.textContent = 'ISSUES DETECTED -- ' + flagged.join(', ');
        }
      } else {
        verdictBadge.style.display = 'none';
      }
    } else if (data.status === 'error') {
      clearInterval(pollTimer);
      resetStopBtn(false);
      statusMsg.textContent = 'Error after ' + formatElapsed(data.elapsed) + ': ' + data.error;
      statusWarning.style.display = 'none';
    }
  }
}

/** Shared JIRA-checkbox toggle: shows/hides the ticket field. */
function initJiraToggle(checkboxId, wrapId) {
  const cb = document.getElementById(checkboxId);
  const wrap = document.getElementById(wrapId);
  if (!cb || !wrap) return;
  cb.addEventListener('change', (e) => {
    wrap.style.display = e.target.checked ? 'block' : 'none';
  });
}
