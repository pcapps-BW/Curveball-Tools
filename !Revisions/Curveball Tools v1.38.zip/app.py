#!/usr/bin/env python3
"""
app.py -- Curveball Tools web front end (proof of concept).

Wraps all 9 launcher tools in a small Flask app so they can be run from a
browser instead of a terminal. Thin wrapper -- no tool/client module logic
changed except one thing: every tool's run(params) now returns its output
file path (previously returned nothing), so this layer can retrieve it.

Architecture (same for every tool, see WEB_SETUP.md for the full writeup):
  1. collect_inputs() is never called -- it uses input()/getpass(), which
     would hang with no terminal attached. Each tool has its own HTML form
     (templates/<tool>.html) matching the same fields; the Flask route
     builds the same params dict collect_inputs() would have built, then
     calls <module>.run(params) directly.
  2. Each run happens in a background thread (see _launch_job/_run_job,
     tool-agnostic). The browser polls /api/job/<id> for status, an
     elapsed-time counter, a "may be hung" warning past a threshold, and a
     live step-by-step log. That log is just each tool's existing
     print(...) progress lines (the same ones you'd see running it from a
     terminal) -- captured via a thread-aware stdout tee (_JobStdoutTee)
     instead of any new logging calls in the tool modules themselves.
  3. Credentials are POSTed fresh every run and held only in the params
     dict passed into the background thread -- never written to disk,
     never put in a session/cookie.

Built by P. Capps.
"""

import os
import re
import sys
import time
import uuid
import threading

from flask import Flask, render_template, request, jsonify, send_file, abort

import autotester_standalone
import npt1250_discovery
import ds1_pms
import fiber_util
import ospf_events
import health_check
import gsx_perfmon
import interface_check
import mux_loop_script

from device_base import CredentialError
from jira_client import valid_ticket

app = Flask(__name__)

# Shown next to the "Built by P. Capps" watermark on every page.
# Bump this with each release (keep in sync with CHANGELOG.md).
APP_VERSION = "v1.38"


@app.context_processor
def _inject_version():
    return {"app_version": APP_VERSION}

# ---- in-memory job store (shared by every tool) --------------------------
JOBS = {}
JOBS_LOCK = threading.Lock()

# ---- live progress log capture --------------------------------------------
# Every tool already print()s its progress as it runs ("[GSX] resolving...",
# "[MUX] connecting...", etc). To surface that in the web UI without adding
# any logging calls to the tool modules, sys.stdout is swapped once at
# startup for a tee that (a) still writes to the real console and (b) routes
# each write to the job log of whichever background thread is currently
# writing, via a thread-id -> job_id map maintained by _run_job.
_THREAD_JOB = {}
_THREAD_JOB_LOCK = threading.Lock()


class _JobStdoutTee:
    def __init__(self, real):
        self._real = real

    def write(self, s):
        self._real.write(s)
        if not s or not s.strip():
            return
        with _THREAD_JOB_LOCK:
            job_id = _THREAD_JOB.get(threading.get_ident())
        if not job_id:
            return
        with JOBS_LOCK:
            job = JOBS.get(job_id)
            if job is not None:
                job["log"].append(s.rstrip("\n"))

    def flush(self):
        self._real.flush()

    def isatty(self):
        return False


sys.stdout = _JobStdoutTee(sys.stdout)


def _valid_ip(s):
    parts = (s or "").strip().split(".")
    return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


def _opt_ip(raw):
    """Blank-or-valid-IP for optional fields. Returns (value, error)."""
    s = (raw or "").strip()
    if not s:
        return "", None
    if _valid_ip(s):
        return s, None
    return None, "'{}' is not a valid IP address.".format(s)


def _parse_jira(f):
    """Returns (jira_ticket_or_None, error_or_None)."""
    if f.get("add_jira") != "on":
        return None, None
    raw = (f.get("jira_ticket") or "").strip().upper()
    if not raw:
        return None, None
    if not valid_ticket(raw):
        return None, "JIRA ticket must look like NOE-1234."
    return raw, None


def _creds(f, user_key="infra_user", pass_key="infra_pass"):
    u = (f.get(user_key) or "").strip()
    p = f.get(pass_key) or ""
    return u, p


def _warn_after(count=1):
    """Seconds before the UI flags a running job as possibly hung. Scales
    gently for tools that loop per-DS1 (Autotester, DS1 PMs)."""
    return max(300, count * 90)


# ---- overall PASS/FAIL rollup (currently only Autotester's Run Summary) --
# Every per-DS1 Run Summary one-liner autotester_standalone.py writes looks
# like "  TS1/1  --  PASS  |  1250: TDM Clean / CES Dirty (...)  |  ..." or
# "  TS1/1  --  FAIL  |  Route incomplete: ...". The existing PASS/FAIL
# there only reflects whether the route resolved -- it says PASS even when
# a hop is Dirty. This scan adds the rollup verdict the report itself
# doesn't have: PASS only if every hop on every DS1 came back Clean.
# Tools that don't emit a Run Summary (everything except Autotester, for
# now) have no such line, so this returns None and the UI shows no badge.
_RUN_SUMMARY_LINE_RE = re.compile(r'^\s*(\S+)\s+--\s+(PASS|FAIL)\b(.*)$', re.MULTILINE)


def _scan_run_summary(report_text):
    if not report_text or "RUN SUMMARY" not in report_text:
        return None
    matches = _RUN_SUMMARY_LINE_RE.findall(report_text)
    if not matches:
        return None
    flagged = [ds1 for ds1, verdict, rest in matches if verdict == "FAIL" or "Dirty" in rest]
    return {"checked": len(matches), "flagged": flagged,
            "verdict": "issues" if flagged else "clean"}


# ---- generic job machinery (identical for every tool) --------------------

def _run_job(job_id, run_callable):
    tid = threading.get_ident()
    with _THREAD_JOB_LOCK:
        _THREAD_JOB[tid] = job_id
    try:
        out_path = run_callable()
        report_text = ""
        if out_path and os.path.exists(out_path):
            with open(out_path, "r", errors="ignore") as f:
                report_text = f.read()
        elif not out_path:
            report_text = ("(Finished without producing a report file -- "
                            "check your inputs, or the server console for details.)")
        verdict = _scan_run_summary(report_text)
        with JOBS_LOCK:
            JOBS[job_id].update(status="done", finished=time.time(),
                                 report=report_text, path=out_path, verdict=verdict)
    except CredentialError as e:
        with JOBS_LOCK:
            JOBS[job_id].update(status="error", finished=time.time(),
                error="Credential error ({}): {}".format(e.cred_type, e))
    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id].update(status="error", finished=time.time(),
                error="{}: {}".format(type(e).__name__, e))
    finally:
        with _THREAD_JOB_LOCK:
            _THREAD_JOB.pop(tid, None)


def _launch_job(label, warn_seconds, run_callable):
    job_id = uuid.uuid4().hex
    with JOBS_LOCK:
        JOBS[job_id] = {
            "status": "running", "started": time.time(), "finished": None,
            "report": None, "path": None, "error": None, "log": [],
            "warn_after": warn_seconds, "label": label,
        }
    t = threading.Thread(target=_run_job, args=(job_id, run_callable), daemon=True)
    t.start()
    return job_id


@app.route("/api/job/<job_id>")
def api_job_status(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify(error="Unknown job id."), 404
        job = dict(job)

    now = job["finished"] or time.time()
    elapsed = now - job["started"]
    warning = job["status"] == "running" and elapsed > job["warn_after"]

    resp = {"status": job["status"], "elapsed": int(elapsed),
            "warning": warning, "label": job["label"], "log": job.get("log", [])}
    if job["status"] == "done":
        resp["report"] = job["report"]
        resp["download_url"] = "/download/{}".format(job_id)
        resp["verdict"] = job.get("verdict")
    elif job["status"] == "error":
        resp["error"] = job["error"]
    return jsonify(**resp)


@app.route("/download/<job_id>")
def download(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job or job["status"] != "done" or not job["path"] or not os.path.exists(job["path"]):
        abort(404)
    return send_file(job["path"], as_attachment=True)


# ---- home page -------------------------------------------------------------

TOOL_URLS = {
    "autotester_standalone": "/tools/autotester",
    "npt1250_discovery":     "/tools/discovery",
    "ds1_pms":               "/tools/ds1-pms",
    "fiber_util":            "/tools/fiber",
    "ospf_events":           "/tools/ospf",
    "health_check":          "/tools/health",
    "gsx_perfmon":           "/tools/gsx-perfmon",
    "interface_check":       "/tools/ixc-check",
    "mux_loop_script":       "/tools/mux-loop",
}
_TOOL_MODULES = [
    autotester_standalone, npt1250_discovery, ds1_pms, fiber_util,
    ospf_events, health_check, gsx_perfmon, interface_check, mux_loop_script,
]


@app.route("/")
def home():
    tools = []
    for mod in _TOOL_MODULES:
        info = mod.TOOL_INFO
        tools.append({
            "name": info["name"], "ran_from": info["ran_from"],
            "desc": info["desc"], "requires": info["requires"],
            "order": info["order"], "url": TOOL_URLS[mod.__name__],
        })
    tools.sort(key=lambda t: t["order"])
    return render_template("home.html", tools=tools)


# ---- Autotester -------------------------------------------------------------

@app.route("/tools/autotester")
def page_autotester():
    return render_template("autotester.html")


@app.route("/api/autotester/run", methods=["POST"])
def api_autotester_run():
    f = request.form
    ip_1250 = (f.get("ip_1250") or "").strip()
    if not _valid_ip(ip_1250):
        return jsonify(error="Enter a valid 1250 IP (4 octets, e.g. 10.111.131.77)."), 400
    ds1_raw = (f.get("ds1_list") or "").strip()
    ds1_list = [d.strip().lower() for d in ds1_raw.replace("&", ",").split(",") if d.strip()]
    if not ds1_list:
        return jsonify(error="Enter at least one DS1 (e.g. ts3/8, ts3/9)."), 400
    infra_user, infra_pass = _creds(f)
    gsx_user, gsx_pass = _creds(f, "gsx_user", "gsx_pass")
    if not (infra_user and infra_pass and gsx_user and gsx_pass):
        return jsonify(error="Infrastructure and GSX credentials are both required."), 400
    jira_ticket, err = _parse_jira(f)
    if err:
        return jsonify(error=err), 400

    params = {
        "ip_1250": ip_1250, "ds1_list": ds1_list,
        "infra_user": infra_user, "infra_pass": infra_pass,
        "gsx_user": gsx_user, "gsx_pass": gsx_pass,
        "jira_ticket": jira_ticket,
        "open_when_done": f.get("open_when_done") == "on",
    }
    job_id = _launch_job(ip_1250, _warn_after(len(ds1_list)),
                          lambda: autotester_standalone.run(params))
    return jsonify(job_id=job_id)


# ---- shared shape: Discovery / Fiber / OSPF / Health ------------------------
# These 4 tools take identical inputs (1250 IP + infra creds + JIRA + open),
# and their run(params) all expect the same keys ("username"/"password", not
# "infra_user"/"infra_pass" -- matches each tool's own collect_inputs()).

def _simple_1250_route(module, run_url):
    f = request.form
    ip_1250 = (f.get("ip_1250") or "").strip()
    if not _valid_ip(ip_1250):
        return jsonify(error="Enter a valid 1250 IP (4 octets, e.g. 10.111.131.77)."), 400
    user, pw = _creds(f)
    if not (user and pw):
        return jsonify(error="Infrastructure username and password are required."), 400
    jira_ticket, err = _parse_jira(f)
    if err:
        return jsonify(error=err), 400

    params = {
        "ip_1250": ip_1250, "username": user, "password": pw,
        "jira_ticket": jira_ticket, "open_when_done": f.get("open_when_done") == "on",
    }
    job_id = _launch_job(ip_1250, _warn_after(), lambda: module.run(params))
    return jsonify(job_id=job_id)


@app.route("/tools/discovery")
def page_discovery():
    info = npt1250_discovery.TOOL_INFO
    return render_template("simple_1250.html", tool_title=info["name"],
                            tool_desc=info["desc"], run_url="/api/discovery/run")


@app.route("/api/discovery/run", methods=["POST"])
def api_discovery_run():
    return _simple_1250_route(npt1250_discovery, "/api/discovery/run")


@app.route("/tools/fiber")
def page_fiber():
    info = fiber_util.TOOL_INFO
    return render_template("simple_1250.html", tool_title=info["name"],
                            tool_desc=info["desc"], run_url="/api/fiber/run")


@app.route("/api/fiber/run", methods=["POST"])
def api_fiber_run():
    return _simple_1250_route(fiber_util, "/api/fiber/run")


@app.route("/tools/ospf")
def page_ospf():
    info = ospf_events.TOOL_INFO
    return render_template("simple_1250.html", tool_title=info["name"],
                            tool_desc=info["desc"], run_url="/api/ospf/run")


@app.route("/api/ospf/run", methods=["POST"])
def api_ospf_run():
    return _simple_1250_route(ospf_events, "/api/ospf/run")


@app.route("/tools/health")
def page_health():
    info = health_check.TOOL_INFO
    return render_template("simple_1250.html", tool_title=info["name"],
                            tool_desc=info["desc"], run_url="/api/health/run")


@app.route("/api/health/run", methods=["POST"])
def api_health_run():
    return _simple_1250_route(health_check, "/api/health/run")


# ---- DS1 PMs -----------------------------------------------------------

@app.route("/tools/ds1-pms")
def page_ds1_pms():
    return render_template("ds1_pms.html")


@app.route("/api/ds1-pms/run", methods=["POST"])
def api_ds1_pms_run():
    f = request.form
    ip_1250 = (f.get("ip_1250") or "").strip()
    if not _valid_ip(ip_1250):
        return jsonify(error="Enter a valid 1250 IP (4 octets, e.g. 10.111.131.77)."), 400
    ds1_raw = (f.get("ds1_list") or "").strip()
    raw_entries = [e for e in ds1_raw.replace("&", ",").split(",") if e.strip()]
    if not raw_entries:
        return jsonify(error="Enter at least one DS1 (e.g. ts1/21, ts3/6)."), 400
    channels, verr = ds1_pms._parse_and_validate(raw_entries)
    if verr:
        return jsonify(error=verr), 400
    user, pw = _creds(f)
    if not (user and pw):
        return jsonify(error="Infrastructure username and password are required."), 400
    jira_ticket, jerr = _parse_jira(f)
    if jerr:
        return jsonify(error=jerr), 400

    params = {
        "ip_1250": ip_1250, "ds1_list": [c[0] for c in channels],
        "username": user, "password": pw,
        "jira_ticket": jira_ticket, "open_when_done": f.get("open_when_done") == "on",
    }
    job_id = _launch_job(ip_1250, _warn_after(len(channels)), lambda: ds1_pms.run(params))
    return jsonify(job_id=job_id)


# ---- GSX Perfmon --------------------------------------------------------

@app.route("/tools/gsx-perfmon")
def page_gsx_perfmon():
    return render_template("gsx_perfmon.html")


@app.route("/api/gsx-perfmon/run", methods=["POST"])
def api_gsx_perfmon_run():
    f = request.form
    gsx_ip = (f.get("gsx_ip") or "").strip()
    if not _valid_ip(gsx_ip):
        return jsonify(error="Enter a valid GSX IP (4 octets)."), 400
    t1_id = gsx_perfmon._parse_t1_id((f.get("t1_id") or "").strip())
    if not t1_id:
        return jsonify(error="T1 assignment must look like T1-1-7-2-2 or 7-2-2."), 400
    gsx_user, gsx_pass = _creds(f, "gsx_user", "gsx_pass")
    if not (gsx_user and gsx_pass):
        return jsonify(error="GSX username and password are required."), 400
    jira_ticket, jerr = _parse_jira(f)
    if jerr:
        return jsonify(error=jerr), 400

    params = {
        "gsx_ip": gsx_ip, "t1_id": t1_id,
        "gsx_user": gsx_user, "gsx_pass": gsx_pass,
        "jira_ticket": jira_ticket, "open_when_done": f.get("open_when_done") == "on",
    }
    job_id = _launch_job(t1_id, _warn_after(), lambda: gsx_perfmon.run(params))
    return jsonify(job_id=job_id)


# ---- IXC Check -----------------------------------------------------------

@app.route("/tools/ixc-check")
def page_ixc_check():
    return render_template("ixc_check.html")


@app.route("/api/ixc-check/run", methods=["POST"])
def api_ixc_check_run():
    f = request.form
    site = (f.get("site") or "").strip().upper()
    if site not in interface_check.SITE_TO_1800:
        return jsonify(error="Select a valid site (ATL, LAX, JFK, DFW)."), 400
    iface = (f.get("interface") or "").strip()
    if not iface or "." not in iface:
        return jsonify(error="Interface must include a dot (VLAN sub-interface), e.g. xe-ts13/3.624."), 400
    user, pw = _creds(f)
    if not (user and pw):
        return jsonify(error="Infrastructure username and password are required."), 400
    jira_ticket, jerr = _parse_jira(f)
    if jerr:
        return jsonify(error=jerr), 400

    params = {
        "site": site, "interface": iface, "username": user, "password": pw,
        "jira_ticket": jira_ticket, "open_when_done": f.get("open_when_done") == "on",
    }
    job_id = _launch_job("{} {}".format(site, iface), _warn_after(),
                          lambda: interface_check.run(params))
    return jsonify(job_id=job_id)


# ---- MUX CEM Loop Script (two modes) -------------------------------------

@app.route("/tools/mux-loop")
def page_mux_loop():
    return render_template("mux_loop.html")


@app.route("/api/mux-loop/run", methods=["POST"])
def api_mux_loop_run():
    f = request.form
    mode = f.get("mode") or "from_1250"
    infra_user, infra_pass = _creds(f)
    if not (infra_user and infra_pass):
        return jsonify(error="Infrastructure username and password are required."), 400
    gsx_user, gsx_pass = _creds(f, "gsx_user", "gsx_pass")
    jira_ticket, jerr = _parse_jira(f)
    if jerr:
        return jsonify(error=jerr), 400
    open_when_done = f.get("open_when_done") == "on"

    if mode == "mux_direct":
        mux_ip = (f.get("mux_ip") or "").strip()
        mux_name = (f.get("mux_name") or "").strip()
        acr_num = (f.get("acr_num") or "").strip()
        cem_group = (f.get("cem_group") or "").strip()
        if not _valid_ip(mux_ip):
            return jsonify(error="Enter a valid MUX IP."), 400
        if not (mux_name and acr_num and cem_group):
            return jsonify(error="MUX name, ACR group, and CEM group are required."), 400

        opt_ip_1250, e1 = _opt_ip(f.get("opt_ip_1250"))
        if e1:
            return jsonify(error=e1), 400
        opt_ip_1800, e2 = _opt_ip(f.get("opt_ip_1800"))
        if e2:
            return jsonify(error=e2), 400
        opt_gsx_ip, e3 = _opt_ip(f.get("opt_gsx_ip"))
        if e3:
            return jsonify(error=e3), 400

        opt_ds1 = (f.get("opt_ds1") or "").strip().lower() if opt_ip_1250 else ""
        opt_oc_iface = (f.get("opt_oc_iface") or "").strip().lower() if opt_ip_1800 else ""
        opt_gsx_t1 = (f.get("opt_gsx_t1") or "").strip().upper()

        # NOTE: _run_mux_direct never actually opens a live GSX session --
        # gsx_ip/gsx_t1 are only embedded as "run manually" text in the
        # generated script, so gsx_user/gsx_pass aren't required here.
        params = {
            "mode": "mux_direct",
            "mux_ip": mux_ip, "mux_name": mux_name,
            "acr_num": acr_num, "cem_group": cem_group,
            "ip_1250": opt_ip_1250, "ds1": opt_ds1,
            "ip_1800": opt_ip_1800, "oc_iface": opt_oc_iface,
            "gsx_t1": opt_gsx_t1, "gsx_ip": opt_gsx_ip if opt_gsx_t1 else "",
            "infra_user": infra_user, "infra_pass": infra_pass,
            "gsx_user": gsx_user, "gsx_pass": gsx_pass,
            "jira_ticket": jira_ticket, "open_when_done": open_when_done,
        }
        label = mux_name
    else:
        ip_1250 = (f.get("ip_1250") or "").strip()
        ds1_raw = (f.get("ds1") or "").strip().lower()
        if not _valid_ip(ip_1250):
            return jsonify(error="Enter a valid 1250 IP."), 400
        if not ds1_raw:
            return jsonify(error="Enter a DS1 (e.g. ts1/1)."), 400
        ds1 = ds1_raw.replace("&", ",").split(",")[0].strip()
        if not (gsx_user and gsx_pass):
            return jsonify(error="GSX username and password are required in this mode."), 400

        params = {
            "mode": "from_1250",
            "ip_1250": ip_1250, "ds1": ds1,
            "infra_user": infra_user, "infra_pass": infra_pass,
            "gsx_user": gsx_user, "gsx_pass": gsx_pass,
            "jira_ticket": jira_ticket, "open_when_done": open_when_done,
        }
        label = "{} {}".format(ip_1250, ds1)

    job_id = _launch_job(label, _warn_after(), lambda: mux_loop_script.run(params))
    return jsonify(job_id=job_id)


if __name__ == "__main__":
    print("=" * 64)
    print("  Curveball Tools -- Web (proof of concept)")
    print("  Open http://127.0.0.1:5000 in a browser")
    print("=" * 64)
    # debug=True is fine on localhost only -- see WEB_SETUP.md.
    app.run(host="127.0.0.1", port=5000, debug=True, threaded=True)
